/**
 * What the version picker recommends, and what it offers to download.
 *
 * The bug was "recommend the first row the source sent", which was wrong three
 * separate ways and each one produced a download that does not work:
 *
 *  - Modrinth's list spans every platform. LuckPerms sent 102 versions and the
 *    head was `v5.5.85-neoforge` -- a NeoForge mod build, offered to a Paper
 *    server, purely because it was published most recently.
 *  - The head is often not a release. Of 25 popular Paper plugins, 5 recommended
 *    a beta or snapshot; ViaVersion and ViaBackwards both had a
 *    `5.12.1-SNAPSHOT` head with 11 real releases below it.
 *  - Hangar and CurseForge decided `installable` purely on "is there a download
 *    URL", so a build for the wrong Minecraft version still got a button.
 *
 * These tests import the real fit pass and run real-shaped data through it. A
 * test that only checked a `recommended: i === 0` string was replaced would pass
 * against the code that was broken.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

import { AddOnHit, ServerFit, versionsFor } from '@/api/server/plugins/providers';

// Namespace imports, not default ones: the version listers are named exports, and
// reaching for `default.getVersions` on a mocked module is simply undefined.
import * as modrinthApi from '@/api/server/plugins/modrinth';
import * as spigetApi from '@/api/server/plugins/spiget';
import * as hangarApi from '@/api/server/plugins/hangar';
import * as curseForgeApi from '@/api/server/plugins/curseforge';

jest.mock('@/api/server/plugins/modrinth', () => ({
    __esModule: true,
    default: { get: jest.fn(), post: jest.fn() },
    search: jest.fn(),
    countAddonsForVersion: jest.fn(),
    getVersions: jest.fn(),
    pickVersion: jest.fn(),
    sha1Hex: jest.fn(),
    downloadVerified: jest.fn(),
}));

// The real export names, not the shape I assumed. Mocking `getVersions` on all
// three left getSpigotVersions/getHangarVersions/getCurseForgeVersions undefined,
// the call threw, and versionsFor's `catch { return [] }` -- which exists so a
// source that cannot be asked shows an empty picker -- reported that as "this
// project publishes no versions". Fourteen green assertions, three providers
// never reached.
jest.mock('@/api/server/plugins/spiget', () => ({
    __esModule: true,
    default: { get: jest.fn() },
    searchSpigot: jest.fn(),
    getSpigotResource: jest.fn(),
    getSpigotVersions: jest.fn(),
}));

jest.mock('@/api/server/plugins/hangar', () => ({
    __esModule: true,
    default: { get: jest.fn() },
    searchHangar: jest.fn(),
    getHangarVersions: jest.fn(),
}));

jest.mock('@/api/server/plugins/curseforge', () => ({
    http: { get: jest.fn() },
    searchCurseForge: jest.fn(),
    getCurseForgeVersions: jest.fn(),
}));

const mrGet = modrinthApi.getVersions as jest.Mock;
const spigetGet = spigetApi.getSpigotVersions as jest.Mock;
const hangarGet = hangarApi.getHangarVersions as jest.Mock;
const cfGet = curseForgeApi.getCurseForgeVersions as jest.Mock;

/** A Leaf server: loadersFor('leaf'), running 1.21.11. */
const leafServer: ServerFit = {
    loaders: ['paper', 'spigot', 'bukkit', 'purpur'],
    gameVersions: ['1.21.11'],
};

/**
 * A hit with only the fields the version list reads.
 *
 * Built here rather than spelled out at each call site: hand-written literals
 * missed `iconUrl` and `raw` and failed tsc, and a builder cannot drift out of
 * sync with the interface the way a copy of it can.
 */
const hit = (over: Partial<AddOnHit> = {}): AddOnHit =>
    ({
        key: 'modrinth:a',
        provider: 'modrinth',
        title: 'A',
        description: '',
        downloads: 0,
        iconUrl: null,
        raw: {},
        ...over,
    }) as AddOnHit;

const mrVersion = (over: Record<string, unknown> = {}) => ({
    id: `id-${Math.random()}`,
    version_number: '1.0.0',
    version_type: 'release',
    loaders: ['bukkit'],
    game_versions: ['1.21.11'],
    date_published: '2026-01-01T00:00:00Z',
    downloads: 10,
    files: [{ url: 'https://cdn.modrinth.com/x.jar' }],
    ...over,
});

beforeEach(() => {
    jest.clearAllMocks();
    mrGet.mockResolvedValue([]);
    spigetGet.mockResolvedValue([]);
    hangarGet.mockResolvedValue([]);
    cfGet.mockResolvedValue({ data: { data: [] } });
});

describe('the version list is asked for what this server can run', () => {
    it('the server is sent to Modrinth rather than ignored', async () => {
        await versionsFor(hit({ key: 'm:a', title: 'A', projectId: 'a' }), leafServer);

        expect(mrGet).toHaveBeenCalledWith('a', {
            loaders: ['paper', 'spigot', 'bukkit', 'purpur'],
            gameVersions: ['1.21.11'],
        });
    });

    it('no Minecraft version chosen means none is sent', async () => {
        // Filtering by a version the user never picked would hide builds for
        // every version, including the one they are on.
        await versionsFor(
            hit({ key: 'm:a', title: 'A', projectId: 'a' }),
            { loaders: ['bukkit'], gameVersions: [] }
        );

        expect(mrGet).toHaveBeenCalledWith('a', { loaders: ['bukkit'], gameVersions: [] });
    });

    it('an empty filtered list falls back to the unfiltered one', async () => {
        // A project that only ships builds for another loader must still show
        // something. Returning [] would read as "this project has no versions".
        mrGet.mockResolvedValueOnce([]).mockResolvedValueOnce([
            mrVersion({ version_number: 'for-fabric', loaders: ['fabric'] }),
        ]);

        const versions = await versionsFor(
            hit({ key: 'm:a', title: 'A', projectId: 'a' }),
            leafServer
        );

        expect(mrGet).toHaveBeenCalledTimes(2);
        expect(versions).toHaveLength(1);
        expect(versions[0].version).toBe('for-fabric');
    });
});

describe('recommended is a version this server can actually run', () => {
    it('a newer build for another platform is not recommended', async () => {
        // The real LuckPerms shape: the NeoForge build is the newest thing in the
        // list and would be the head of an unfitted list.
        mrGet.mockResolvedValue([
            mrVersion({ version_number: 'v5.5.85-neoforge', loaders: ['neoforge'], game_versions: ['26.1'] }),
            mrVersion({ version_number: 'v5.5.71-bukkit', loaders: ['bukkit'], game_versions: ['1.21.11'] }),
        ]);

        const versions = await versionsFor(
            hit({ key: 'm:lp', title: 'LuckPerms', projectId: 'lp' }),
            leafServer
        );

        expect(versions.find((v) => v.recommended)?.version).toBe('v5.5.71-bukkit');
    });

    it('a newer beta is not recommended while a release exists', async () => {
        // The real ViaVersion shape: a SNAPSHOT head over 11 releases.
        mrGet.mockResolvedValue([
            mrVersion({ version_number: '5.12.1-SNAPSHOT+1069', version_type: 'beta' }),
            mrVersion({ version_number: '5.12.0', version_type: 'release' }),
        ]);

        const versions = await versionsFor(
            hit({ key: 'm:v', title: 'ViaVersion', projectId: 'v' }),
            leafServer
        );

        expect(versions.find((v) => v.recommended)?.version).toBe('5.12.0');
    });

    it('a beta is still recommended when it is the only thing on offer', async () => {
        // Refusing to recommend anything would leave the row with no marker and
        // the user with no idea which to pick. Geyser, on 1.21.11, is exactly
        // this: beta head, zero releases.
        mrGet.mockResolvedValue([mrVersion({ version_number: '2.11.3-b1247', version_type: 'beta' })]);

        const versions = await versionsFor(
            hit({ key: 'm:g', title: 'Geyser', projectId: 'g' }),
            leafServer
        );

        expect(versions.filter((v) => v.recommended)).toHaveLength(1);
        expect(versions[0].recommended).toBe(true);
    });

    it('a build for another Minecraft version is not recommended', async () => {
        mrGet.mockResolvedValue([
            mrVersion({ version_number: 'new-but-1.8-only', game_versions: ['1.8.9'] }),
            mrVersion({ version_number: 'matches-1.21.11', game_versions: ['1.21.11'] }),
        ]);

        const versions = await versionsFor(
            hit({ key: 'm:x', title: 'X', projectId: 'x' }),
            leafServer
        );

        expect(versions.find((v) => v.recommended)?.version).toBe('matches-1.21.11');
    });

    it('exactly one row is recommended', async () => {
        mrGet.mockResolvedValue([
            mrVersion({ version_number: 'a' }),
            mrVersion({ version_number: 'b' }),
            mrVersion({ version_number: 'c' }),
        ]);

        const versions = await versionsFor(
            hit({ key: 'm:x', title: 'X', projectId: 'x' }),
            leafServer
        );

        expect(versions.filter((v) => v.recommended)).toHaveLength(1);
    });

    it('nothing is recommended when nothing can be installed', async () => {
        // A snapshot marker on a row with no button would be worse than none.
        mrGet.mockResolvedValue([
            mrVersion({ version_number: 'fabric-only', loaders: ['fabric'], files: [] }),
        ]);

        const versions = await versionsFor(
            hit({ key: 'm:x', title: 'X', projectId: 'x' }),
            leafServer
        );

        expect(versions.filter((v) => v.recommended)).toHaveLength(0);
    });
});

describe('a version that cannot run here gets no download button', () => {
    it('and it says which build it is for', async () => {
        mrGet.mockResolvedValue([mrVersion({ loaders: ['neoforge'], game_versions: ['26.1'] })]);

        const versions = await versionsFor(
            hit({ key: 'm:x', title: 'X', projectId: 'x' }),
            leafServer
        );

        expect(versions[0].installable).toBe(false);
        // The reason has to name the actual mismatch, or the user is left with a
        // greyed row and nothing to act on.
        expect(versions[0].unavailableReason).toMatch(/neoforge/);
        expect(versions[0].unavailableReason).toMatch(/paper/);
    });

    it('a Hangar build for the wrong Minecraft version loses its button', async () => {
        // Hangar's own `installable` only means "there is a download URL", which
        // said nothing about whether it fits.
        hangarGet.mockResolvedValue([
            { name: 'built-for-1.8', createdAt: '2026-02-01', downloads: 5, gameVersions: ['1.8.9'], installable: true },
            { name: 'built-for-1.21.11', createdAt: '2026-01-01', downloads: 1, gameVersions: ['1.21.11'], installable: true },
        ]);

        const versions = await versionsFor(
            hit({ key: 'h:a', provider: 'hangar', title: 'A', hangarSlug: 'a' }),
            leafServer
        );

        expect(versions.find((v) => v.version === 'built-for-1.8')?.installable).toBe(false);
        expect(versions.find((v) => v.version === 'built-for-1.21.11')?.installable).toBe(true);
        expect(versions.find((v) => v.recommended)?.version).toBe('built-for-1.21.11');
    });

    it('a CurseForge file for the wrong Minecraft version loses its button', async () => {
        // The already-mapped CurseForgeVersion shape, not a raw CurseForge file:
        // getCurseForgeVersions is the function mocked, so its own mapping is not
        // in play here.
        cfGet.mockResolvedValue([
            { id: 2, name: 'for-1.8', createdAt: '2026-02-01T00:00:00Z', downloads: 9, gameVersions: ['1.8.9'], fileName: 'a.jar', size: 1, installable: true },
            { id: 1, name: 'for-1.21.11', createdAt: '2026-01-01T00:00:00Z', downloads: 1, gameVersions: ['1.21.11'], fileName: 'b.jar', size: 1, installable: true },
        ]);

        const versions = await versionsFor(
            hit({ key: 'c:a', provider: 'curseforge', title: 'A', curseforgeId: 1 }),
            leafServer
        );

        expect(versions.find((v) => v.version === 'for-1.8')?.installable).toBe(false);
        expect(versions.find((v) => v.recommended)?.version).toBe('for-1.21.11');
    });
});

describe('sources that do not describe their builds are not blocked for it', () => {
    it('Spiget still recommends its one fetchable build', async () => {
        // Spiget publishes no loaders and its tested_versions is almost always
        // null. Treating "unstated" as "incompatible" would leave Spigot with an
        // empty picker, which is a regression rather than a fix.
        spigetGet.mockResolvedValue([
            { id: 9089, name: '2.0.0', releaseAt: 1700000000000, downloads: 5, tested_versions: null },
        ]);

        const versions = await versionsFor(
            hit({ key: 's:a', provider: 'spigot', title: 'A', spigetId: 1 }),
            leafServer
        );

        expect(versions[0].installable).toBe(true);
        expect(versions[0].recommended).toBe(true);
    });

    it('and the newest is still the one offered', async () => {
        spigetGet.mockResolvedValue([
            { id: 2, name: '2.0.0', releaseAt: 1800000000000, downloads: 9, tested_versions: null },
            { id: 1, name: '1.0.0', releaseAt: 1700000000000, downloads: 99, tested_versions: null },
        ]);

        const versions = await versionsFor(
            hit({ key: 's:a', provider: 'spigot', title: 'A', spigetId: 1 }),
            leafServer
        );

        expect(versions.find((v) => v.recommended)?.version).toBe('2.0.0');
    });
});

describe('the list order is left alone', () => {
    it('recommending a release does not move it to the top', async () => {
        // Every source returns newest-first and the source knows things we do
        // not. Re-sorting to float the recommendation would quietly rewrite the
        // order the user is reading.
        mrGet.mockResolvedValue([
            mrVersion({ version_number: 'beta-newest', version_type: 'beta' }),
            mrVersion({ version_number: 'release-older', version_type: 'release' }),
        ]);

        const versions = await versionsFor(
            hit({ key: 'm:x', title: 'X', projectId: 'x' }),
            leafServer
        );

        expect(versions.map((v) => v.version)).toEqual(['beta-newest', 'release-older']);
        expect(versions[1].recommended).toBe(true);
    });
});

describe('the UI is told which row is which', () => {
    it('the modal passes the server down', () => {
        const modal = readFileSync(
            join(__dirname, 'components/server/plugins/AddOnVersions.tsx'),
            'utf8'
        );

        expect(modal).toMatch(/loaders: string\[\];/);
        expect(modal).toMatch(/gameVersion: string;/);
        expect(modal).toContain('versionsFor(hit, { loaders, gameVersions: gameVersion ? [gameVersion] : [] })');
        // Refetched when the server changes, not only when the project does.
        expect(modal).toMatch(/\}, \[hit, loaders, gameVersion\]\);/);
    });

    it('and the container supplies the same loaders the search used', () => {
        const container = readFileSync(
            join(__dirname, 'components/server/plugins/PluginsContainer.tsx'),
            'utf8'
        );

        expect(container).toMatch(/<AddOnVersions[\s\S]{0,700}?loaders=\{loaders\}[\s\S]{0,200}?gameVersion=\{gameVersion\}/);
    });

    it('a row explains its own absence of a button', () => {
        const modal = readFileSync(
            join(__dirname, 'components/server/plugins/AddOnVersions.tsx'),
            'utf8'
        );

        // The provider-level reason is wrong for an incompatible build: "this
        // project publishes its file elsewhere" does not explain a 1.8 jar.
        expect(modal).toMatch(/if \(version\?\.unavailableReason\)/);
        expect(modal).toContain('title={whyNot(hit, version)}');
    });
});
