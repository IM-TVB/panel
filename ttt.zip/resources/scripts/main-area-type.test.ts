/**
 * The main area: a wider column, and type that is a size and a weight up.
 *
 * Two separate things, and the reason they are in one file is that they are
 * the two halves of the same complaint -- the content area was too narrow for
 * what it was showing, and the text in it was too small and too light to read
 * comfortably.
 *
 * The width is a cap on the content column (ContentContainer), which was
 * 1200px. The type is set on `.at-shell__main`, which is the flex column the
 * two routers wrap their page content in -- so it covers the dashboard, the
 * server pages and the account pages, and leaves the sidebar alone, because
 * the sidebar is its sibling rather than a descendant.
 *
 * The tracking matters as much as the size does, and it goes *down*: 0.015em
 * is right at 16px and reads as loose at 17px, with the letters looking like
 * they are being pulled apart.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

/**
 * Comments stripped before scanning: the note above names the class and the
 * tracking value in order to explain the failure, so an unstripped scan reads
 * the explanation as the thing being asserted.
 */
const code = (p: string) => read(p).replace(/\/\*[\s\S]*?\*\//g, '');

const container = code('components/elements/ContentContainer.tsx');
const css = code('assets/aternos.css');

describe('the content column is wider', () => {
    it('the cap is raised', () => {
        expect(container).toMatch(/max-width: 1440px/);
        expect(container).not.toMatch(/max-width: 1200px/);
    });

    it('and the centring and the margin are untouched', () => {
        // A wider column that is no longer centred, or that loses its gutter,
        // would be a different change from the one that was asked for.
        expect(container).toMatch(/mx-4/);
        expect(container).toMatch(/mx-auto/);
    });
});

describe('the main area is set a size and a weight up', () => {
    it('the base type in the main area', () => {
        expect(css).toMatch(/\.at-shell__main,[\s\S]{0,120}font-size: 17px/);
        expect(css).toMatch(/\.at-shell__main,[\s\S]{0,160}font-weight: 500/);
    });

    it('with the tracking tightened, not loosened', () => {
        // Type that is larger needs less tracking. 0.015em on 17px reads as
        // loose, and the letters look like they are being pulled apart.
        expect(css).toMatch(/\.at-shell__main,[\s\S]{0,200}letter-spacing: 0\.005em/);
    });

    it('the headings go from medium to semibold', () => {
        // Upstream sets `font-medium` on h1-h6 in a global style, which
        // styled-components injects at runtime and therefore after this
        // stylesheet -- so the weight has to be stated with !important to be
        // heard at all.
        expect(css).toMatch(/\.at-shell__main :is\(h1, h2, h3, h4, h5, h6\)/);
        expect(css).toMatch(/font-weight: 600 !important/);
    });

    it('and the sidebar is left alone', () => {
        // The size change is scoped to the main area. It is NOT set on the
        // body -- the body carries the panel's own 16px and the tracking, and
        // changing it there would take the sidebar and the flash banners with
        // it, since both are outside the main area.
        expect(css).not.toMatch(/body \{[^}]*font-size: 17px/);
        expect(css).not.toMatch(/body \{[^}]*font-weight: 500/);

        // The rule names the main area, and nothing broader.
        expect(css).toMatch(/\.aternos-blue \.at-shell__main,\s*\n\.aternos-dark \.at-shell__main \{[^}]*font-size: 17px/);
    });
});
