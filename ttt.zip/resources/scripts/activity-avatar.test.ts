/**
 * The activity log shows each actor's own picture.
 *
 * The complaint was that a user who had uploaded a profile picture saw the
 * identicon in the activity log -- the picture was in the sidebar and nowhere
 * else.
 *
 * The cause is that the activity entry drew the plain `Avatar`, which is the
 * identicon and nothing else. The tempting fix is `Avatar.User`, and that is
 * worse: the activity log lists *other people's* actions, and `Avatar.User` is
 * the account that happens to be signed in, so it would put the reader's face
 * next to somebody else's login. The picture has to be the row's own.
 *
 * So `Avatar.Of` was added -- a variant that takes the user it is drawing --
 * and the entry uses it. The data was already there: the API includes the
 * actor (the log asks for `include=actor`), the actor is transformed by
 * UserTransformer, and that sends `avatar_url` for every user it transforms.
 * Nothing on the server had to change.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

/**
 * Comments stripped before scanning: the note above names `Avatar.User` and
 * `Avatar.Of` in order to explain the failure, so an unstripped scan reads the
 * explanation as the thing being asserted.
 */
const code = (p: string) => read(p).replace(/\/\*[\s\S]*?\*\//g, '');

const avatar = code('components/Avatar.tsx');
const entry = code('components/elements/activity/ActivityLogEntry.tsx');
const transformers = code('api/definitions/user/transformers.ts');

describe('the activity entry draws the actor', () => {
    it('and not the identicon', () => {
        // The plain Avatar is the identicon for everybody, which is what the
        // user was seeing.
        expect(entry).not.toMatch(/<Avatar name=/);
    });

    it('and not the signed-in user', () => {
        // This is the one that would look right in a test and be wrong in the
        // product: on the activity log, the reader's own picture would be
        // drawn next to every other person's action.
        expect(entry).not.toMatch(/<Avatar\.User/);
    });

    it('but the actor it was given', () => {
        expect(entry).toMatch(/<Avatar\.Of user=\{actor\}/);
    });
});

describe('the avatar component can draw a particular user', () => {
    it('it is exported', () => {
        expect(avatar).toMatch(/Of: _AvatarOf/);
    });

    it('it draws the picture when there is one', () => {
        expect(avatar).toMatch(/user\?\.avatarUrl/);
        expect(avatar).toMatch(/src=\{user\.avatarUrl\}/);
    });

    it('and the identicon when there is not', () => {
        // Seeded from the uuid, so the same person is the same shape on every
        // page -- and the same shape they had before they uploaded anything.
        expect(avatar).toMatch(/name=\{user\?\.uuid \|\| name \|\| 'system'\}/);
    });

    it('the picture is cropped rather than clipped', () => {
        // An unsized image in a fixed-size box is clipped to its top-left
        // corner, so a 600x800 phone photo came out as a corner of a forehead.
        expect(avatar).toMatch(/objectFit: 'cover'/);
    });
});

describe('the data is already there', () => {
    it('the client maps the API field onto the user', () => {
        expect(transformers).toMatch(/avatarUrl: attributes\.avatar_url \?\? null/);
    });
});
