/**
 * The subuser permission form.
 *
 * This file exists because of a crash that shipped. The "select every
 * permission" control reads the form's value with `useFormikContext()`, called
 * in `EditSubuserModal`'s own body -- but `EditSubuserModal` is the thing that
 * renders `<Formik>`. A hook that reads the Formik context only works in a
 * component rendered *inside* that provider, so the call was never legal:
 *
 *   Formik context is undefined, please verify you are calling
 *   useFormikContext() as child of a <Formik> component.
 *
 * Formik answers that with an invariant, so it was not a partial failure. Every
 * page that mounts the modal -- the Users page, and therefore Settings, died in
 * the app's ErrorBoundary with "An error was encountered by the application
 * while rendering this view. Try refreshing the page." and stayed dead across
 * reloads, because nothing about a reload changes what the code does.
 *
 * Type checking cannot see it and neither can the bundler: `useFormikContext` is
 * a correctly typed call in a correctly typed file. The only thing that notices
 * is rendering, which this panel's jest cannot do for .tsx (see the note in
 * PluginsContainer.stability.test.ts). So these assertions read the source
 * instead, and they are about the shape of the render rather than the values.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

/**
 * Comments stripped before anything is scanned.
 *
 * The docblocks above these two components explain the crash in terms of the
 * hook they exist to avoid -- so an unstripped scan reads the explanation as the
 * very call being asserted against, and the test fails on the documentation
 * that was written to prevent the bug. Same reason sidebar-always-dark.test.ts
 * strips before it looks for tokens.
 */
const code = (p: string) => read(p).replace(/\/\*[\s\S]*?\*\//g, '');

const modal = read('components/server/users/EditSubuserModal.tsx');
const box = read('components/server/users/PermissionTitleBox.tsx');
const css = read('assets/aternos.css');

describe('nothing reads Formik from outside its provider', () => {
    it('the modal does not call useFormikContext at all', () => {
        // The crash. `useField` is the same restriction but is safe in a child,
        // which is why the control became a component of its own.
        expect(modal).not.toContain('useFormikContext');
    });

    it('useField appears only inside the component that is allowed to', () => {
        // `SelectAllPermissions` and `PermissionTitleBox` are rendered inside
        // <Form>. `EditSubuserModal` renders the <Formik>, so a call in its own
        // body is a call outside its own provider.
        //
        // Two details, both learned from the test failing first:
        //  - sliced either side of the control rather than "everything after it",
        //    because it is declared BEFORE the modal and "after" would have
        //    included the very call this exists to exclude;
        //  - matched as a call rather than as the bare name, with the optional generic
        //    argument allowed for (`useField<string[]>(...)`) and the trailing
        //    paren required, so the import at the top of the file -- which
        //    legitimately mentions the name -- is not counted.
        const CALL = /useField(<[^>]*>)?\(/;
        const stripped = code('components/server/users/EditSubuserModal.tsx');
        const control = stripped.indexOf('const SelectAllPermissions');
        const body = stripped.indexOf('const EditSubuserModal');
        const outside = stripped.slice(0, control) + stripped.slice(body);

        expect(stripped.slice(control, body)).toMatch(CALL);
        expect(outside).not.toMatch(CALL);
    });

    it('and the control is rendered inside the Form, not beside it', () => {
        const form = modal.indexOf('<Form>');
        const control = modal.indexOf('<SelectAllPermissions');

        expect(form).toBeGreaterThan(-1);
        expect(control).toBeGreaterThan(form);
        expect(control).toBeLessThan(modal.indexOf('</Formik>'));
    });

    it('PermissionTitleBox keeps its own field access, for the same reason', () => {
        // It was already a component for this reason; this pins that it stayed one.
        expect(box).toContain('useField');
    });
});

describe('select all means all the granter can grant', () => {
    it('and nothing it is not allowed to', () => {
        // `grantable` is filtered by `editablePermissions`, and that is the same
        // list the rows below it are disabled by -- so the filter is asserted on
        // both sides. A control that could tick a disabled box would produce a
        // save the server rejects.
        expect(modal).toContain('visiblePermissions.filter((p) => editablePermissions.indexOf(p) >= 0)');
        expect(modal).toContain(
            'disabled={!canEditUser || editablePermissions.indexOf(`${key}.${pkey}`) < 0}'
        );
    });

    it('and never a permission the form does not show', () => {
        // `editablePermissions` still contains websocket.connect even though the
        // websocket group is not rendered. Ticking it would grant something the
        // person filling in the form can neither see nor undo.
        expect(modal).toMatch(/\.filter\(\(key\) => key !== 'websocket'\)/);
    });

    it('and it says so when some are withheld', () => {
        expect(modal).toContain('the rest are not yours to grant');
    });
});

describe('the third state is visible, not just set', () => {
    it('the DOM property is set on both checkboxes', () => {
        expect(modal).toContain('box.current.indeterminate = partial');
        expect(box).toContain('box.current.indeterminate = partial');
    });

    it('and appearance:none means CSS has to draw the dash', () => {
        // These inputs are `appearance: none` (Input.tsx), so the browser draws
        // no mixed-state mark of its own. Without a rule for it the property is
        // set and nothing is visible -- the fix that fixes nothing.
        expect(css).toMatch(/input\[type='checkbox'\]\.at-check-indeterminate:indeterminate/);
        expect(css).toMatch(/at-check-indeterminate:indeterminate[^}]*background-image:\s*url\(/);
    });

    it('with a dash, not a second tick', () => {
        // `fill='white'` and not an encoded hex, deliberately: sort-relevance
        // counts encoded arrow fills and would read a third one as a failure.
        const dash = css.slice(css.indexOf('.at-check-indeterminate'));
        const rule = dash.slice(dash.indexOf(':indeterminate'), dash.indexOf('}', dash.indexOf(':indeterminate')));

        expect(rule).toContain("fill='white'");
        expect(rule).toMatch(/M4 7h8v2H4z/);
        expect(rule).not.toMatch(/%23/);
    });
});

describe('the mark on a ticked box is legible', () => {
    // Measured rather than eyeballed, because the defect was invisible in the
    // source: Input.tsx paints the tick as `background-color: currentColor`,
    // and `currentColor` resolves from `text-primary-400` -- Tailwind's
    // blue-400, #60a5fa -- because nothing here remaps that scale. A white
    // glyph on it measures 2.54:1, so "ticked" and "half-ticked" were nearly the
    // same picture.
    const toRgb = (hex: string): [number, number, number] => {
        const h = hex.replace('#', '');

        return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number];
    };
    const luminance = ([r, g, b]: [number, number, number]) => {
        const ch = (x: number) => {
            const v = x / 255;

            return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
        };

        return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b);
    };
    const contrast = (a: [number, number, number], b: [number, number, number]) => {
        const la = luminance(a);
        const lb = luminance(b);

        return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
    };

    it('the fill is the theme colour, not currentColor', () => {
        // `currentColor` was the whole bug: it sounds like it follows the theme
        // and in fact follows Tailwind's default palette.
        const checked = css.slice(css.indexOf("input[type='checkbox']:checked"));
        const rule = checked.slice(0, checked.indexOf('}'));

        expect(rule).toContain('background-color: var(--at-primary-600)');
        expect(rule).not.toContain('currentColor');
    });

    it('and the white mark on it clears 4.5:1', () => {
        // Read from the shared block rather than hardcoded, so repointing the
        // theme colour cannot leave the tick illegible again.
        const declared = css.match(/--at-primary-600:\s*(#[0-9a-f]{6});/i);

        expect(declared).not.toBeNull();

        const ratio = contrast([255, 255, 255], toRgb(declared![1]));

        // Was 2.54:1 on #60a5fa.
        expect(ratio).toBeGreaterThanOrEqual(4.5);
    });

    it('the mixed state uses the same fill, so the two read as one control', () => {
        expect(css).toMatch(
            /at-check-indeterminate:indeterminate[^}]*background-color:\s*var\(--at-primary-600\)/
        );
    });

    it('and radios are fixed too -- they share the rule that was broken', () => {
        expect(css).toMatch(/input\[type='radio'\]:checked/);
    });
});