/**
 * The JVM flag picker's wiring, and the two ways it could be wrong.
 *
 * The load-bearing property is that this control never lets the client supply a
 * flag. The flags end up inside a shell invocation that Wings runs, so a control
 * built around a text box, or one that trusted a value the client sent, would be
 * a command injection. The list is a fixed set substituted server-side, and these
 * tests check the client half of that: it sends a key, and the key is checked
 * against what the panel returned rather than hardcoded here.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const component = readFileSync(join(__dirname, 'components/server/startup/JvmFlags.tsx'), 'utf8');
const api = readFileSync(join(__dirname, 'api/server/jvmFlags.ts'), 'utf8');
const startup = readFileSync(join(__dirname, 'components/server/startup/StartupContainer.tsx'), 'utf8');
const console_ = readFileSync(join(__dirname, 'components/server/console/Console.tsx'), 'utf8');

/*
 * The startup page is not theme-restyled: it is stock TitledGreyBox, Select and
 * twin.macro, like the Docker Image dropdown beside it. So this control uses those
 * rather than the at- classes from the restyled pages, and the tests below check
 * it matches its neighbour instead of checking for theme classes.
 */
const select_ = readFileSync(join(__dirname, 'components/elements/Select.tsx'), 'utf8');

describe('the client never supplies a flag', () => {
    it('the payload is a preset key and nothing else', () => {
        expect(api).toMatch(/http\.put<JvmFlagOptions>\([^)]*jvm-flags`,\s*\{\s*preset,?\s*\}\)/);
        // No free-text field, no second value the caller could put flags in.
        expect(api).not.toMatch(/flags:\s*[^}]*preset/);
    });

    it('and it says why, in the place someone would look', () => {
        expect(api).toContain('a command injection');
    });

    it('the presets come from the panel, not from a list here', () => {
        // A second copy of the flag strings in the client would be a list to keep
        // in step, and the one that matters is the one that reaches the command.
        expect(api).toContain('export interface JvmFlagPreset');

        // Comments stripped first: the component explains in prose that
        // -XX:+IgnoreUnrecognizedVMOptions leads each set, and that sentence is
        // exactly what the check was meant to prove is absent from the code.
        const code = component
            .replace(/\/\*[\s\S]*?\*\//g, '')
            .replace(/(^|[^:])\/\/.*$/gm, '$1');

        expect(code).not.toMatch(/XX:[+-]/);
        expect(code).not.toMatch(/-Xmx|-Xms/);

        // No preset may be named in the client either. Checking only for flag
        // strings let a hardcoded <option value="aikar_g1gc"> through, which is
        // the same duplication in a different form: a preset the panel renames
        // would render as an option that selects nothing.
        expect(code).not.toMatch(/aikar_g1gc|aikar_parallel_gc/);
        expect(component).not.toMatch(/value=\{'aikar/);

        // Every option but the default comes from what the panel sent.
        expect(component).toMatch(/\{data\.presets\.map\(\(preset\) => \(/);
        expect(component).toMatch(/<option value=\{'pterodactyl'\}>/);
    });
});

describe('the control is on the startup page', () => {
    it('it is mounted there once', () => {
        expect(startup.match(/<JvmFlags/g)).toHaveLength(1);
    });

    it('below the startup command, above the variables', () => {
        // The command box is a read-only dump of what will run, so a control
        // inside it would look like it edits the whole string.
        expect(startup.indexOf('<JvmFlags')).toBeGreaterThan(startup.indexOf('Startup Command'));
        expect(startup.indexOf('<JvmFlags')).toBeLessThan(startup.indexOf('>Variables<'));
    });

    it('and it is gone from the console page', () => {
        const container = readFileSync(
            join(__dirname, 'components/server/console/ServerConsoleContainer.tsx'),
            'utf8'
        );

        expect(container).not.toContain('JvmFlags');
    });

    it('it uses the same select the Docker image box beside it uses', () => {
        // Matching the immediate neighbour beats reusing a class from a
        // differently-styled page: this one is stock UI, not Aternos-restyled.
        expect(startup).toContain("import Select from '@/components/elements/Select'");
        expect(component).toContain("import Select from '@/components/elements/Select'");
        // And that Select really is a <select>, which is what was asked for.
        expect(select_).toMatch(/styled\.select/);
        expect(component).toMatch(/<Select[\s\S]{0,400}?<option/);
    });

    it('the uuid comes from where it actually lives', () => {
        // state.server is the store wrapper and has no uuid on it, so the natural
        // `state.server?.uuid` is undefined at runtime while type-checking against
        // a `data` property. The console's own components read state.server.data.
        expect(component).toContain('state.server.data?.uuid');
        expect(console_).toContain('state.server.data!');
    });
});

describe('what the user is told', () => {
    it('a small heap is called out, and the choice is still theirs', () => {
        expect(component).toContain('suited_to_this_server');
        expect(component).toMatch(/start-up slower rather than faster/);
    });

    it('the select is never disabled because of the heap', () => {
        // The control is not disabled at all -- a spinner is the busy signal --
        // so there is no attribute a heap check could be smuggled into. A
        // previous guard matched one spelling of such a check, so moving it into
        // a `disabled` prop passed; now the absence of any `disabled` is the
        // assertion, and the heap appears only in the warning text.
        expect(component).not.toMatch(/disabled=/);
        expect(component).not.toMatch(/aria-disabled/);

        const heapUses = [...component.matchAll(/suited_to_this_server/g)];

        // Once to read it, once inside the warning paragraph.
        expect(heapUses.length).toBeGreaterThan(0);
        expect(component).toMatch(/\{!described\.suited_to_this_server \? \(/);
    });

    it('flags a current JVM drops are named, not hidden', () => {
        expect(component).toContain('dropped_on_modern_jvm');
        expect(component).toMatch(/A current Java ignores/);
    });

    it('and that note is actually conditional', () => {
        // The strings are present either way, so only the guard distinguishes a
        // note that appears from one that is dead code.
        expect(component).toMatch(
            /\{described\.dropped_on_modern_jvm\.length > 0 \? \([\s\S]{0,400}A current Java ignores/
        );
    });

    it('a command matching no preset is shown as what it is', () => {
        // Otherwise the control claims a selection that is not in the startup.
        expect(component).toContain('Custom (not one of these)');
        expect(component).toMatch(/flags that are not one of these/);
    });

    it('and a refused change puts the control back', () => {
        // The startup is unchanged when the panel refuses, so re-reading is the
        // only way the select stops showing a choice that did not take.
        expect(component).toMatch(/setError\([\s\S]{0,120}\);\s*\/\/ Re-read[\s\S]{0,200}load\(\);/);
    });

    it('a server with no java command says so instead of offering the control', () => {
        expect(component).toMatch(/if \(!data\.supported\) \{[\s\S]{0,200}data\.reason/);
    });
});

describe('it is styled with what the theme already has', () => {
    it('it uses the startup page\'s own idioms, not the restyled pages\'', () => {
        // Invented in a first pass and matching nothing in the stylesheet, so
        // they would have rendered as unstyled default text.
        for (const ghost of ['at-muted', 'at-code', 'at-note__body', 'at-note__warn', 'at-note__ok']) {
            expect(component).not.toContain(`className={'${ghost}'}`);
        }

        // TitledGreyBox and twin.macro, like the boxes either side of it.
        expect(component).toContain("import TitledGreyBox from '@/components/elements/TitledGreyBox'");
        expect(component).toMatch(/TitledGreyBox title=\{'JVM Flags'\}/);
        expect(component).toContain('tw`text-xs text-neutral-300');
    });

    it('the long flag string wraps rather than widening the card', () => {
        // Aikar\'s set is one unbroken line; without this it widens the layout.
        expect(component).toContain('break-all');
    });
});
