/**
 * Why a search result is missing, and the loader map behind it.
 *
 * Two things are tested, and they are the same bug seen from two ends.
 *
 * Searching "EssentialsX" on a Bungeecord server returned 52 Modrinth results
 * and displayed one. EssentialsX declares bukkit/paper/spigot; a Bungeecord
 * server loads none of those, so the filter dropped it. The filter is correct --
 * a Bukkit plugin genuinely cannot run on a proxy. What was wrong is that
 * nothing said so: the page looked like Modrinth had never heard of it.
 *
 * And `waterfall` was in neither loader map, so a Waterfall server resolved to
 * an EMPTY loader list -- which is the one input that disables the filter. The
 * gap therefore did not hide results, it invited every one of them.
 */

import { hitMatchesLoaders } from './api/server/plugins/modrinth';
import { readFileSync } from 'fs';
import { join } from 'path';

import { loadersFor } from './plugins/loaders';

describe('hitMatchesLoaders', () => {
    // EssentialsX's real Modrinth categories.
    const essentialsX = { categories: ['bukkit', 'economy', 'paper', 'spigot', 'utility'] } as any;

    it('keeps a plugin the server can load', () => {
        expect(hitMatchesLoaders(essentialsX, ['paper', 'spigot', 'bukkit'])).toBe(true);
    });

    it('drops a plugin a proxy cannot load', () => {
        // The case from the report: correct behaviour, and silent until now.
        expect(hitMatchesLoaders(essentialsX, ['bungeecord', 'velocity'])).toBe(false);
    });

    it('treats an empty loader list as no filter at all', () => {
        // Load-bearing, and the reason the waterfall gap was dangerous rather
        // than merely wrong: an unrecognised software yields [], and [] shows
        // everything.
        expect(hitMatchesLoaders(essentialsX, [])).toBe(true);
    });

    it('is case-insensitive on both sides', () => {
        expect(hitMatchesLoaders({ categories: ['Bukkit'] } as any, ['bukkit'])).toBe(true);
        expect(hitMatchesLoaders(essentialsX, ['BUKKIT'])).toBe(true);
    });

    it('drops a project that declares no platform category at all', () => {
        // Documented behaviour rather than an endorsement: a project with no
        // platform category cannot be shown to be compatible, so a filtered
        // search withholds it. This is also why the hidden count is worth
        // surfacing -- these are indistinguishable from "no such plugin" without it.
        expect(hitMatchesLoaders({ categories: [] } as any, ['bukkit'])).toBe(false);
        expect(hitMatchesLoaders({} as any, ['bukkit'])).toBe(false);
    });
});

describe('loadersFor', () => {
    it('maps the software this panel offers to real Modrinth loader categories', () => {
        expect(loadersFor('Paper')).toEqual(['paper', 'spigot', 'bukkit']);
        expect(loadersFor('Bungeecord')).toEqual(['bungeecord', 'velocity']);
        expect(loadersFor('Leaf')).toEqual(['paper', 'spigot', 'bukkit', 'purpur']);
    });

    it('maps Waterfall to its own category first', () => {
        // Waterfall was missing from both maps. loadersFor() fell through to the
        // KNOWN_LOADERS scan, which also lacked it, and returned [] -- the one
        // value that disables the loader filter, so a Waterfall proxy was shown
        // every Bukkit plugin as installable.
        expect(loadersFor('Waterfall')).toContain('waterfall');
        expect(loadersFor('Waterfall')).toContain('bungeecord');
    });

    it('never resolves a known proxy software to an empty list', () => {
        // The specific failure: an empty list is not "unknown", it is
        // "show everything", which is the opposite of what a missing entry means.
        const proxies = ['Bungeecord', 'Waterfall', 'Velocity'];
        proxies.forEach((name) => {
            expect(loadersFor(name).length).toBeGreaterThan(0);
        });
    });

    it('resolves a software it has never heard of to empty, and that is fine', () => {
        // Unknown is different from known-and-missing: there is no right answer,
        // so the filter stands down rather than guessing.
        expect(loadersFor('SomeCustomServer')).toEqual([]);
    });
});

describe('the hidden-results notice is not brought back', () => {
    // It was removed on request. These assertions exist so it cannot reappear by
    // accident: the count had to be threaded through three files to support one
    // line of text, and nothing else consumed it.
    const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

    it('Modrinth no longer reports a withheld count', () => {
        expect(read('api/server/plugins/modrinth.ts')).not.toMatch(/hidden_by_loader/);
    });

    it('the merged search does not carry one', () => {
        const src = read('api/server/plugins/providers.ts');
        expect(src).not.toMatch(/hiddenByLoader/);
    });

    it('and the page neither stores nor renders it', () => {
        const src = read('components/server/plugins/PluginsContainer.tsx');
        expect(src).not.toMatch(/hiddenByLoader/);
        expect(src).not.toMatch(/result(s)? hidden/);
    });
});
