/**
 * Why dialogs need their own hooks in the light theme.
 *
 * This file exists because of a bug the user reported as "the subuser modal is
 * dark". The short version of what was wrong:
 *
 * The light palette is applied by rewriting the stock neutral scale *by class
 * name* -- `.aternos-blue .bg-neutral-800 { background-color: var(--at-page) }`
 * and about thirty others like it. That works only for elements that actually
 * carry those class names.
 *
 * They do not. Pterodactyl styles components with twin's `css` prop, and twin
 * compiles `css={tw`bg-neutral-800`}` to a styled-components style object --
 * verified against this panel's own babel config, which emits:
 *
 *   $_css2: { "--tw-bg-opacity": "1",
 *             "backgroundColor": "hsla(209, 20%, 25%, var(--tw-bg-opacity))" }
 *
 * No class name. The element is left with a hash from styled-components and
 * nothing the remap rules can match, and `className={tw...}` -- which does emit
 * the names -- is used nowhere in the panel. So the remap layer is inert for
 * every stock component; it only reaches elements the theme marks by hand.
 *
 * That is survivable for a card, which reads as a card whether it is dark or
 * not. It is not survivable for a dialog, which overlays the page: the modal
 * panel kept the stock #33404d while the text inside it inherited the light
 * theme's body colour. Measured off the reported screenshot, before any of
 * this was changed:
 *
 *   dialog title  #112136 on #33404d   1.53:1
 *   "User Email"  #203553 on #33404d   1.17:1
 *
 * Both of those are light-theme ink -- #112136 is `--at-text` and #203553 is
 * `--at-text-body` -- sitting on a dark panel. The palette was applied to the
 * text and never to the surface behind it.
 *
 * So `Modal.tsx` and `PermissionTitleBox.tsx` were overridden to put a literal
 * class on the two elements, and the palette is applied to those. The tests
 * below pin the hooks (a hook that is removed silently reintroduces the bug)
 * and the contrast, which is the part that was actually broken.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

/**
 * Comments stripped before scanning, for the reason given in
 * users-permissions.test.ts: the docblocks here name `css={tw...}` and
 * `className={tw...}` in order to explain the failure, so an unstripped scan
 * reads the explanation as the bug. The stylesheet needs the same treatment for
 * the opposite reason -- the comment above the "dark mode is left alone" test
 * spells out the very selector that test asserts is absent.
 */
const code = (p: string) => read(p).replace(/\/\*[\s\S]*?\*\//g, '');

const modal = code('components/elements/Modal.tsx');
const box = code('components/server/users/PermissionTitleBox.tsx');
const row = code('components/server/users/PermissionRow.tsx');
const userRow = code('components/server/users/UserRow.tsx');
const users = code('components/server/users/UsersContainer.tsx');
const edit = code('components/server/users/EditSubuserModal.tsx');
const css = code('assets/aternos.css');

/**
 * The value of a custom property inside a theme's own block.
 *
 * There is more than one block per theme: the shared one, which
 * `.aternos-blue,` and `.aternos-dark {` open between them, and then each
 * theme's own. The shared block carries the primary and sidebar tokens and
 * none of the surfaces, so a lookup has to look through the blocks rather than
 * take the first one it finds.
 */
const blocksOf = (selector: string): string[] => {
    const re = new RegExp(`^\\.${selector} \\{([\\s\\S]*?)\\n\\}`, 'gm');
    const out: string[] = [];
    let match = re.exec(css);
    while (match !== null) {
        out.push(match[1]);
        match = re.exec(css);
    }
    return out;
};

const tokenIn = (selector: string, name: string): string => {
    for (const block of blocksOf(selector)) {
        const found = new RegExp(`${name}:\\s*([^;]+);`).exec(block);
        if (found) return found[1].trim();
    }
    throw new Error(`no ${name} in any .${selector} block`);
};

/** The value of a custom property inside the `.aternos-blue` block. */
const token = (name: string): string => tokenIn('aternos-blue', name);

/** The same, out of the `.aternos-dark` block. */
const darkToken = (name: string): string => tokenIn('aternos-dark', name);

/** #rrggbb or hsl(h, s%, l%) to relative luminance. */
const luminance = (value: string): number => {
    let r = 0;
    let g = 0;
    let b = 0;

    const hex = /^#([0-9a-f]{6})$/i.exec(value);
    if (hex) {
        r = parseInt(hex[1].slice(0, 2), 16) / 255;
        g = parseInt(hex[1].slice(2, 4), 16) / 255;
        b = parseInt(hex[1].slice(4, 6), 16) / 255;
    } else {
        const hsl = /^hsl\(\s*([\d.]+)\s*,\s*([\d.]+)%\s*,\s*([\d.]+)%\s*\)$/.exec(value);
        if (!hsl) throw new Error(`cannot read a colour out of "${value}"`);
        const h = parseFloat(hsl[1]) / 360;
        const s = parseFloat(hsl[2]) / 100;
        const l = parseFloat(hsl[3]) / 100;
        const c = (1 - Math.abs(2 * l - 1)) * s;
        const x = c * (1 - Math.abs(((h * 6) % 2) - 1));
        const m = l - c / 2;
        const [r1, g1, b1] =
            h < 1 / 6
                ? [c, x, 0]
                : h < 2 / 6
                ? [x, c, 0]
                : h < 3 / 6
                ? [0, c, x]
                : h < 4 / 6
                ? [0, x, c]
                : h < 5 / 6
                ? [x, 0, c]
                : [c, 0, x];
        r = r1 + m;
        g = g1 + m;
        b = b1 + m;
    }

    const [lr, lg, lb] = [r, g, b].map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
    return 0.2126 * lr + 0.7152 * lg + 0.0722 * lb;
};

/** WCAG 2.1 contrast ratio between two token names. */
const ratio = (fg: string, bg: string): number => {
    const a = luminance(token(fg));
    const b = luminance(token(bg));
    return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
};

describe('the light palette can reach the dialog', () => {
    it('the modal panel carries a literal class', () => {
        // Twin turns the css prop into a style object, so this className is the
        // only handle the stylesheet has on the panel. Remove it and the dialog
        // goes dark again with nothing failing.
        expect(modal).toMatch(/className=\{'at-modal'\}/);
    });

    it('and that class has a background', () => {
        // Scoped to neither mode on purpose. The theme's tokens are arranged so
        // that each --at-* surface is the same colour as the stock neutral it
        // replaces -- in the dark palette --at-page IS gray-800, which is the
        // stock modal panel. One rule therefore gives the light theme its
        // palette and leaves the dark theme exactly as it was, instead of two
        // rules that have to be kept in agreement.
        expect(css).toMatch(/\.at-modal \{[^}]*background-color: var\(--at-page\)/);
    });

    it('and the permission groups carry one too', () => {
        // TitledGreyBox paints the box and its header through the css prop, so
        // neither `bg-neutral-700` nor `bg-neutral-900` is in the DOM.
        expect(box).toContain('at-modal__group');
        expect(css).toMatch(/\.at-modal__group \{[^}]*background-color:/);
    });

    it('and the dark token is the stock colour, so dark mode does not move', () => {
        // The claim the mode-agnostic rules rest on. The dialog's panel is
        // `bg-neutral-800` upstream, and the dark palette's --at-page has to be
        // that same value or the rule above would restyle the stock dialog.
        const scale = read('../../tailwind.config.js');
        const gray800 = /800:\s*'([^']+)'/.exec(scale);
        expect(gray800).not.toBeNull();
        expect(darkToken('--at-page')).toBe(gray800![1]);
    });

    it('and it is kept alongside any className already passed in', () => {
        // PermissionTitleBox takes a className prop. Replacing it outright would
        // silently drop the caller's styling the first time one is passed.
        expect(box).toMatch(/className=\{className \? `at-modal__group \$\{className\}` : 'at-modal__group'\}/);
    });
});

describe('the dialog is readable in the light theme', () => {
    // These are the pairs that were broken. Measured off the reported
    // screenshot at 1.53:1 and 1.17:1 respectively, because the ink was the
    // light theme's and the surface behind it was not.
    it.each([
        ['the dialog title', '--at-text', '--at-page', 4.5],
        ['a field label', '--at-text-body', '--at-page', 4.5],
        ['the permission count', '--at-text-body', '--at-page', 4.5],
        ['a group header', '--at-text', '--at-surface', 4.5],
        ['a permission name', '--at-text', '--at-surface-2', 4.5],
        ['a permission detail', '--at-text-body', '--at-surface-2', 4.5],
    ])('%s clears 4.5:1', (_what, fg, bg, floor) => {
        const measured = ratio(fg, bg);
        expect(measured).toBeGreaterThanOrEqual(floor);
        // Recorded, so a change that trades a little headroom for something is
        // visible in the diff rather than silent.
        expect(`${measured.toFixed(2)}:1`).toMatch(/^\d/);
    });

    it('the field is bounded by at least 3:1 against the dialog', () => {
        // The fill is section 14's `--at-surface` on an `--at-page` panel, which
        // is only 1.25:1 -- too close to read as a field on its own. The border
        // is what carries the boundary, so it is the border that has to clear
        // 1.4.11, and there is a rule giving it something that does.
        expect(ratio('--at-text-muted', '--at-page')).toBeGreaterThanOrEqual(3);
        expect(css).toMatch(/\.aternos-blue \.at-modal input:not\(\[type='checkbox'\]\)[^}]*border-color:/);
    });
});

describe('dark mode is left alone', () => {
    it('the dialog has no dark-theme override', () => {
        // Dark mode is the stock palette already -- the whole point of it. A
        // `.aternos-dark .at-modal` rule would be the theme restyling something
        // that was never broken, which is how dark mode drifts away from stock.
        //
        // Anchored so it cannot match the panel hook by prefix: `.at-modal__warn`
        // and `.at-modal__error` are pre-existing theme classes on unrelated
        // elements, and a bare prefix test trips over both.
        expect(css).not.toMatch(/\.aternos-dark \.at-modal(?![_\w-])/);
    });
});

/**
 * The modern restyle of the two subuser surfaces.
 *
 * The dialog and the list were asked to look modern, which was agreed as a
 * restyle: same information, same behaviour, no new controls. So what is
 * pinned here is not a look but the things a look depends on -- that every
 * element the stylesheet reaches has the class that reaches it, that the
 * classes exist in the stylesheet at all, and that the text still measures
 * what it measured when it was stock.
 */
describe('the subuser surfaces are modernised', () => {
    it('every element the stylesheet reaches carries its class', () => {
        // A class in the markup with no rule for it is a hole: the element
        // looks half-done and nothing fails.
        expect(modal).toMatch(/className=\{'at-modal'\}/);
        expect(edit).toContain('at-modal__title');
        expect(edit).toContain('at-modal__selectall');
        expect(edit).toContain('at-modal__muted');
        expect(edit).toContain('at-modal__group-desc');
        expect(edit).toContain('at-modal__actions');
        expect(edit).toContain('at-modal__notice');
        expect(box).toContain('at-modal__group');
        expect(box).toContain('at-modal__group-title');
        expect(box).toContain('at-modal__pill');
        expect(row).toContain('at-modal__row');
        expect(row).toContain('at-modal__row-name');
        expect(row).toContain('at-modal__row-detail');
        expect(userRow).toContain('at-subuser');
        expect(userRow).toContain('at-subuser__avatar');
        expect(userRow).toContain('at-subuser__email');
        expect(userRow).toContain('at-subuser__meta');
        expect(userRow).toContain('at-subuser__stat');
        expect(users).toContain('at-subusers');
    });

    it('and the stylesheet has a rule for each of them', () => {
        for (const name of [
            'at-modal',
            'at-modal__title',
            'at-modal__selectall',
            'at-modal__muted',
            'at-modal__pill',
            'at-modal__group',
            'at-modal__group-title',
            'at-modal__group-desc',
            'at-modal__row',
            'at-modal__row-name',
            'at-modal__row-detail',
            'at-modal__notice',
            'at-modal__actions',
            'at-subusers',
            'at-subuser',
            'at-subuser__avatar',
            'at-subuser__email',
            'at-subuser__meta',
            'at-subuser__stat',
        ]) {
            expect(css).toMatch(new RegExp(`\\.${name}(?![\\w-])`));
        }
    });

    it('the action bar is pinned to the bottom of the dialog', () => {
        // The dialog is longer than most viewports, and a Save button that
        // scrolls out of reach is the one control that has to stay reachable.
        expect(css).toMatch(/\.at-modal__actions \{[^}]*position: sticky/);
        expect(css).toMatch(/\.at-modal__actions \{[^}]*bottom:/);
    });

    it('the list is a column of cards rather than a stack of rows', () => {
        expect(css).toMatch(/\.at-subusers \{[^}]*flex-direction: column/);
        expect(css).toMatch(/\.at-subusers \{[^}]*gap:/);
    });

    it('the restyle did not quietly add or remove a control', () => {
        // "Restyle, not redesign" was the brief. A search box, a toggle in
        // place of a checkbox, or a collapsed group would all be new controls,
        // and each of them is a decision the user did not ask for.
        expect(edit).not.toMatch(/at-subuser__search|at-modal__filter|type=['"]search['"]/);
        expect(edit).not.toMatch(/<details|<summary/);
        // The group header is still a checkbox, not a switch.
        expect(box).toMatch(/type=\{'checkbox'\}/);
    });

    it.each([
        ['the dialog title', '--at-text', '--at-page'],
        ['a group name', '--at-text', '--at-page'],
        ['a group count', '--at-text-body', '--at-surface'],
        ['the permission count', '--at-text-body', '--at-surface'],
        ['a permission name', '--at-text', '--at-surface'],
        ['a permission detail', '--at-text-body', '--at-surface'],
        ['a subuser address', '--at-text', '--at-surface'],
        ['a subuser caption', '--at-text-body', '--at-surface'],
    ])('%s still clears 4.5:1', (_what, fg, bg) => {
        expect(ratio(fg, bg)).toBeGreaterThanOrEqual(4.5);
    });
});
