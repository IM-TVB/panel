/**
 * Spigot jar filenames.
 *
 * The name matters more here than for any other provider. Spiget serves the jar
 * from "/{id}.jar" with no Content-Disposition, so whatever the panel invents is
 * what the user sees in their file manager, in `/plugins`, and in any backup.
 * `spigot-28140.jar` says nothing -- not the plugin, not the version, and two of
 * them are indistinguishable.
 *
 * The other half is that the name must be REVERSIBLE. The installed-detection
 * strips a trailing version off a filename to work out which project it is, and
 * the card badge is keyed on the same thing. When those two were written
 * independently they disagreed (`spigot-<id>` vs `spigot`), and the "Installed"
 * badge silently vanished for every Spigot plugin. So the round trip is tested
 * here, not just the output.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

import { spigotFilename, spigotMarker } from './api/server/plugins/spigetFilename';

/** The rule PluginsContainer uses to recover a project from an installed file. */
const keyOfInstalled = (filename: string): string =>
    filename
        .replace(/\.jar$/i, '')
        .replace(/-disabled$/i, '')
        .replace(/-\d[\w.+-]*$/i, '')
        .toLowerCase();

describe('spigotFilename', () => {
    it('uses the project name rather than the resource id', () => {
        expect(spigotFilename('LuckPerms', 28140, '5.5.71')).toBe('LuckPerms-5.5.71.jar');
    });

    it('falls back to a readable name when the version is unknown', () => {
        // The version lookup is a network call that can fail; a missing version
        // must not mean falling back to the id.
        expect(spigotFilename('LuckPerms', 28140, null)).toBe('LuckPerms.jar');
        expect(spigotFilename('LuckPerms', 28140, undefined)).toBe('LuckPerms.jar');
        expect(spigotFilename('LuckPerms', 28140, '')).toBe('LuckPerms.jar');
    });

    it('never emits the id-only name it used to', () => {
        expect(spigotFilename('LuckPerms', 28140, '5.5.71')).not.toMatch(/spigot-28140/);
    });

    it('replaces characters a filesystem would refuse', () => {
        expect(spigotFilename('My Plugin', 1, '1.0')).toBe('My-Plugin-1.0.jar');
        expect(spigotFilename('a/b', 1, '1.0')).toBe('a-b-1.0.jar');
        expect(spigotFilename('what?', 1, '1.0')).toBe('what-1.0.jar');
        expect(spigotFilename('a:b*c', 1, '1.0')).toBe('a-b-c-1.0.jar');
    });

    it('will not produce a hidden or awkward filename', () => {
        expect(spigotFilename('...', 1, '1.0')).toBe('spigot-1-1.0.jar');
        expect(spigotFilename('  spaced  ', 1, '1.0')).not.toMatch(/^-/);
    });

    it('refuses names Windows will not open', () => {
        // A jar called con.jar cannot be deleted through Explorer, which makes it
        // a support ticket rather than a filename.
        expect(spigotFilename('CON', 5, '1.0')).toBe('spigot-5-1.0.jar');
        expect(spigotFilename('nul', 5, '1.0')).toBe('spigot-5-1.0.jar');
    });

    it('always puts a digit after the version separator', () => {
        // This is what makes the name reversible. Spiget version names are not
        // guaranteed to start with a digit, and one that began with a letter
        // would leave the installed-detection unable to strip it.
        expect(spigotFilename('Plugin', 1, 'v2.0')).toBe('Plugin-2.0.jar');
        expect(spigotFilename('Plugin', 1, '2023.1')).toBe('Plugin-2023.1.jar');
        expect(spigotFilename('Plugin', 1, 'beta')).toBe('Plugin.jar');
    });

    it('handles real Spiget version shapes', () => {
        expect(spigotFilename('LuckPerms', 28140, '5.5.71')).toBe('LuckPerms-5.5.71.jar');
        expect(spigotFilename('Vault', 33184, '1.7.3')).toBe('Vault-1.7.3.jar');
        expect(spigotFilename('ProtocolLib', 31274, '5.3.0')).toBe('ProtocolLib-5.3.0.jar');
    });

    it('keeps accented names readable', () => {
        expect(spigotFilename('Café Plugin', 1, '1.0')).toBe('Cafe-Plugin-1.0.jar');
    });
});

describe('the filename and the installed-detection agree', () => {
    // The round trip that was broken. Each case is a real Spiget shape.
    const cases: [string, number, string | null][] = [
        ['LuckPerms', 28140, '5.5.71'],
        ['Vault', 33184, '1.7.3'],
        ['My Awesome Plugin', 1234, '2.0'],
        ['Weird/Name?', 99, '1.0'],
        ['Plugin', 42, 'v2.0'],
        ['Café', 7, '3.1'],
        ['NoVersion', 5, null],
        ['With-Bits', 6, '2023.4.1'],
    ];

    it.each(cases)('%s resolves back to the project it came from', (name, id, version) => {
        const filename = spigotFilename(name, id, version);

        expect(keyOfInstalled(filename)).toBe(spigotMarker(name, id));
    });

    it('is not merely self-consistent: it must differ between projects', () => {
        // If the sanitiser collapsed everything to one key, the round trip above
        // would still pass while the badge matched the wrong plugin.
        const keys = cases.map(([name, id]) => spigotMarker(name, id));

        expect(new Set(keys).size).toBe(cases.length);
    });
});

describe('the container is wired to the same helper', () => {
    // Without this the whole file is a test of a function nothing calls. The
    // badge broke precisely because the card built its marker inline
    // (`spigot-<id>`) while the filename was built elsewhere, and a unit test of
    // the helper would have passed throughout.
    const source = readFileSync(
        join(__dirname, 'components/server/plugins/PluginsContainer.tsx'),
        'utf8'
    );

    it('derives the Spigot marker with spigotMarker, not an inline id', () => {
        expect(source).toContain('spigotMarker(');
        expect(source).not.toMatch(/`spigot-\$\{hit\.spigetId\}`/);
    });

    it('imports it', () => {
        expect(source).toMatch(/import \{ spigotMarker \} from/);
    });
});

describe('spigotMarker', () => {
    it('is lowercase, matching how the installed list is keyed', () => {
        expect(spigotMarker('LuckPerms', 28140)).toBe('luckperms');
        expect(spigotMarker('LuckPerms', 28140)).toBe(spigotMarker('luckperms', 28140));
    });

    it('falls back to the id only when the name is unusable', () => {
        expect(spigotMarker('...', 77)).toBe('spigot-77');
        expect(spigotMarker('', 77)).toBe('spigot-77');
    });
});
