/**
 * Minecraft release versions, newest first.
 *
 * Generated from Mojang's official version manifest
 * (https://launchermeta.mojang.com/mc/game/version_manifest.json), keeping every
 * release from 26.3 down to 1.7.10. Anything older than 1.7.10 is omitted on purpose:
 * no currently supported server software can run it, so offering it would only
 * produce an install that cannot succeed.
 *
 * To refresh after a new Minecraft release:
 *   curl -s https://launchermeta.mojang.com/mc/game/version_manifest.json
 *   # take every entry with "type":"release", newest first, and stop at 1.7.10
 *
 * Order matters: the version grid renders this array top-to-bottom, so it is
 * listed newest first to match Aternos.
 */
export const MINECRAFT_VERSIONS: string[] = [
    '26.3', '26.2', '26.1.2', '26.1.1', '26.1', '1.21.11',
    '1.21.10', '1.21.9', '1.21.8', '1.21.7', '1.21.6', '1.21.5',
    '1.21.4', '1.21.3', '1.21.2', '1.21.1', '1.21', '1.20.6',
    '1.20.5', '1.20.4', '1.20.3', '1.20.2', '1.20.1', '1.20',
    '1.19.4', '1.19.3', '1.19.2', '1.19.1', '1.19', '1.18.2',
    '1.18.1', '1.18', '1.17.1', '1.17', '1.16.5', '1.16.4',
    '1.16.3', '1.16.2', '1.16.1', '1.16', '1.15.2', '1.15.1',
    '1.15', '1.14.4', '1.14.3', '1.14.2', '1.14.1', '1.14',
    '1.13.2', '1.13.1', '1.13', '1.12.2', '1.12.1', '1.12',
    '1.11.2', '1.11.1', '1.11', '1.10.2', '1.10.1', '1.10',
    '1.9.4', '1.9.3', '1.9.2', '1.9.1', '1.9', '1.8.9',
    '1.8.8', '1.8.7', '1.8.6', '1.8.5', '1.8.4', '1.8.3',
    '1.8.2', '1.8.1', '1.8', '1.7.10',
];

export const LATEST_MINECRAFT_VERSION = MINECRAFT_VERSIONS[0];
