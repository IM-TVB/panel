import { ModrinthHit, search as searchModrinth, countAddonsForVersion, getVersions as getModrinthVersions } from '@/api/server/plugins/modrinth';
import { SpigetHit, searchSpigot, getSpigotVersions } from '@/api/server/plugins/spiget';
import { HangarHit, searchHangar, getHangarVersions } from '@/api/server/plugins/hangar';
import { CurseForgeHit, searchCurseForge, getCurseForgeVersions } from '@/api/server/plugins/curseforge';

export type Provider = 'modrinth' | 'spigot' | 'hangar' | 'curseforge';

/**
 * One result from any provider, in the shape the card grid renders.
 *
 * The two sources have very different metadata, so the fields that only one of
 * them can supply are optional rather than faked: `game_versions` and a SHA-1
 * `hash` exist for Modrinth and are null for Spigot.
 */
export interface AddOnHit {
    /** Stable per-provider key, e.g. "modrinth:AANobbMI". */
    key: string;
    provider: Provider;
    title: string;
    description: string;
    downloads: number;
    iconUrl: string | null;
    /** Modrinth only. */
    projectId?: string;
    gameVersions?: string[];
    hash?: string;
    /** Spigot only. */
    spigetId?: number;
    spigotName?: string;
    /** Spigot only: the resource's newest version, whose name gives the jar its version. */
    spigetVersionId?: number | null;
    spigotAuthor?: string | null;
    /** Spigot only: the resource's newest build is what can be installed. */
    latestOnly?: boolean;
    /** Hangar only. */
    hangarSlug?: string;
    hangarVersion?: string | null;
    /** CurseForge only. */
    curseforgeId?: number;
    curseforgeFileId?: number | null;
    /** True when the project is listed but its jar is published elsewhere. */
    external?: boolean;
    raw: ModrinthHit | SpigetHit | HangarHit | CurseForgeHit;
}

/**
 * How the merged list is ordered.
 *
 * `downloads` is the default because that is what people mean by "popular": the
 * whole list, across every selected source, ranked by download count.
 *
 * `mixed` is the older behaviour and still earns its place. Ranked purely by
 * downloads, Modrinth's catalogue dwarfs the others, so it filled page one on
 * its own and Spigot and Hangar were invisible until the user paged forward.
 * Round-robin keeps every source on screen, which is the point of offering more
 * than one chip.
 *
 * `name` is alphabetical. No upstream can sort by name, so it is applied to the
 * merged list here rather than being pushed down to them.
 */
/**
 * One installable version of a project, normalised across sources.
 *
 * The point of this shape is that the version list does not have to know which
 * source it came from. Every upstream names versions differently -- Modrinth has
 * an id and a version_number, Spigot an id and a name, Hangar only a name,
 * CurseForge a file id and a display name -- and the UI should not.
 */
export interface AddOnVersion {
    /** Opaque, provider-specific. Passed back verbatim to install this exact one. */
    id: string;
    /** What to show. Modrinth's version_number, or the upstream name. */
    version: string;
    gameVersions: string[];
    /** ISO date when the source publishes one. */
    releasedAt: string | null;
    downloads: number;
    /**
     * False when the source lists the version but there is no URL we can fetch, or
     * when the build cannot run on the server that asked. Shown, but with no
     * download button -- a button that fails after the click is worse than an
     * obviously unavailable row.
     */
    installable: boolean;
    /**
     * The one a plain "install" would have chosen, and the only Spigot version
     * fetchable from the browser. Marked so the list can show it.
     */
    recommended: boolean;
    /**
     * Why this row has no download button, when the panel decided that rather
     * than the source. Null when the source is the reason, or when there is one.
     */
    unavailableReason?: string | null;
}

/**
 * What the fit pass needs to know about a row beyond what the UI shows.
 *
 * Not part of AddOnVersion: the list is per-project and these are per-source
 * facts used to decide what to recommend, not something the version row renders.
 */
interface VersionFacts {
    /** Per-version loaders, when the source publishes them. Empty means "not stated". */
    loaders: string[];
    /** A finished release rather than a beta, alpha or snapshot. */
    isRelease: boolean;
}

export interface ServerFit {
    loaders: string[];
    gameVersions: string[];
}

/**
 * Fit a source's version list to one server: which rows can be downloaded onto
 * it, and which to recommend.
 *
 * This existed because "recommend the first row" was wrong in three separate
 * ways, all of which produced a download that does not work:
 *
 *  - Modrinth's list spans every platform. For LuckPerms the head is a NeoForge
 *    mod build, offered to a Paper server, because NeoForge versions were
 *    published most recently.
 *  - The head is frequently not a release. Scanning 25 popular Paper plugins,
 *    5 recommended a beta or snapshot -- including ViaVersion and ViaBackwards,
 *    whose heads were `5.12.1-SNAPSHOT` builds while 11 real releases sat below
 *    them in the same list.
 *  - Hangar and CurseForge decide `installable` purely on "is there a download
 *    URL", so a build for the wrong Minecraft version still got a button.
 *
 * Sources are asked for compatible versions first (Modrinth can filter, and now
 * does), and this pass is the backstop for the ones that cannot. A row the source
 * does not describe -- Spiget publishes no loaders and usually no tested
 * versions -- is never blocked, because refusing a build for missing metadata
 * would leave Spigot with nothing to offer at all.
 *
 * Order is left exactly as the source returned it. Only the flags change, so the
 * list still reads newest-first and nothing moves.
 */
const fitToServer = (
    versions: AddOnVersion[],
    facts: VersionFacts[],
    fit: ServerFit
): AddOnVersion[] => {
    const wanted = fit.loaders.map((l) => l.toLowerCase());
    const game = fit.gameVersions;
    const gameRequired = game.length > 0;

    const rows = versions.map((version, i) => {
        const fact = facts[i] ?? { loaders: [], isRelease: true };

        let reason: string | null = null;

        if (wanted.length > 0 && fact.loaders.length > 0) {
            const overlap = fact.loaders.some((l) => wanted.includes(l.toLowerCase()));

            if (!overlap) {
                reason = `Built for ${fact.loaders.join(', ')}; this server runs ${fit.loaders.join(', ')}.`;
            }
        }

        // A row that lists game versions and does not include this one is for a
        // different Minecraft. A row that lists none is simply not described.
        if (reason === null && gameRequired && version.gameVersions.length > 0) {
            if (!version.gameVersions.some((g) => game.includes(g))) {
                reason = `Built for Minecraft ${version.gameVersions
                    .slice(0, 3)
                    .join(', ')}; this server runs ${game.join(', ')}.`;
            }
        }

        return { version, fact, reason };
    });

    // The first installable release, falling back to the first installable row of
    // any kind. Every source returns newest-first, so "first" already means
    // newest and no re-sorting is needed -- and not re-sorting matters, because
    // the source's own ordering knows things we do not.
    const installable = rows.filter((r) => r.reason === null && r.version.installable);
    const recommendedId =
        installable.find((r) => r.fact.isRelease)?.version.id ??
        installable[0]?.version.id ??
        null;

    return rows.map(({ version, reason }) => ({
        ...version,
        installable: reason === null && version.installable,
        unavailableReason: reason ?? version.unavailableReason ?? null,
        recommended: version.id === recommendedId,
    }));
};

/**
 * Every published version of a project, newest first.
 *
 * $fit is the server asking, and it decides what gets recommended. Omitting it
 * keeps the old behaviour of "whatever the source listed first", which is kept
 * only so the signature stays usable from a context that genuinely has no
 * server -- there is none in the panel today.
 *
 * Deliberately returns a plain list rather than throwing: a source that cannot
 * be asked (no CurseForge key, Spiget down) yields an empty list for that entry,
 * and the caller already handles a project with no version list -- it falls back
 * to the single install button. A version picker that hard-fails would take the
 * whole browser down with it.
 */
export const versionsFor = async (
    hit: AddOnHit,
    fit: ServerFit = { loaders: [], gameVersions: [] }
): Promise<AddOnVersion[]> => {
    try {
        if (hit.provider === 'modrinth' && hit.projectId) {
            // Asked for compatible versions first. Modrinth can answer that
            // question, and asking is strictly better than downloading 102
            // versions to discard 99 of them -- a NeoForge mod build offered to a
            // Bukkit server is the failure this prevents.
            let raw = await getModrinthVersions(hit.projectId, {
                loaders: fit.loaders,
                gameVersions: fit.gameVersions,
            });

            // But never answer with an empty picker for a project that has
            // versions. A project that only ships builds for another loader is
            // still worth showing, with every row marked and the reason shown --
            // which is what the unfiltered list is for.
            if (raw.length === 0) {
                raw = await getModrinthVersions(hit.projectId);
            }

            const versions = raw.map((v) => ({
                id: v.id,
                version: v.version_number || v.name,
                gameVersions: v.game_versions ?? [],
                releasedAt: v.date_published ?? null,
                downloads: v.downloads ?? 0,
                installable: Array.isArray(v.files) && v.files.length > 0,
                recommended: false,
            }));

            return fitToServer(
                versions,
                // Modrinth is the only source that states a per-version loader
                // and a release/beta/snapshot type, and the only one where
                // getVersions already did the filtering.
                raw.map((v) => ({
                    loaders: v.loaders ?? [],
                    isRelease: (v.version_type ?? 'release') === 'release',
                })),
                fit
            );
        }

        if (hit.provider === 'spigot' && hit.spigetId) {
            const raw = await getSpigotVersions(hit.spigetId);

            // Only the newest is fetchable from the browser; the rest need the
            // panel. Marked so the list does not pretend otherwise.
            return fitToServer(
                raw.map((v) => ({
                    id: String(v.id),
                    version: v.name,
                    // Spiget publishes no loaders and its tested_versions is
                    // almost always null, so a row is described by nothing. The
                    // fit pass leaves undescribed rows alone rather than refusing
                    // every one of them, which is the only way Spigot offers
                    // anything at all.
                    gameVersions: [],
                    releasedAt: v.releasedAt ? new Date(v.releasedAt).toISOString() : null,
                    downloads: v.downloads,
                    installable: true,
                    recommended: false,
                })),
                // No type information, so every row counts as a release and the
                // newest is recommended -- which is the only fetchable one.
                raw.map(() => ({ loaders: [], isRelease: true })),
                fit
            );
        }

        if (hit.provider === 'hangar' && hit.hangarSlug) {
            const raw = await getHangarVersions(hit.hangarSlug);

            return fitToServer(
                raw.map((v) => ({
                    id: v.name,
                    version: v.name,
                    gameVersions: v.gameVersions,
                    releasedAt: v.createdAt || null,
                    downloads: v.downloads,
                    installable: v.installable,
                    recommended: false,
                })),
                // Hangar states no per-version loader here; installable already
                // means "there is a PAPER download for it".
                raw.map(() => ({ loaders: [], isRelease: true })),
                fit
            );
        }

        if (hit.provider === 'curseforge' && hit.curseforgeId) {
            const raw = await getCurseForgeVersions(hit.curseforgeId);

            return fitToServer(
                raw.map((v) => ({
                    id: String(v.id),
                    version: v.name,
                    gameVersions: v.gameVersions,
                    releasedAt: v.createdAt || null,
                    downloads: v.downloads,
                    installable: v.installable,
                    recommended: false,
                })),
                raw.map(() => ({ loaders: [], isRelease: true })),
                fit
            );
        }
    } catch (e) {
        return [];
    }

    return [];
};

/**
 * A source that dropped out of a search, and why.
 *
 * The reason is the point. Previously a failed source was recorded by name only
 * and the page said it "could not be reached" -- which is a guess. The three
 * causes look identical from the page and need completely different responses:
 *
 *   blocked   a blocker or privacy extension refused the request. Nothing is
 *             wrong with Spiget, the panel, or the query, and no amount of
 *             retrying will help. The user needs to know it is their browser.
 *   refused   the source answered, with an error. Its problem, possibly
 *             temporary.
 *   network   the request never got an answer at all.
 *
 * Without this, all three were reported identically and a user whose blocker was
 * eating the request had no way to tell that from Spiget being down.
 */
export interface ProviderFailure {
    provider: Provider;
    reason: 'blocked' | 'refused' | 'network';
    /** HTTP status, when there was one. */
    status?: number;
}

/**
 * Classify a failed source request.
 *
 * A blocked request is the interesting case. It is not an HTTP error -- the
 * browser refuses to send it -- so it arrives as a generic network failure with
 * no status. What distinguishes it is `navigator.onLine` being true: the machine
 * has a connection, the source simply never saw the request.
 *
 * That is a heuristic, and it is labelled as one in the wording the UI shows. It
 * is still the difference between "Spigot is down, try again" and "something in
 * your browser is blocking Spiget", which is the difference between a user who
 * waits and a user who turns off an extension.
 */
const classify = (e: any): ProviderFailure['reason'] => {
    if (typeof e?.response?.status === 'number') {
        return 'refused';
    }

    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
        return 'network';
    }

    // Online, yet no HTTP response: a blocker, a DNS/hosts entry, or a CSP
    // refusal. All of them mean the request never left the browser.
    return 'blocked';
};

export const describeFailure = (f: ProviderFailure): string => {
    if (f.reason === 'blocked') {
        return 'was blocked before it left your browser — an ad blocker or privacy extension is the usual cause';
    }

    if (f.reason === 'network') {
        return 'could not be reached — this device appears to be offline';
    }

    return f.status
        ? `answered with an error (HTTP ${f.status})`
        : 'answered with an error';
};

export type AddOnSort = 'relevance' | 'downloads' | 'name' | 'mixed';

export interface AddOnSearchOptions {
    query: string;
    loaders: string[];
    gameVersion: string;
    supports: 'plugins' | 'mods';
    /** Empty means every provider. */
    providers: Provider[];
    sort?: AddOnSort;
    limit?: number;
    offset?: number;
}

const fromModrinth = (hit: ModrinthHit): AddOnHit => ({
    key: `modrinth:${hit.project_id}`,
    provider: 'modrinth',
    title: hit.title,
    description: hit.description ?? '',
    downloads: hit.downloads ?? 0,
    iconUrl: hit.icon_url,
    projectId: hit.project_id,
    gameVersions: hit.game_versions ?? [],
    raw: hit,
});

const fromHangar = (hit: HangarHit): AddOnHit => ({
    key: `hangar:${hit.slug}`,
    provider: 'hangar',
    title: hit.name,
    description: hit.description ?? '',
    downloads: hit.downloads ?? 0,
    iconUrl: hit.iconUrl,
    hangarSlug: hit.slug,
    hangarVersion: hit.latestVersion,
    gameVersions: hit.supportedVersions,
    // Hangar hosts most projects but not all; an external-only one is listed
    // with a marker rather than dropped, so a search does not look lossy.
    external: !hit.installable,
    raw: hit,
});

const fromCurseForge = (hit: CurseForgeHit): AddOnHit => ({
    key: `curseforge:${hit.id}`,
    provider: 'curseforge',
    title: hit.name,
    description: hit.summary ?? '',
    downloads: hit.downloads ?? 0,
    iconUrl: hit.iconUrl,
    curseforgeId: hit.id,
    curseforgeFileId: hit.fileId,
    gameVersions: hit.gameVersions ?? [],
    raw: hit,
});


const fromSpigot = (hit: SpigetHit): AddOnHit => ({
    key: `spigot:${hit.id}`,
    provider: 'spigot',
    title: hit.name,
    description: hit.description ?? '',
    downloads: hit.downloads ?? 0,
    iconUrl: hit.icon_url,
    spigetId: hit.id,
    spigotName: hit.name,
    spigetVersionId: hit.version_id,
    spigotAuthor: hit.author,
    latestOnly: true,
    external: hit.external,
    raw: hit,
});

/**
 * Search every selected provider and merge.
 *
 * A provider that fails is dropped rather than failing the whole search: losing
 * Spiget for a moment is much better than losing Modrinth too. The names of any
 * providers that dropped come back in `failed` so the UI can say so.
 */
export const searchAddOns = async (opts: AddOnSearchOptions): Promise<{
    hits: AddOnHit[];
    truncated: boolean;
    failed: ProviderFailure[];
}> => {
    // Each provider is asked for the full limit, not a share of it: the
    // merged list is interleaved afterwards, so a smaller per-provider fetch
    // would show a page that is thin in whichever source is behind.
    const limit = opts.limit ?? 20;
    const failed: ProviderFailure[] = [];
    const sort = opts.sort ?? 'downloads';

    // A source is only ever asked for one page, so asking it for the wrong
    // ordering loses results before the merge ever sees them: the popular ones
    // past page one are not recoverable by sorting what came back. The requested
    // ordering therefore has to match what the user picked.
    //
    // Relevance is the default now, and it is a real option rather than a
    // hidden exception. When someone has typed a query a download ranking is
    // close to meaningless -- "luck perms" should surface LuckPerms, not
    // whichever plugin has the most downloads -- and re-sorting by downloads
    // here used to throw away the relevance Modrinth had already ranked with.
    // With an empty query there is nothing to be relevant to, so Modrinth is left
    // on its own default.
    /*
     * Relevance and 'mixed' both interleave the sources round-robin; they differ
     * in whether each source is re-ranked before that.
     *
     * Relevance leaves every stream exactly as its provider returned it. That is
     * the point: Modrinth already ranked by relevance, and re-sorting by
     * downloads here threw that ranking away, so the list answered "most
     * downloaded" to someone who had typed a query. Re-ranking a relevance
     * ordering by download count is strictly worse than not ranking it at all.
     *
     * Interleaving rather than concatenating is kept either way: concatenating
     * put every Modrinth result ahead of every Spigot one, and since the page
     * shows only the first N, Modrinth filled the page alone and the other
     * sources stayed invisible until the user paged forward.
     */
    const byRelevance = sort === 'relevance';
    const byPopularity = sort === 'downloads';
    const relevanceFirst = Boolean(opts.query) && sort !== 'name';

    const tasks: Promise<AddOnHit[]>[] = [];

    if (opts.providers.includes('modrinth')) {
        tasks.push(
            searchModrinth(opts.query, {
                projectType: opts.supports === 'mods' ? 'mod' : 'plugin',
                loaders: opts.loaders,
                gameVersions: opts.gameVersion ? [opts.gameVersion] : [],
                limit,
                sort: relevanceFirst ? 'relevance' : 'downloads',
            })
                .then((r) => r.hits.map(fromModrinth))
                .catch((e) => {
                    failed.push({ provider: 'modrinth', reason: classify(e), ...(e?.response?.status ? { status: e.response.status } : {}) });

                    return [];
                })
        );
    }

    if (opts.providers.includes('spigot')) {
        tasks.push(
            searchSpigot(opts.query, { limit, sort: 'downloads' })
                .then((r) =>
                    r.hits
                        // Spigot hosts more than plugins: resource packs and
                        // mods would be installed into a Bukkit server, where
                        // they can never load. External resources have no jar
                        // here either.
                        .filter((h) => !h.external)
                        .map(fromSpigot)
                )
                .catch((e) => {
                    failed.push({ provider: 'spigot', reason: classify(e), ...(e?.response?.status ? { status: e.response.status } : {}) });

                    return [];
                })
        );
    }

    if (opts.providers.includes('hangar')) {
        tasks.push(
            searchHangar(opts.query, { limit, sort: byPopularity ? 'downloads' : 'updated' })
                .then((r) => r.hits.map(fromHangar))
                .catch((e) => {
                    failed.push({ provider: 'hangar', reason: classify(e), ...(e?.response?.status ? { status: e.response.status } : {}) });

                    return [];
                })
        );
    }

    if (opts.providers.includes('curseforge')) {
        tasks.push(
            searchCurseForge(opts.query, { limit })
                .then((r) => r.hits.map(fromCurseForge))
                .catch((e) => {
                    failed.push({ provider: 'curseforge', reason: classify(e), ...(e?.response?.status ? { status: e.response.status } : {}) });

                    return [];
                })
        );
    }

    const settled = await Promise.all(tasks);

    const flat = settled.flat();

    if (sort === 'name') {
        // localeCompare, not >: a plain string sort puts every capitalised name
        // before every lower-case one, and provider names are inconsistently
        // cased, so "Zoomify" and "authMe" would swap places.
        return {
            hits: [...flat].sort((a, b) => a.title.localeCompare(b.title)),
            truncated: flat.length >= limit,
            failed,
        };
    }

    if (sort === 'downloads') {
        // One ranking across every source, which is what "most downloaded" has
        // to mean. A source with no download count is treated as zero rather
        // than dropped: Spiget and CurseForge both occasionally omit it, and a
        // missing number is not evidence of an unpopular project.
        return {
            hits: [...flat].sort((a, b) => (b.downloads ?? 0) - (a.downloads ?? 0)),
            truncated: flat.length >= limit,
            failed,
        };
    }

    // 'mixed': order each source by downloads, then interleave round-robin
    // rather than concatenating.
    //
    // Concatenating put every Modrinth result ahead of every Spigot one, and
    // because the page shows the first N hits, Modrinth alone filled the first
    // page and Spigot was invisible until the user paged forward. Interleaving
    // means both sources are on screen at once, which is the point of offering
    // two. The chips still let the user commit to one.
    const ordered = byRelevance
        ? settled.map((stream) => [...stream])
        : settled.map((stream) => [...stream].sort((a, b) => (b.downloads ?? 0) - (a.downloads ?? 0)));
    const hits: AddOnHit[] = [];
    const cursors = ordered.map(() => 0);
    let remaining = ordered.reduce((n, s) => n + s.length, 0);

    while (remaining > 0) {
        for (let i = 0; i < ordered.length; i += 1) {
            if (cursors[i] < ordered[i].length) {
                hits.push(ordered[i][cursors[i]]);
                cursors[i] += 1;
                remaining -= 1;
            }
        }
    }

    return { hits, truncated: hits.length >= limit, failed };
};

/** Re-exported so the version-count hook keeps a single import for Modrinth. */
export { countAddonsForVersion };
