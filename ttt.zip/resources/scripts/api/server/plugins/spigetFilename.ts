import axios from 'axios';

/**
 * A filename a human can read, derived from the same data the card showed.
 *
 * The download URL is Spiget's own `/{id}.jar`, and the CDN sends no
 * Content-Disposition, so there is no server-supplied name to use: the one the
 * panel invents is the one the user sees in their file manager and in
 * `/plugins`. `spigot-28140.jar` identifies nothing -- not the plugin, not the
 * version -- and two of them are indistinguishable at a glance.
 *
 * `spigotFilename` is therefore the single source of truth for the name, and
 * `spigotMarker` exists so the installed-detection can key off exactly what the
 * filename will be. Deriving both from one function is the point: when the
 * marker was built independently it stopped matching, and the "Installed" badge
 * silently disappeared for every Spigot plugin.
 *
 * The version is always placed after a hyphen that is followed by a digit. That
 * is what lets the installed-detection strip it back off again with
 * /-\d[\w.+-]*$/, so a name whose version happens to start with a letter
 * (`v2.0`) cannot leave the two permanently disagreeing.
 */

/**
 * Reduce a name to something safe for a filename on any platform.
 *
 * Plugin names come from users, and they contain spaces, slashes, colons and
 * occasionally characters no filesystem accepts. A leading dot or hyphen is
 * dropped too: a jar called `.jar` or `-foo.jar` is invisible or awkward
 * everywhere, and Windows additionally refuses a set of reserved device names.
 */
const sanitise = (value: string): string => {
    const cleaned = value
        .normalize('NFKD')
        // Strip combining marks so "Café" becomes "Cafe" rather than an
        // accented character that some filesystems and every zip tool
        // disagree about.
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^A-Za-z0-9._+-]+/g, '-')
        // Collapse runs of separators, and trim them from both ends.
        .replace(/[-_+]{2,}/g, '-')
        .replace(/^[-_+.]+|[-_+.]+$/g, '');

    return cleaned.slice(0, 80);
};

/** Windows refuses these as filenames whatever the extension. */
const RESERVED = new Set([
    'con', 'prn', 'aux', 'nul',
    'com1', 'com2', 'com3', 'com4', 'com5', 'com6', 'com7', 'com8', 'com9',
    'lpt1', 'lpt2', 'lpt3', 'lpt4', 'lpt5', 'lpt6', 'lpt7', 'lpt8', 'lpt9',
]);

const safeSegment = (value: string, fallback: string): string => {
    const clean = sanitise(value);

    if (clean === '' || RESERVED.has(clean.toLowerCase())) {
        return fallback;
    }

    return clean;
};

/**
 * The key the installed-list uses for a plugin, which is also the filename with
 * its version and extension removed.
 *
 * Kept next to spigotFilename so the two cannot drift apart: the whole reason
 * the badge broke is that they were written independently.
 */
export const spigotMarker = (name: string, id: number): string => safeSegment(name, `spigot-${id}`).toLowerCase();

/**
 * Build the jar filename for a Spigot project.
 *
 * `version` is the project's newest version name, which Spiget only exposes
 * through a per-version request. Pass null when it could not be fetched: the
 * name is still readable, just without the version.
 */
export const spigotFilename = (name: string, id: number, version?: string | null): string => {
    const base = safeSegment(name, `spigot-${id}`);

    // A leading "v" is dropped so the separator is always followed by a digit,
    // which is what makes the name reversible by the installed-detection.
    const cleanedVersion = version ? sanitise(version).replace(/^v/i, '') : '';

    if (cleanedVersion === '' || !/^\d/.test(cleanedVersion)) {
        return `${base}.jar`;
    }

    return `${base}-${cleanedVersion}.jar`;
};

/**
 * The project's newest version name, e.g. "5.5.71".
 *
 * The search result carries only a version id, and Spiget's resource document
 * embeds that version without its name, so one extra request is needed. It is
 * made at install time rather than per search result, because a search page of
 * twenty plugins would otherwise cost twenty extra requests to label files that
 * most viewers never install.
 *
 * A failure here is not fatal: the caller falls back to a name without a
 * version, which is still better than the resource id.
 */
export const spigotVersionName = async (resourceId: number, versionId: number | null): Promise<string | null> => {
    if (!versionId) {
        return null;
    }

    try {
        const { data } = await axios.get(`https://api.spiget.org/v2/resources/${resourceId}/versions/${versionId}`, {
            timeout: 15000,
            params: { fields: 'id,name' },
        });

        const name = typeof data?.name === 'string' ? data.name.trim() : '';

        return name === '' ? null : name;
    } catch (err) {
        return null;
    }
};
