import http from '@/api/http';
import { looksLikeJar, sizeOf } from './blob';

/**
 * CurseForge, through the panel's own proxy.
 *
 * Every request here goes to /api/client/plugins/curseforge/*, never to
 * api.curseforge.com. That is not a convenience:
 *
 *  - the key never reaches the browser. It is issued to a person and carries
 *    their quota, so a key in the bundle is a key in every visitor's devtools.
 *  - api.curseforge.com sends no CORS headers, so the browser would refuse the
 *    request before it left the page even if it had the key.
 *
 * CurseForge also hosts the Bukkit plugin category (classId 5), which is what
 * this source is pinned to. There is deliberately no separate "Bukkit" source:
 * dev.bukkit.org is a CurseForge/Overwolf property serving the same catalogue
 * behind the same credential, so a second field would be a second name for one
 * key.
 *
 * Set a key in Admin -> Settings -> Plugin Sources.
 */

export interface CurseForgeHit {
    id: number;
    slug: string | null;
    name: string;
    summary: string;
    downloads: number;
    iconUrl: string | null;
    fileId: number | null;
    fileName: string | null;
    latestVersion: string | null;
    gameVersions: string[];
    authors: (string | null)[];
}

export interface CurseForgeSearchOptions {
    limit?: number;
    offset?: number;
}

const rows = (data: any): CurseForgeHit[] => (Array.isArray(data?.hits) ? data.hits : []) as CurseForgeHit[];

export const searchCurseForge = async (
    query: string,
    opts: CurseForgeSearchOptions = {}
): Promise<{ hits: CurseForgeHit[]; total: number }> => {
    const { data } = await http.get('/api/client/plugins/curseforge/search', {
        params: { query, size: opts.limit ?? 20, index: opts.offset ?? 0 },
    });

    return { hits: rows(data), total: data?.total ?? 0 };
};

export interface CurseForgeVersion {
    id: number;
    name: string;
    createdAt: string;
    downloads: number;
    gameVersions: string[];
    fileName: string;
    size: number;
    installable: boolean;
}

/**
 * Every published file of a mod, newest first.
 *
 * Through the panel rather than api.curseforge.com, for the two reasons spelled
 * out at the top of this file: the key must never reach a browser, and
 * CurseForge sends no CORS headers, so a direct call would be refused before it
 * left the page.
 *
 * A CurseForge "file" is the same thing as a version -- one jar, one version
 * number -- so it maps onto the same normalised shape the other sources use.
 */
export const getCurseForgeVersions = async (modId: number): Promise<CurseForgeVersion[]> => {
    const { data } = await http.get(`/api/client/plugins/curseforge/detail/${modId}/files`);

    const body = data?.body?.data ?? data?.body ?? data;
    if (!Array.isArray(body)) return [];

    const versions: CurseForgeVersion[] = [];

    for (const row of body) {
        const id = Number(row?.id);
        const name = String(row?.displayName ?? row?.fileName ?? '').trim();

        if (!Number.isInteger(id) || id <= 0 || name === '') continue;

        versions.push({
            id,
            name,
            createdAt: String(row?.fileDate ?? ''),
            downloads: Number(row?.downloadCount ?? 0) || 0,
            gameVersions: Array.isArray(row?.gameVersions) ? row.gameVersions.map(String) : [],
            fileName: String(row?.fileName ?? ''),
            size: Number(row?.fileLength ?? 0) || 0,
            // A file with no download URL cannot be fetched, and CurseForge mixes
            // those in with the rest.
            installable: !!row?.downloadUrl,
        });
    }

    return versions;
};

/**
 * Metadata for one file. The panel holds the download URL; it is not returned to
 * the browser, because fetching it directly would need the key in the browser.
 */
export const getCurseForgeFile = async (
    modId: number,
    fileId: number
): Promise<{ fileName: string; size: number } | null> => {
    const { data } = await http.get(`/api/client/plugins/curseforge/detail/${modId}/files/${fileId}`);

    const body = data?.body?.data ?? data?.body ?? data;

    if (!body?.fileName) return null;

    return { fileName: body.fileName, size: body.fileLength ?? 0 };
};

/**
 * Download a jar through the panel.
 *
 * The panel has already checked the bytes against CurseForge's published
 * checksums by the time they arrive, and repeats the digests in headers so the
 * client can confirm it got what the panel verified. That second check is not
 * redundant: it is what catches a truncated or mangled response between the
 * panel and the browser, which a server-side check alone would miss.
 */
export const downloadCurseForgeJar = async (
    modId: number,
    fileId: number,
    onProgress?: (percent: number) => void
): Promise<{ blob: Blob; filename: string }> => {
    onProgress?.(15);

    const response = await http.get(`/api/client/plugins/curseforge/download/${modId}/files/${fileId}`, {
        responseType: 'blob',
        timeout: 300000,
        onDownloadProgress: (event) => {
            if (event.total) {
                onProgress?.(15 + Math.round((event.loaded / event.total) * 0.55));
            }
        },
    });

    const blob = response.data as Blob;

    if (!blob || sizeOf(blob) === 0) throw new Error('The download was empty.');

    if (!(await looksLikeJar(blob))) {
        throw new Error('The download was not a jar file (a web page came back instead).');
    }

    const expectedSize = Number(response.headers['x-jar-size'] ?? 0);
    if (expectedSize > 0 && sizeOf(blob) !== expectedSize) {
        throw new Error(
            `The download was truncated (expected ${expectedSize} bytes, received ${sizeOf(blob)}).`
        );
    }

    const filename = decodeURIComponent(
        String(response.headers['content-disposition'] ?? '').match(/filename="?([^";]+)"?/)?.[1] ?? `plugin-${modId}.jar`
    );

    onProgress?.(75);

    return { blob, filename };
};
