import axios from 'axios';
import { spigotFilename, spigotVersionName } from './spigetFilename';
import { looksLikeJar, sizeOf } from './blob';

/**
 * SpigotMC resources, via the public Spiget API (https://spiget.org).
 *
 * Spiget is used rather than scraping spigotmc.org directly for two reasons that
 * were verified before writing any of this:
 *
 *  - CORS. api.spiget.org sends `access-control-allow-origin: *`, so the browser
 *    can call it. The jar it redirects to does not: spigotmc.org answers 403 to
 *    a cross-origin GET of /resources/{id}/download.
 *  - The CDN. cdn.spiget.org serves the jar with CORS reflecting the origin, and
 *    is reachable directly.
 *
 * Two limitations are inherent to Spiget, not to this integration, and the UI
 * states them rather than hiding them:
 *
 *  - Only the LATEST published jar is fetchable cross-origin. The predictable
 *    path cdn.spiget.org/file/spiget-resources/{id}.jar serves the newest
 *    version; the per-version paths 404, and the version-scoped download route
 *    302s to spigotmc.org, which blocks us. So a Spigot install is always the
 *    resource's newest build, never the Minecraft-version-matched one.
 *  - No checksum. Modrinth publishes SHA-1 per file; Spiget publishes no hash
 *    for a version, so integrity here rests on the response being a real jar.
 *
 * Minecraft-version compatibility is also unavailable: `tested_versions` comes
 * back null for most modern resources, so results cannot be filtered by the
 * version the user picked in the version grid.
 */

const API = 'https://api.spiget.org/v2';
const CDN = 'https://cdn.spiget.org/file/spiget-resources';

export interface SpigetHit {
    id: number;
    name: string;
    description: string;
    downloads: number;
    /** Present only when the resource declares it; null for most. */
    tested_versions: string | null;
    /** Id of the resource's newest version. */
    version_id: number | null;
    rating: number | null;
    author: string | null;
    icon_url: string | null;
    external: boolean;
}

const asArray = (value: unknown): string[] => {
    if (Array.isArray(value)) return value.map(String);
    if (typeof value === 'string') return [value];

    return [];
};

const normalise = (raw: any): SpigetHit => ({
    id: raw.id,
    name: raw.name ?? `Resource ${raw.id}`,
    description: raw.description ?? '',
    downloads: raw.downloads ?? 0,
    tested_versions: raw.tested_versions ?? null,
    version_id: raw.version?.id ?? null,
    rating: raw.ratings?.average ?? null,
    author: raw.author?.name ?? null,
    icon_url: raw.icon_url ?? null,
    // "external" resources live on another site and have no jar here.
    external: raw.external === true,
});

const FIELDS = 'id,name,description,downloads,tested_versions,version,ratings,author,icon_url,external';

/**
 * No User-Agent header is set here, deliberately.
 *
 * `User-Agent` is on the Fetch spec's forbidden header list, so a browser
 * rejects any attempt to set it -- axios surfaces that as
 * "Headers User-Agent forbidden" and every Spiget search fails. Node allows it,
 * so a server-side test of this module passes and the browser still breaks; the
 * browser supplies its own User-Agent regardless. Spiget asks for a descriptive
 * one to rate-limit politely, which is a courtesy it can do without.
 */
const spiget = axios.create({
    timeout: 20000,
    headers: {
        Accept: 'application/json',
    },
});

export interface SpigetSearchOptions {
    limit?: number;
    offset?: number;
    sort?: 'downloads' | 'rating' | 'newest';
}

export interface SpigetSearchResult {
    hits: SpigetHit[];
    total: number;
}

export const searchSpigot = async (
    query: string,
    opts: SpigetSearchOptions = {}
): Promise<SpigetSearchResult> => {
    const limit = opts.limit ?? 20;
    const offset = opts.offset ?? 0;
    const sort = opts.sort === 'rating' ? '-rating' : opts.sort === 'newest' ? '-release_date' : '-downloads';
    const term = query.trim();

    // Spiget has no browse-all search route: /v2/search/resources/ with an empty
    // term answers 404, which is what the plugins page hits on first load because
    // it opens with no search term. /v2/resources is the browse route and returns
    // the same resource shape, sorted, so an empty query is served from there.
    const url = term ? `${API}/search/resources/${encodeURIComponent(term)}` : `${API}/resources`;

    const { data, headers } = await spiget.get<any[]>(url, {
        params: { size: limit, offset, sort, fields: FIELDS },
    });

    const pages = Number(headers['x-page-count'] ?? 0);
    const total = pages > 0 ? pages * limit : (data?.length ?? 0);

    return { hits: (data ?? []).map(normalise), total };
};

/** Full record for one resource; used to fill in a description before install. */
export const getSpigotResource = async (id: number): Promise<SpigetHit> => {
    const { data } = await spiget.get<any>(`${API}/resources/${id}`, { params: { fields: FIELDS } });

    return normalise(data);
};

export interface SpigetVersion {
    id: number;
    name: string;
    /** Unix milliseconds; 0 when Spiget omits it. */
    releasedAt: number;
    downloads: number;
}

/**
 * Every published version of a resource, newest first.
 *
 * Spiget paginates and caps `size`, so this asks for one generous page rather
 * than pretending it is the whole history. A resource with more versions than
 * that is not one anybody scrolls.
 *
 * Note what this can and cannot do: the list is complete, but only the NEWEST
 * jar is fetchable. cdn.spiget.org serves `/{id}.jar` for the latest build and
 * 404s for the per-version paths, and the version-scoped download route 302s to
 * spigotmc.org, which refuses a cross-origin GET. So every row here is
 * installable, but only the first one is installable from the browser -- the rest
 * go through the panel, which has no such restriction.
 */
export const getSpigotVersions = async (id: number, limit = 50): Promise<SpigetVersion[]> => {
    const { data } = await spiget.get<any>(`${API}/resources/${id}/versions`, {
        params: { size: Math.min(Math.max(limit, 1), 50), offset: 0, sort: '-releaseDate' },
    });

    if (!Array.isArray(data)) return [];

    return data
        .map((raw) => ({
            id: Number(raw?.id),
            name: String(raw?.name ?? '').trim(),
            releasedAt: Number(raw?.releaseDate ?? 0) || 0,
            downloads: Number(raw?.downloads ?? 0) || 0,
        }))
        .filter((v) => Number.isInteger(v.id) && v.id > 0 && v.name !== '');
};

/**
 * Direct, cross-origin-downloadable URL for the resource's newest jar.
 *
 * Deliberately not the /download endpoint: that 302s to spigotmc.org, which
 * returns 403 to a cross-origin GET.
 */
export const spigotJarUrl = (id: number): string => `${CDN}/${id}.jar`;

/**
 * Fetch a Spigot jar.
 *
 * There is no published checksum to check against, so verification is limited to
 * what can actually be established: the request succeeded, the body is a
 * non-empty ZIP archive. A jar always begins with "PK"; an HTML error page from
 * a CDN edge does not, which is the failure this catches.
 */
export const downloadSpigotJar = async (
    id: number,
    name: string,
    versionId: number | null,
    onProgress?: (percent: number) => void
): Promise<{ blob: Blob; filename: string }> => {
    onProgress?.(15);

    // Spiget's CDN serves the jar as "/{id}.jar" with no Content-Disposition, so
    // there is no name to read off the response. It is built from the project's
    // own name and newest version instead of the resource id, which identifies
    // nothing to whoever finds the file later.
    const version = await spigotVersionName(id, versionId);
    const filename = spigotFilename(name, id, version);

    const response = await axios.get(spigotJarUrl(id), {
        responseType: 'blob',
        timeout: 60000,
        onDownloadProgress: (event) => {
            if (event.total) {
                onProgress?.(15 + Math.round((event.loaded / event.total) * 0.55));
            }
        },
    });

    const blob = response.data as Blob;

    if (!blob || sizeOf(blob) === 0) {
        throw new Error('The download was empty.');
    }

    if (!(await looksLikeJar(blob))) {
        throw new Error('The download was not a jar file (a web page came back instead).');
    }

    onProgress?.(75);

    return { blob, filename };
};
