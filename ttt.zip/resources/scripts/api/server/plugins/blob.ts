/**
 * Small helpers for the bytes a download comes back as.
 *
 * axios returns a real Blob in a browser but a Node Buffer when the same module
 * is exercised from a test harness, and only Blob has arrayBuffer(). Both the
 * checksum verification and the "is this actually a jar" check read raw bytes, so
 * the conversion lives here rather than being re-implemented with a cast that
 * works in one runtime and throws in the other.
 */

export type DownloadedBytes = Blob | ArrayBuffer | Uint8Array | string;

export const toArrayBuffer = async (data: DownloadedBytes): Promise<ArrayBuffer> => {
    const candidate = data as Blob;

    if (typeof candidate.arrayBuffer === 'function') {
        return candidate.arrayBuffer();
    }

    if (data instanceof ArrayBuffer) {
        return data;
    }

    if (typeof data === 'string') {
        // Node's axios has no real "blob" response type and hands back a string
        // instead. The earlier version reached this point, built a Uint8Array
        // from a string, got zero bytes, and reported "not a jar" for a perfectly
        // good download -- so the type is handled rather than swallowed.
        return new TextEncoder().encode(data).buffer as ArrayBuffer;
    }

    // A Node Buffer is a Uint8Array, so this covers it.
    const view = new Uint8Array(data as Uint8Array);

    if (view.byteLength === 0) {
        throw new Error('The download produced no readable bytes.');
    }

    return view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength) as ArrayBuffer;
};

/** First bytes as a byte array, for magic-number checks. */
export const head = async (data: DownloadedBytes, length: number): Promise<Uint8Array> => {
    const buffer = await toArrayBuffer(data);

    return new Uint8Array(buffer, 0, Math.min(length, buffer.byteLength));
};

/** True when the data starts with "PK", which every jar and zip does. */
export const looksLikeJar = async (data: DownloadedBytes): Promise<boolean> => {
    const first = await head(data, 2);

    return first.length === 2 && first[0] === 0x50 && first[1] === 0x4b;
};

export const sizeOf = (data: DownloadedBytes): number => {
    if (typeof data === 'string') return new TextEncoder().encode(data).byteLength;
    if (data instanceof ArrayBuffer) return data.byteLength;

    const size = (data as Blob).size;

    return typeof size === 'number' ? size : (data as Uint8Array).byteLength;
};
