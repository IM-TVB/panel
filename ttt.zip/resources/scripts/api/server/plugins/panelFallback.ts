import http from '@/api/http';
import { looksLikeJar, sizeOf, toArrayBuffer } from './blob';
import { AddOnHit } from './providers';

/**
 * The second route for a jar, and the last resort when there is no route left.
 *
 * Every keyless source is normally downloaded by the browser straight from the
 * provider's CDN, which is the fast path and keeps the panel out of the loop.
 * That path can fail for reasons that have nothing to do with the provider: a
 * privacy extension that rewrites third-party requests, a corporate proxy that
 * only allows its own allowlist, a network that blocks the CDN, a browser
 * refusing a mixed-content download. When it does, the user is left with an
 * error and no jar, even though the panel could have fetched the identical file
 * server-side where none of that applies.
 *
 * So the order is: download directly, and if that throws for any reason, ask the
 * panel to make the same request and hand the bytes back. If that also fails,
 * the user gets a link to the provider's own page, because a person can always
 * fetch a file a machine in two places could not -- and a dead end with no
 * forward route is the one outcome worth engineering against.
 *
 * The panel is not a general proxy here. It is asked for a named project, never
 * a URL, and it builds the request from a fixed set of hosts; see
 * PublicProviderProxy.
 */

/** What a provider download produces, whichever route it came by. */
export interface DownloadedJar {
    blob: Blob;
    filename: string;
}

/**
 * The provider's own page for a project.
 *
 * This is the last tier, and the only one that does not depend on the panel
 * working at all. It is also the only tier that can rescue a project whose jar is
 * published off-site, which is why it is built from whatever identity the search
 * result carries rather than from a download URL.
 *
 * Returns null when the search result has no usable identifier, which is the
 * honest answer: there is no page to send anyone to.
 */
export const providerPageUrl = (hit: AddOnHit): string | null => {
    if (hit.provider === 'modrinth' && hit.projectId) {
        // /project/ resolves for every project type, so a mod and a plugin both
        // land on the right page without this needing to know which it is.
        return `https://modrinth.com/project/${encodeURIComponent(hit.projectId)}`;
    }

    if (hit.provider === 'spigot' && hit.spigetId) {
        return `https://www.spigotmc.org/resources/${hit.spigetId}/`;
    }

    if (hit.provider === 'hangar' && hit.hangarSlug) {
        // Already namespaced as owner/slug, which is the shape Hangar's own URLs
        // take. Each half is encoded so a project name cannot become a segment.
        const parts = hit.hangarSlug.split('/').filter((p) => p !== '');

        if (parts.length === 0) {
            return null;
        }

        // A dot segment is refused outright rather than encoded. encodeURIComponent
        // leaves "." alone -- it is an unreserved character -- so "own/../../secret"
        // would survive encoding as a literal traversal. Escaping the dots instead
        // is not reliable either, since servers commonly normalise %2E%2E. The
        // honest answer for a slug containing one is that there is no page to offer.
        if (parts.some((part) => part === '.' || part === '..')) {
            return null;
        }

        return `https://hangar.papermc.io/${parts.map(encodeURIComponent).join('/')}`;
    }

    if (hit.provider === 'curseforge') {
        const raw = hit.raw as { slug?: string | null };

        return raw.slug ? `https://www.curseforge.com/bukkit/plugins/${encodeURIComponent(raw.slug)}` : null;
    }

    return null;
};

/** The provider's display name, for the fallback button. */
export const providerLabel = (hit: AddOnHit): string => {
    switch (hit.provider) {
        case 'modrinth':
            return 'Modrinth';
        case 'spigot':
            return 'Spigot';
        case 'hangar':
            return 'Hangar';
        case 'curseforge':
            return 'CurseForge';
        default:
            return hit.provider;
    }
};

/**
 * Thrown when neither download route produced a jar.
 *
 * Carries the provider's page so the caller can offer a way forward instead of
 * only reporting a failure. The original two errors are kept on `direct` and
 * `viaPanel` because "the CDN refused it and so did the panel" is a very
 * different thing for whoever has to fix it than either message alone.
 */
export class AddOnUnavailableError extends Error {
    public readonly webUrl: string | null;

    public readonly direct: unknown;

    public readonly viaPanel: unknown;

    constructor(message: string, direct: unknown, viaPanel: unknown) {
        super(message);
        this.name = 'AddOnUnavailableError';
        this.webUrl = null;
        this.direct = direct;
        this.viaPanel = viaPanel;
    }

    /** Attach the page once the hit is known, keeping the error a single object. */
    public withPage(url: string | null): this {
        (this as { webUrl: string | null }).webUrl = url;

        return this;
    }
}

const hex = (buffer: ArrayBuffer): string =>
    Array.from(new Uint8Array(buffer))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');

/**
 * Fetch a jar through the panel.
 *
 * The identifiers are the same ones the direct route would have used, so the
 * panel resolves the identical file -- it does not pick a different version.
 * That matters for Modrinth in particular: re-resolving "latest" server-side
 * would hand back a jar for whatever platform is newest, which is frequently not
 * the one the user picked.
 *
 * `filename` overrides the name the panel suggests. Spigot needs this, because
 * the panel only knows the resource id and the real name is built from the
 * project's own name and version.
 */
export const downloadViaPanel = async (
    hit: AddOnHit,
    identifiers: Record<string, string | number>,
    opts: {
        /**
         * Overrides the name the panel suggests. Accepts a function because
         * working one out can cost a request, and there is no reason to pay it on
         * the direct route -- Spigot's real name needs the project's version,
         * which the panel cannot know and the direct route already fetched.
         */
        filename?: string | (() => string | Promise<string>);
        onProgress?: (message: string) => void;
    } = {}
): Promise<DownloadedJar> => {
    const { onProgress } = opts;

    onProgress?.(`Asking the panel to download ${hit.title}…`);

    const response = await http.get(`/api/client/plugins/public/${hit.provider}/download`, {
        params: identifiers,
        responseType: 'blob',
        timeout: 300000,
        onDownloadProgress: (event) => {
            if (event.total) {
                const percent = 15 + Math.round((event.loaded / event.total) * 0.55);
                onProgress?.(`Panel is downloading ${hit.title}… ${percent}%`);
            }
        },
    });

    const blob = response.data as Blob;

    if (!blob || sizeOf(blob) === 0) {
        throw new Error('The panel’s copy of the download was empty.');
    }

    if (!(await looksLikeJar(blob))) {
        throw new Error('The panel’s download was not a jar file (a web page came back instead).');
    }

    // The panel has already checked the digest it published, and says which it
    // checked. Repeating it here catches a truncation on the panel-to-browser
    // hop, which is the one leg nothing has verified.
    const expectedSize = Number(response.headers['x-jar-size'] ?? 0);
    if (expectedSize > 0 && sizeOf(blob) !== expectedSize) {
        throw new Error(
            `The panel’s copy was truncated (expected ${expectedSize} bytes, received ${sizeOf(blob)}).`
        );
    }

    const buffer = await toArrayBuffer(blob);

    for (const [header, algorithm] of [
        ['x-jar-sha1', 'SHA-1'],
        ['x-jar-sha256', 'SHA-256'],
    ] as const) {
        const expected = response.headers[header];

        if (typeof expected !== 'string' || expected === '' || expected === '0') {
            continue;
        }

        if (!globalThis.crypto?.subtle) {
            throw new Error(
                'This browser cannot verify downloads (crypto.subtle is unavailable). Serve the panel over HTTPS.'
            );
        }

        const actual = hex(await crypto.subtle.digest(algorithm, buffer));

        if (actual.toLowerCase() !== expected.toLowerCase()) {
            throw new Error(
                `The panel’s download did not match the ${algorithm} it published, so it was not installed.`
            );
        }
    }

    const header = String(response.headers['content-disposition'] ?? '');
    const suggested = decodeURIComponent(header.match(/filename="?([^";]+)"?/)?.[1] ?? '');

    const override = typeof opts.filename === 'function' ? await opts.filename() : opts.filename;
    const filename = override ?? (suggested !== '' ? suggested : `${hit.title}.jar`);

    return { blob, filename };
};

/**
 * Download a jar, falling back to the panel if the direct attempt fails.
 *
 * Every failure counts as a reason to retry, not just a network error. A
 * checksum mismatch and a 403 both mean the browser has no usable file, and
 * whether the panel's server-side request will fare better is not something the
 * client can predict. Retrying costs one request; giving up costs the user their
 * plugin.
 *
 * If the panel route fails too, the error is replaced with one carrying the
 * provider's page -- but only after both original errors are attached, so the
 * cause is not lost.
 */
export const withPanelFallback = async (
    hit: AddOnHit,
    direct: () => Promise<DownloadedJar>,
    identifiers: Record<string, string | number>,
    opts: {
        filename?: string | (() => string | Promise<string>);
        onProgress?: (message: string) => void;
    } = {}
): Promise<DownloadedJar> => {
    const { onProgress } = opts;

    try {
        return await direct();
    } catch (directError) {
        onProgress?.(
            `The direct download did not work — asking the panel to fetch ${hit.title} instead…`
        );

        try {
            return await downloadViaPanel(hit, identifiers, opts);
        } catch (panelError) {
            throw new AddOnUnavailableError(
                `Could not download ${hit.title} from ${providerLabel(hit)}.`,
                directError,
                panelError
            ).withPage(providerPageUrl(hit));
        }
    }
};
