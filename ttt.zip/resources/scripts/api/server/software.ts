import { AxiosError } from 'axios';
import http from '@/api/http';

/**
 * What a single piece of software looks like to the picker.
 *
 * Note the shape is derived server-side from the eggs that actually exist in
 * this server's nest (see SoftwareService). There is deliberately no client-side
 * catalogue: a hardcoded list would offer software this panel has no install
 * script for, and selecting it would silently do nothing.
 */
export interface SoftwareOption {
    egg_id: number;
    name: string;
    description: string;
    image: string;
    supports: 'plugins' | 'mods';
    install_dir: string;
    badge: string;
    version_variable: string | null;
    version: string | null;
    version_default: string | null;
    version_editable: boolean;
    version_rules: string | null;
    is_current: boolean;
}

export interface BackupState {
    /** 0 disables backups outright; see SoftwareService::backupState. */
    backup_limit: number;
    /** False when the limit is 0, i.e. no backup can be created at all. */
    can_create_backup: boolean;
    /** How many backups could actually be restored. */
    backup_count: number;
}

export interface SoftwareResponse {
    current: SoftwareOption & { can_switch: boolean };
    options: SoftwareOption[];
    can_switch: boolean;
    backups: BackupState;
    /**
     * Echoed after a change so the client can report what was actually asked
     * for. Optional because GET /software does not include it -- only the
     * response to a change does.
     */
    delete_files?: boolean;
}

export interface ChangeSoftwareRequest {
    egg_id: number;
    version?: string;
    /**
     * Optional. The backup's uuid rather than a row id, because the backup
     * transformer never exposes the numeric id. When sent it must name a real,
     * restorable backup belonging to this server.
     *
     * A software change is a reinstall that deletes the server's files, so this
     * is offered rather than demanded: a server with the default backup limit of
     * 0 can never produce one, and requiring it made the change impossible.
     */
    backup?: string;
    /**
     * Whether the reinstall wipes what is already in the directory.
     *
     * Omitted means yes, which is what a reinstall has always done. Sent
     * explicitly rather than left to the default so the choice the operator made
     * is visible in the request rather than inferred from its absence.
     */
    delete_files?: boolean;
    acknowledged: boolean;
}

export const getSoftware = async (identifier: string): Promise<SoftwareResponse> => {
    const { data } = await http.get<SoftwareResponse>(`/api/client/servers/${identifier}/software`);

    return data;
};

export const changeSoftware = async (
    identifier: string,
    payload: ChangeSoftwareRequest
): Promise<SoftwareResponse> => {
    const { data } = await http.post<SoftwareResponse>(
        `/api/client/servers/${identifier}/software/change`,
        payload
    );

    return data;
};

/**
 * Pulls the human-readable message out of a Pterodactyl error envelope so the
 * confirmation dialog can explain exactly what was refused.
 */
export const changeSoftwareError = (error: unknown): string => {
    const err = error as AxiosError<any>;
    const errors = err?.response?.data?.errors;

    if (Array.isArray(errors) && errors.length > 0) {
        return errors.map((e: any) => e.detail || e.field).join(' ');
    }

    return 'Could not change the server software.';
};
