import { AxiosError } from 'axios';
import http from '@/api/http';

/**
 * A user's own profile picture.
 *
 * Multipart rather than a JSON body, because the file is the request. The url is
 * returned rather than assumed, so the client shows the stored file and not the
 * one the browser happened to hold -- they differ whenever the bytes were
 * re-encoded, and the stored name is content-addressed.
 */

/**
 * The content type for a multipart post, and it is not optional.
 *
 * The shared `http` instance sets `Content-Type: application/json` as a default,
 * and axios's own multipart handling only kicks in *after* transformRequest has
 * already run. That transform does this:
 *
 *     if (isFormData) {
 *         return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
 *     }
 *
 * So with the instance default in place the FormData is flattened to a plain
 * object and stringified. A File has no own enumerable properties, so it
 * serialises to `{}` and the request leaves the browser as the literal body
 * `{"image":{}}`. PHP decodes that to `image => []`, an empty array, the
 * `required` rule fails, and the user is told "Choose a picture to upload." --
 * which is what the first version of this did, and it is why nothing about the
 * file input, the controller or the service was at fault.
 *
 * Declaring multipart here means hasJSONContentType is false and the FormData
 * survives the transform untouched. axios's adapter then drops the header
 * entirely for FormData in a browser, so the boundary is the browser's to add --
 * this does not hardcode a content type that is missing its boundary, which is
 * the failure mode that never parses at all.
 */
const MULTIPART = { headers: { 'Content-Type': 'multipart/form-data' } };

/** Upload a picture, returning the url it is now served from. */
export const setAvatar = async (file: File): Promise<string | null> => {
    const body = new FormData();

    body.append('image', file);

    const { data } = await http.post<{ url: string | null }>('/api/client/account/avatar', body, MULTIPART);

    return data?.url ?? null;
};

/** Remove the picture, so the identicon comes back. */
export const clearAvatar = async (): Promise<void> => {
    await http.post('/api/client/account/avatar/reset');
};

/** What is currently set, for a page that did not boot from window.PterodactylUser. */
export const getAvatar = async (): Promise<{ url: string | null; has_image: boolean }> => {
    try {
        const { data } = await http.get<{ url: string | null; has_image: boolean }>('/api/client/account/avatar');

        return data;
    } catch (e) {
        if (e instanceof AxiosError && e.response?.status === 404) {
            return { url: null, has_image: false };
        }

        throw e;
    }
};
