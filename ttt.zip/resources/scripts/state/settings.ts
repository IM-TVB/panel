import { action, Action } from 'easy-peasy';

export interface SiteSettings {
    name: string;
    locale: string;
    recaptcha: {
        enabled: boolean;
        siteKey: string;
    };
    /**
     * The sidebar logo. url is null when no logo is set, which is what tells the
     * navigation to draw its initial-letter tile -- so null means "use the
     * default" and never "an image that failed to load".
     */
    logo: {
        url: string | null;
    };
}


export interface SettingsStore {
    data?: SiteSettings;
    setSettings: Action<SettingsStore, SiteSettings>;
}

const settings: SettingsStore = {
    data: undefined,

    setSettings: action((state, payload) => {
        state.data = payload;
    }),
};

export default settings;
