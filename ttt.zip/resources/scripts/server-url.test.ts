/**
 * The address in the bar, when you go to a server.
 *
 * A server has three names in this panel, and the API sends all three:
 *
 *   uuid                  7641b3f2-31d2-40af-ae67-7e8a3934d26c
 *   uuidShort             7641b3f2
 *   identifier            serv_oza3h4rr2jak7lthp2fdsngsnq
 *
 * The third is a *realtime* identifier, not a column: HasRealtimeIdentifier
 * derives it from the uuid's bytes every time it is read, so it is
 * `serv_` + base32 of the uuid. It is long, and it is the one the dashboard
 * card and the console's add-on strip used to link with -- so opening a server
 * put `/server/serv_oza3h4rr2jak7lthp2fdsngsnq` in the address bar.
 *
 * The panel resolves all three (SubstituteClientBindings picks the column from
 * the shape of the value: `serv_` prefix, 8 characters, or 36), so the choice
 * is only about which one to show. The short one is the one to show: it is
 * what a person reads out loud, pastes into a chat, or reads over a call. The
 * panel's own search modal already linked with it.
 *
 * Which of the two API fields carries the short form depends on the
 * `new_server_identifiers` feature flag: while it is off, `identifier` is the
 * short uuid and `server_identifier` is the long one, and the client maps them
 * to `server.id` and `server.identifier` respectively. So `server.id` is the
 * field to link with -- it is the short uuid today, and it stays a valid
 * address if the flag is ever turned on.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

/**
 * Comments stripped before scanning: the note above explains the failure in
 * terms of the very identifiers the assertions are written against, so an
 * unstripped scan reads the explanation as the bug.
 */
const code = (p: string) => read(p).replace(/\/\*[\s\S]*?\*\//g, '');

const card = code('components/dashboard/ServerRow.tsx');
const addons = code('components/server/console/InstalledAddons.tsx');
const api = code('api/server/getServer.ts');

describe('a server is linked to by its short name', () => {
    it('the dashboard card uses the short id', () => {
        expect(card).toMatch(/to=\{`\/server\/\$\{server\.id\}`\}/);
        // The long form is the thing being got rid of.
        expect(card).not.toMatch(/to=\{`\/server\/\$\{server\.identifier\}`\}/);
    });

    it('and so does the console add-on strip', () => {
        // Otherwise the URL goes short and then long again in one click, and
        // the rest of the session is spent in the long form.
        expect(addons).toMatch(/to=\{`\/server\/\$\{server\?\.id\}\/plugins`\}/);
        expect(addons).not.toMatch(/to=\{`\/server\/\$\{server\?\.identifier\}\/plugins`\}/);
    });

    it('the client maps the API field it wants to `id`', () => {
        // The API sends the short uuid in `identifier` and the long one in
        // `server_identifier`; the client calls them `id` and `identifier`.
        // Getting this backwards is what would put the long one in the link.
        expect(api).toMatch(/id: data\.identifier,/);
        expect(api).toMatch(/identifier: data\.server_identifier,/);
    });

    it('the API path keeps using the long identifier', () => {
        // The API path is not an address anyone reads, and the software lookup
        // is keyed on the server's own identifier. Only the links change.
        expect(addons).toMatch(/getSoftware\(server!\.identifier\)/);
    });
});
