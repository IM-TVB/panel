/**
 * The account page, in the same modern style as the subuser surfaces.
 *
 * The boxes on the account page are the stock ContentBox, and they had the
 * problem the whole theme has: the box paints itself through twin's `css`
 * prop, which compiles to a style object and puts no class name in the DOM.
 * The light palette's remap for `bg-neutral-700` therefore had nothing to
 * match, and the boxes stayed the stock dark slab on a light page.
 *
 * The stylesheet already had a rule for exactly that case -- section 6,
 * `.aternos-blue .rounded.bg-neutral-700` -- and it was dead for this
 * component, because the class names it selects are not in the DOM.
 *
 * So ContentBox now carries a literal class, the way the modal and the
 * permission groups do, and the palette is applied to that. Only the account
 * section uses ContentBox -- the overview, the API credentials and the SSH
 * keys -- so the change stops there.
 *
 * The two things that are easy to get wrong are pinned here: the label inside
 * the card, and the grid the four boxes sit in.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const read = (p: string) => readFileSync(join(__dirname, p), 'utf8');

/**
 * Comments stripped before scanning: the note above names `bg-neutral-700` and
 * the css prop in order to explain the failure, so an unstripped scan reads the
 * explanation as the thing being asserted.
 */
const code = (p: string) => read(p).replace(/\/\*[\s\S]*?\*\//g, '');

const box = code('components/elements/ContentBox.tsx');
const page = code('components/dashboard/AccountOverviewContainer.tsx');
const avatar = code('components/dashboard/forms/UpdateAvatarForm.tsx');
const css = code('assets/aternos.css');

describe('the account page is a set of cards', () => {
    it('the box carries a class the stylesheet can reach', () => {
        // Without it the box is a dark slab in the light theme, and nothing
        // fails -- the stylesheet's rule for it simply never matches.
        expect(box).toMatch(/className=\{'at-card'\}/);
        expect(box).toMatch(/className=\{'at-card__title'\}/);
    });

    it('and the stylesheet has rules for both', () => {
        expect(css).toMatch(/\.at-card \{[^}]*background-color:/);
        expect(css).toMatch(/\.at-card__title \{[^}]*font-size:/);
    });

    it('the card keeps the stock border treatment', () => {
        // `borderColor` is what draws the coloured top edge, and it is
        // upstream's own prop. Dropping it would be a behaviour change made
        // for the sake of a restyle.
        expect(box).toMatch(/borderColor && tw`border-t-4`/);
    });

    it('the profile picture sits in a ring', () => {
        expect(avatar).toContain('at-account__avatar');
        expect(css).toMatch(/\.at-account__avatar \{[^}]*border:/);
    });
});

describe('the labels inside a card are legible', () => {
    it('the label is reached by tag, not by class', () => {
        // Label is a styled component, so its `text-neutral-200` is inlined and
        // never reaches the DOM as a class. The light palette's remap for it
        // has nothing to match, and the label stayed a very light grey on a
        // very light card. The tag is in the DOM either way.
        expect(css).toMatch(/\.aternos-blue \.at-card label \{[^}]*color:/);
    });

    it('and so is the help text under a field', () => {
        expect(css).toMatch(/\.aternos-blue \.at-card \.input-help \{[^}]*color:/);
    });

    it('dark mode keeps the stock label', () => {
        // The stock dark label is gray-200 on gray-700 and reads perfectly
        // well. Overriding it for symmetry would make it worse.
        expect(css).not.toMatch(/\.aternos-dark \.at-card label/);
    });
});

describe('the four boxes are laid out as a grid', () => {
    it('two columns, not three', () => {
        // Four boxes in three columns leaves the last one stranded on a row of
        // its own, which reads as an afterthought. Two gives a balanced 2x2.
        expect(page).toMatch(/grid-cols-1 sm:grid-cols-2/);
        expect(page).not.toMatch(/lg:grid-cols-3/);
    });

    it('and the spacing is a gap, not hand-set margins', () => {
        expect(page).toMatch(/gap-5/);
        expect(page).not.toMatch(/sm:ml-8/);
        expect(page).not.toMatch(/md:ml-8/);
    });
});
