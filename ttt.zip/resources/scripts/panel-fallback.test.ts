/**
 * The fallback chain: direct download, then the panel, then the provider's page.
 *
 * The middle tier is the point of this file. A direct browser download fails for
 * reasons that have nothing to do with the provider -- an extension that rewrites
 * third-party requests, a proxy with its own allowlist, a blocked CDN -- and the
 * user should still get their jar, because the panel can make the same request
 * where none of that applies.
 *
 * The last tier matters just as much. Both routes failing must not leave a dead
 * end, so the error that escapes carries the provider's own page. What is easy to
 * get wrong here is quietly succeeding: a test that asserts "the fallback ran"
 * without also asserting the panel was *not* used when the direct route worked
 * passes just as happily against a wrapper that always calls the panel.
 */

import {
    AddOnUnavailableError,
    downloadViaPanel,
    providerLabel,
    providerPageUrl,
    withPanelFallback,
} from './api/server/plugins/panelFallback';
import { AddOnHit } from './api/server/plugins/providers';

// Typed loosely on purpose: these tests build deliberately partial hits, and
// AddOnHit.raw is a union of four provider shapes that no partial literal
// satisfies. The cast at the end is the honest description of what a search
// result looks like by the time the UI sees it.
const hit = (over: Record<string, unknown> = {}): AddOnHit =>
    ({
        key: 'modrinth:luckperms',
        provider: 'modrinth',
        title: 'LuckPerms',
        description: '',
        downloads: 1,
        iconUrl: null,
        projectId: 'luckperms',
        raw: {},
        ...over,
    }) as AddOnHit;

/** A jar blob that starts with "PK", which is what looksLikeJar checks for. */
const jarBlob = () => new Blob([new Uint8Array([0x50, 0x4b, 3, 4])], { type: 'application/java-archive' });

describe('providerPageUrl', () => {
    it('builds a real page for each source', () => {
        expect(providerPageUrl(hit())).toBe('https://modrinth.com/project/luckperms');
        expect(providerPageUrl(hit({ provider: 'spigot', projectId: undefined, spigetId: 28140 }))).toBe(
            'https://www.spigotmc.org/resources/28140/'
        );
        expect(providerPageUrl(hit({ provider: 'hangar', projectId: undefined, hangarSlug: 'ViaVersion/ViaBackwards' }))).toBe(
            'https://hangar.papermc.io/ViaVersion/ViaBackwards'
        );
        expect(providerPageUrl(hit({ provider: 'curseforge', projectId: undefined, raw: { slug: 'essentialx' } }))).toBe(
            'https://www.curseforge.com/bukkit/plugins/essentialx'
        );
    });

    it('returns null rather than a broken link when there is no identity', () => {
        // A link to a page that 404s is worse than no link: it looks like a way
        // out and is not one.
        expect(providerPageUrl(hit({ projectId: undefined }))).toBeNull();
        expect(providerPageUrl(hit({ provider: 'spigot', projectId: undefined }))).toBeNull();
        expect(providerPageUrl(hit({ provider: 'curseforge', projectId: undefined, raw: {} }))).toBeNull();
    });

    it('cannot be talked into naming another host', () => {
        // Asserted on the parsed host rather than by substring. Note what this
        // does and does not prove: with a fixed base per provider the host was
        // never steerable in the first place, so this is a guard against someone
        // later building the URL by concatenation. The encoding earns its place
        // elsewhere, in the two cases below.
        const attempts = ['evil.example.com/x', '//evil.example.com', 'https://evil.example.com', '@evil.example.com'];

        for (const attempt of attempts) {
            const url = providerPageUrl(hit({ projectId: attempt }));

            expect(url).not.toBeNull();
            expect(new URL(url as string).host).toBe('modrinth.com');
        }
    });

    it('will not let a project id append a query or a fragment', () => {
        // https://modrinth.com/project/luckperms?x=1 would silently drop
        // everything after the "?" and land the user somewhere else entirely.
        for (const attempt of ['luckperms?x=1', 'luckperms#frag']) {
            const parsed = new URL(providerPageUrl(hit({ projectId: attempt })) as string);

            expect(parsed.search).toBe('');
            expect(parsed.hash).toBe('');
            expect(parsed.pathname).toContain('luckperms');
        }
    });

    it('will not let a slug part walk up the path', () => {
        // Hangar is the one place parts are joined with "/", so this is the one
        // place a part could otherwise add segments of its own. encodeURIComponent
        // does not help here: "." is unreserved, so it passes through untouched.
        // Refusing the link is the only honest answer.
        for (const slug of ['own/../../secret', 'own/..', '../admin', 'own/./x']) {
            expect(providerPageUrl(hit({ provider: 'hangar', projectId: undefined, hangarSlug: slug }))).toBeNull();
        }
    });

    it('still links an ordinary namespaced slug', () => {
        // The refusal above must not cost the normal case its page.
        expect(providerPageUrl(hit({ provider: 'hangar', projectId: undefined, hangarSlug: 'ViaVersion/ViaBackwards' }))).toBe(
            'https://hangar.papermc.io/ViaVersion/ViaBackwards'
        );
        expect(providerPageUrl(hit({ provider: 'hangar', projectId: undefined, hangarSlug: 'Vault' }))).toBe(
            'https://hangar.papermc.io/Vault'
        );
    });

    it('encodes each part of a namespaced slug separately', () => {
        // Hangar slugs are owner/slug, so the separator must survive while a part
        // cannot introduce a segment of its own.
        expect(providerPageUrl(hit({ provider: 'hangar', projectId: undefined, hangarSlug: 'own/er/slug' }))).toBe(
            'https://hangar.papermc.io/own/er/slug'
        );
    });
});

describe('providerLabel', () => {
    it('names every source in the form the button uses', () => {
        expect(providerLabel(hit())).toBe('Modrinth');
        expect(providerLabel(hit({ provider: 'spigot' }))).toBe('Spigot');
        expect(providerLabel(hit({ provider: 'hangar' }))).toBe('Hangar');
        expect(providerLabel(hit({ provider: 'curseforge' }))).toBe('CurseForge');
    });
});

describe('withPanelFallback', () => {
    it('uses the direct download and does not bother the panel', async () => {
        const get = jest.spyOn(require('@/api/http').default, 'get');
        const direct = jest.fn().mockResolvedValue({ blob: jarBlob(), filename: 'LuckPerms-5.5.85.jar' });

        const result = await withPanelFallback(hit(), direct, { versionId: 'abc' });

        expect(result.filename).toBe('LuckPerms-5.5.85.jar');
        expect(direct).toHaveBeenCalledTimes(1);
        // The whole saving of the panel route is that it is not used when the
        // fast path works. A wrapper that always called it would still pass the
        // assertions above.
        expect(get).not.toHaveBeenCalled();
        get.mockRestore();
    });

    it('asks the panel when the direct download fails', async () => {
        const get = jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: jarBlob(),
            headers: {
                'content-disposition': 'attachment; filename="LuckPerms-5.5.85.jar"',
                'x-jar-size': '4',
            },
        });

        const direct = jest.fn().mockRejectedValue(new Error('blocked by extension'));
        const result = await withPanelFallback(hit(), direct, { versionId: 'abc' });

        expect(result.filename).toBe('LuckPerms-5.5.85.jar');
        expect(direct).toHaveBeenCalledTimes(1);
        expect(get).toHaveBeenCalledWith(
            '/api/client/plugins/public/modrinth/download',
            expect.objectContaining({ params: { versionId: 'abc' } })
        );
        get.mockRestore();
    });

    it('asks the panel for a project, never for a url', async () => {
        const get = jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: jarBlob(),
            headers: { 'x-jar-size': '4' },
        });

        await withPanelFallback(hit(), () => Promise.reject(new Error('nope')), { versionId: 'abc' });

        // The route carries the provider and the panel builds every URL itself.
        // If a url could ride along here, the endpoint would be an open proxy.
        const [, config] = get.mock.calls[0] as [string, { params: Record<string, unknown> }];

        expect(Object.keys(config.params)).toEqual(['versionId']);
        expect(JSON.stringify(config.params)).not.toContain('http');
        get.mockRestore();
    });

    it('falls back for a checksum failure too, not only a network error', async () => {
        const get = jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: jarBlob(),
            headers: { 'x-jar-size': '4' },
        });

        // Whether the panel fares better is not something the client can predict,
        // and a mismatch still means the browser has no usable file.
        const direct = jest.fn().mockRejectedValue(new Error('Checksum mismatch'));
        const result = await withPanelFallback(hit(), direct, { versionId: 'abc' });

        expect(result.blob).toBeInstanceOf(Blob);
        get.mockRestore();
    });

    it('gives up with a link when both routes fail', async () => {
        jest.spyOn(require('@/api/http').default, 'get').mockRejectedValue(new Error('panel said no'));

        const direct = jest.fn().mockRejectedValue(new Error('blocked by extension'));

        await expect(withPanelFallback(hit(), direct, { versionId: 'abc' })).rejects.toThrow(AddOnUnavailableError);

        // The dead end is the outcome worth engineering against, so the error has
        // to carry a way forward.
        const error = await withPanelFallback(hit(), direct, { versionId: 'abc' }).catch((e) => e);
        expect(error.webUrl).toBe('https://modrinth.com/project/luckperms');
    });

    it('keeps both causes, because they are not the same problem', async () => {
        jest.spyOn(require('@/api/http').default, 'get').mockRejectedValue(new Error('panel said no'));

        const direct = jest.fn().mockRejectedValue(new Error('blocked by extension'));
        const error = await withPanelFallback(hit(), direct, { versionId: 'abc' }).catch((e) => e);

        expect((error.direct as Error).message).toBe('blocked by extension');
        expect((error.viaPanel as Error).message).toBe('panel said no');
    });

    it('does not compute a lazy filename unless the fallback is used', async () => {
        const get = jest.spyOn(require('@/api/http').default, 'get');
        const filename = jest.fn(() => 'LuckPerms-5.5.71.jar');

        await withPanelFallback(hit(), () => Promise.resolve({ blob: jarBlob(), filename: 'x.jar' }), { id: 1 }, { filename });

        // Spigot's real name needs a version lookup. Paying for it on the fast
        // path would be a request spent on a file nobody needs renamed.
        expect(filename).not.toHaveBeenCalled();
        get.mockRestore();
    });

    it('computes a lazy filename when the fallback is used', async () => {
        const get = jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: jarBlob(),
            headers: { 'content-disposition': 'attachment; filename="spigot-28140.jar"' },
        });

        const filename = jest.fn(() => 'LuckPerms-5.5.71.jar');
        const result = await withPanelFallback(
            hit({ provider: 'spigot', projectId: undefined, spigetId: 28140 }),
            () => Promise.reject(new Error('blocked')),
            { id: 28140 },
            { filename }
        );

        expect(filename).toHaveBeenCalled();
        // The panel only knows the resource id and would say spigot-28140.jar,
        // so the override is the only thing keeping the good name.
        expect(result.filename).toBe('LuckPerms-5.5.71.jar');
        get.mockRestore();
    });

    it('reports the fallback in progress so the user is not left watching a stall', async () => {
        jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: jarBlob(),
            headers: { 'x-jar-size': '4' },
        });

        const messages: string[] = [];
        await withPanelFallback(
            hit(),
            () => Promise.reject(new Error('blocked')),
            { versionId: 'abc' },
            { onProgress: (m) => messages.push(m) }
        );

        expect(messages.join(' ')).toMatch(/asking the panel/i);
    });
});

describe('downloadViaPanel', () => {
    afterEach(() => jest.restoreAllMocks());

    const okHeaders = (extra: Record<string, string> = {}) => ({
        'content-disposition': 'attachment; filename="Modrinth.jar"',
        'x-jar-size': '4',
        ...extra,
    });

    it('refuses an empty response', async () => {
        jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: new Blob([]),
            headers: okHeaders(),
        });

        await expect(downloadViaPanel(hit(), { versionId: 'abc' })).rejects.toThrow(/empty/i);
    });

    it('refuses something that is not a jar', async () => {
        // A provider answering with an HTML error page is the classic way a
        // "download" turns into a file that would never load.
        jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: new Blob(['<!doctype html><title>404</title>']),
            headers: okHeaders(),
        });

        await expect(downloadViaPanel(hit(), { versionId: 'abc' })).rejects.toThrow(/not a jar/i);
    });

    it('refuses a truncated copy', async () => {
        // The panel checked its own leg; this is the panel-to-browser hop, which
        // nothing else has verified.
        jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: new Blob([new Uint8Array([0x50, 0x4b])]),
            headers: okHeaders({ 'x-jar-size': '999999' }),
        });

        await expect(downloadViaPanel(hit(), { versionId: 'abc' })).rejects.toThrow(/truncated/i);
    });

    it('skips a digest the panel did not claim to check', async () => {
        // Spiget publishes none, and the panel says so with an empty header. A
        // literal "0" or "null" must not be compared against a real hash.
        jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: jarBlob(),
            headers: okHeaders({ 'x-jar-sha1': '', 'x-jar-sha256': '0' }),
        });

        await expect(downloadViaPanel(hit(), { versionId: 'abc' })).resolves.toBeDefined();
    });

    it('uses the filename the panel suggests when no override is given', async () => {
        jest.spyOn(require('@/api/http').default, 'get').mockResolvedValue({
            data: jarBlob(),
            headers: okHeaders(),
        });

        const result = await downloadViaPanel(hit(), { versionId: 'abc' });

        expect(result.filename).toBe('Modrinth.jar');
    });
});
