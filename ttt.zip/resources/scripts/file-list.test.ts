/**
 * The file list row.
 *
 * Two things are being held here, and one of them is structural.
 *
 * The cosmetic one: the row is the colour that was asked for, per theme --
 * #00666E on the blue theme, #1C4D23 on the dark one.
 *
 * The structural one: it got there by way of tokens rather than by replacing
 * the palette names that were there before. Those names were the bug. The rule
 * read `@apply bg-neutral-700`, and @apply inlines the colour, so no
 * `bg-neutral-700` class ever reached the DOM for the theme's remap to catch --
 * which is why every row was still dark-palette slate, hsl(209, 18%, 30%),
 * sitting on the blue theme with 3.47:1 text. The theme looked broken on the
 * Files page and the tokens said everything was fine.
 *
 * So the assertions here mostly check that the row is wired to tokens, because
 * a literal colour written straight into the module would pass every colour
 * check and reintroduce exactly the drift that caused this.
 *
 * The row is now per theme, which is the opposite of how it started, and that
 * reversal is why there are two block readers below instead of one. It used to
 * live in the shared block on the reasoning that a fixed dark surface keeps
 * `--at-surface` from putting a light bar on the dark theme. That reasoning is
 * still true and no longer applies: the two themes were asked for two different
 * row colours.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const themeCss = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');
const filesCss = readFileSync(
    join(__dirname, 'components/server/files/style.module.css'),
    'utf8'
);
const row = readFileSync(
    join(__dirname, 'components/server/files/FileObjectRow.tsx'),
    'utf8'
);

const shared = (() => {
    const found = themeCss.match(/\.aternos-blue,\s*\.aternos-dark\s*\{([\s\S]*?)\n\}/);

    if (!found) throw new Error('no shared token block');

    return found[1];
})();

/**
 * A theme block's body.
 *
 * The `\n\n` prefix is load-bearing, and it is the fourth time this file layout
 * has bitten. The shared selector list *ends* in `.aternos-dark {`, so an
 * unanchored search for the dark block returns the shared one -- which would
 * make every per-theme assertion below quietly compare the shared block against
 * itself and pass.
 */
const modeBlock = (selector: string) => {
    const found = themeCss.match(
        new RegExp(`\\n\\n${selector}\\s*\\{([\\s\\S]*?)\\n\\}`)
    );

    if (!found) throw new Error(`no block for ${selector}`);

    return found[1];
};

const blue = modeBlock('\\.aternos-blue');
const dark = modeBlock('\\.aternos-dark');

const grab = (block: string, name: string, where: string): string => {
    const found = block.match(new RegExp(`--at-${name}:\\s*([^;]+);`));

    if (!found) throw new Error(`no --at-${name} in the ${where} block`);

    return found[1].trim();
};

const modeToken = (block: string, name: string, where: string): string =>
    grab(block, name, where);

const hslToRgb = (h: number, s: number, l: number): [number, number, number] => {
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const hp = h / 60;
    const x = c * (1 - Math.abs((hp % 2) - 1));
    const [r, g, b] =
        hp < 1 ? [c, x, 0] : hp < 2 ? [x, c, 0] : hp < 3 ? [0, c, x] : hp < 4 ? [0, x, c] : hp < 5 ? [x, 0, c] : [c, 0, x];
    const m = l - c / 2;

    return [r, g, b].map((v) => Math.round((v + m) * 255)) as [number, number, number];
};

const toRgb = (value: string): [number, number, number] => {
    const v = value.trim();

    if (v.startsWith('#')) {
        const h = v.slice(1);

        return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)) as [number, number, number];
    }

    const rgb = v.match(/rgba?\(([^)]+)\)/);
    if (rgb) {
        return rgb[1].split(',').slice(0, 3).map((x) => parseInt(x, 10)) as [number, number, number];
    }

    // Needed because the dark theme writes its page colour as hsl(209, 20%, 25%),
    // and a translucent row can only be measured against what is behind it.
    const hsl = v.match(/hsla?\(([^)]+)\)/);
    if (hsl) {
        const [h, sat, lig] = hsl[1].split(',').map((x) => parseFloat(x));

        return hslToRgb(h, sat / 100, lig / 100);
    }

    throw new Error(`cannot parse colour: ${v}`);
};

/** The alpha in a colour, defaulting to 1 for the hex and hsl forms. */
const alphaOf = (value: string): number => {
    const rgb = value.trim().match(/rgba?\(([^)]+)\)/);
    const parts = rgb?.[1].split(',').map((x) => x.trim()) ?? [];

    return parts.length > 3 ? Number(parts[3]) : 1;
};

/** What a translucent colour actually looks like on top of a backdrop. */
const over = (top: string, backdrop: string): string => {
    const a = alphaOf(top);

    if (a >= 1) return top;

    const t = toRgb(top);
    const b = toRgb(backdrop);

    return (
        '#' +
        t
            .map((c, i) => Math.round(a * c + (1 - a) * b[i]).toString(16).padStart(2, '0'))
            .join('')
    );
};

const luminance = ([r, g, b]: [number, number, number]) => {
    const ch = (x: number) => {
        const v = x / 255;

        return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
    };

    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b);
};

const contrast = (a: string, b: string) => {
    const la = luminance(toRgb(a));
    const lb = luminance(toRgb(b));

    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
};

describe('the row colours that were asked for', () => {
    it('the blue theme row is rgba(157, 196, 241, 0.5), as asked', () => {
        const value = modeToken(blue, 'file-row', 'blue');
        const [r, g, b] = toRgb(value);

        expect([r, g, b]).toEqual([157, 196, 241]);
        expect(alphaOf(value)).toBeCloseTo(0.5, 2);
    });

    it('and the dark theme row is #454545 at the requested half opacity', () => {
        // Spelled out rather than compared to a string, so the assertion says what
        // the row is instead of what it happens to be serialised as -- rgba and
        // hsla with the same meaning would both be legitimate here.
        const value = modeToken(dark, 'file-row', 'dark');
        const [r, g, b] = toRgb(value);

        expect([r, g, b]).toEqual([69, 69, 69]);
        expect(alphaOf(value)).toBeCloseTo(0.5, 2);
    });

    it('both rows are translucent, so neither theme can fall back to a solid one', () => {
        // This was the opposite of a decision. Half transparency was tried on the
        // blue theme with a DARK row and rejected: over a light page it put the
        // file name at 2.99:1. It works with a light row, which is what is here
        // now -- and it is the row colour that made the difference, not the alpha.
        expect(alphaOf(modeToken(blue, 'file-row', 'blue'))).toBeLessThan(1);
        expect(alphaOf(modeToken(dark, 'file-row', 'dark'))).toBeLessThan(1);
    });

    it('it is the row background', () => {
        expect(filesCss).toMatch(/background-color:\s*var\(--at-file-row\)/);
    });
});

describe('both themes define the row, so neither falls through', () => {
    // The original version of this file asserted the opposite -- that the row
    // tokens were NOT per theme -- and the reasoning behind it still holds: a
    // value in only one mode block would win on specificity and leave the other
    // theme reading the shared block, which no longer has one. So the property
    // being held is "both or neither", not "shared".
    it.each([
        ['blue', () => blue],
        ['dark', () => dark],
    ])('the %s theme defines the row', (_name, block) => {
        expect(block()).toMatch(/--at-file-row:/);
    });

    it.each([
        ['blue', () => blue],
        ['dark', () => dark],
    ])('and the %s theme defines its own hover', (_name, block) => {
        expect(block()).toMatch(/--at-file-row-hover:/);
    });

    it('neither theme shares one row colour with the other', () => {
        // If they matched, the second block would be dead weight and the per-theme
        // split would be a promise the stylesheet does not keep.
        expect(modeToken(blue, 'file-row', 'blue')).not.toBe(modeToken(dark, 'file-row', 'dark'));
    });

    it.each(['file-row', 'file-row-hover', 'file-row-text', 'file-row-muted'])(
        '%s is declared exactly once per theme',
        (name) => {
            /*
             * A duplicate is invisible to every other check here. grab() returns
             * the FIRST declaration in a block, so a second one further down --
             * which is the one CSS actually uses, last one wins -- would leave the
             * test reading a value the browser never sees. A control that added a
             * second --at-file-row to the dark block passed all 37 assertions
             * while overriding the row outright.
             */
            [blue, dark].forEach((block) => {
                const count = (block.match(new RegExp(`--at-${name}:`, 'g')) ?? []).length;

                expect(count).toBe(1);
            });
        }
    );

    it('the shared block no longer sets a row background', () => {
        // If it did, and a theme block were ever dropped, the other theme would
        // silently get the shared colour instead of showing the breakage.
        expect(shared).not.toMatch(/--at-file-row:/);
        expect(shared).not.toMatch(/--at-file-row-hover:/);
    });

    it('the two themes hover in their own hue, not a leftover navy', () => {
        // #101f52 was the hover for a near-black navy row. It stays readable on
        // both new colours, so only a colour check catches it, and visually it
        // reads as a different row rather than a hover on this one.
        [blue, dark].forEach((block) => {
            expect(grab(block, 'file-row-hover', 'a theme').toLowerCase()).not.toBe('#101f52');
        });
    });

    it('the dark hover is a neutral, because the dark row is one', () => {
        // The dark row was a green and was asked for as a neutral grey. Its hover
        // went with it -- #123318 is still readable on #454545 at 1.45:1 and still
        // clears the "visibly different" bar, so no other assertion here would
        // notice a green hover sitting under a grey row.
        const [r, g, b] = toRgb(modeToken(dark, 'file-row-hover', 'dark'));

        expect(r).toBe(g);
        expect(g).toBe(b);
        expect(r).toBe(46);
    });

    it('the blue hover is blue, because the blue row is', () => {
        // The mirror of the neutrality check above, so a rule that only asked for
        // a neutral dark hover could not be satisfied by neutrals everywhere.
        const [r, g, b] = toRgb(modeToken(blue, 'file-row-hover', 'blue'));

        expect(b > r);
        expect(r).toBe(127);
    });

    it('both hovers are translucent, because both rows are', () => {
        // An opaque hover next to a see-through row reads as a different row and
        // drops the property that the row and its backdrop stay one thing.
        [blue, dark].forEach((block) => {
            expect(alphaOf(grab(block, 'file-row-hover', 'a theme'))).toBeLessThan(1);
        });
    });
});

describe('the row is wired to tokens, not to baked palette names', () => {
    // The actual regression. Each of these reads as a dark-palette value in the
    // compiled stylesheet, where no class-based override can reach it.
    it.each(['bg-neutral-700', 'bg-neutral-600', 'text-neutral-300', 'text-neutral-100'])(
        '%s is gone from the file row',
        (cls) => {
            const block = filesCss.slice(filesCss.indexOf('.file_row'));

            expect(block).not.toContain(cls);
        }
    );

    it('the row paints from a custom property', () => {
        // A literal colour in the module would pass every colour assertion below
        // and reintroduce the drift, so the wiring is what is checked.
        expect(filesCss).not.toMatch(/\.file_row\s*\{[^}]*background-color:\s*#/);
    });

    it('the text tokens are per mode, because the two rows are opposite', () => {
        /*
         * This asserted the opposite until now -- that they stay shared -- and the
         * reasoning was sound: one pair has to work on both rows, and a copy per
         * mode is a second place for them to drift. It stopped being true when the
         * light theme's row became a light translucent blue. A light text colour
         * cannot be readable on a light row and on a dark one at the same time, so
         * the tokens moved per mode and the "both or neither" rule took over.
         */
        [blue, dark].forEach((block) => {
            expect(block).toMatch(/--at-file-row-text:/);
            expect(block).toMatch(/--at-file-row-muted:/);
        });

        expect(shared).not.toMatch(/--at-file-row/);
    });

    it('and the two themes text their rows in opposite directions', () => {
        // The property that makes the split necessary rather than arbitrary. If
        // these ever matched, one theme's file list would be unreadable and the
        // per-mode copy would be a promise the stylesheet does not keep.
        expect(luminance(toRgb(modeToken(blue, 'file-row-text', 'blue')))).toBeLessThan(0.1);
        expect(luminance(toRgb(modeToken(dark, 'file-row-text', 'dark')))).toBeGreaterThan(0.5);
    });
});

describe.each([
    ['blue', () => blue, () => blue],
    ['dark', () => dark, () => dark],
])('the %s row still has to be readable', (_name, blockOf) => {
    // A dark background on its own is not a readable row. These are the pairs
    // that were previously 3.47:1 and 2.23:1.
    //
    // The teal row is the one that needed work: the muted token carried over from
    // the old navy row would have sat at 3.16:1 there, under AA, which is why it
    // was lightened to 4.58:1. The dark row is near enough in luminance that the
    // same value needed no second adjustment, and these assertions are what
    // guarantee that stays true if either row is ever changed again.
    /*
     * Everything below measures the row as the browser will actually paint it.
     *
     * The dark row is translucent, so its contrast depends on the page colour
     * behind it, and measuring the token on its own would compare the text
     * against an opaque #454545 the user never sees. Compositing first is the
     * only version of this assertion that means anything; the numbers it now
     * reports are 8.07:1 and 6.93:1 rather than 7.61:1 and 6.54:1.
     *
     * This is also the assertion that would catch a background *image* being a
     * problem, and it cannot: with an image set the backdrop is the photograph
     * under the panel's scrim, which the operator controls. The row was immune to
     * that while it was solid and is not now.
     */
    const page = () => modeToken(blockOf(), 'page', _name);
    const rowColour = () => over(modeToken(blockOf(), 'file-row', _name), page());
    // From the mode block, not the shared one. The text pair moved per mode when
    // the light theme's row became light, and reading it from the shared block is
    // what made all six of these fail on that change: the token was not there any
    // more, so the lookup threw inside each test and every one of them reported a
    // contrast failure it had not actually evaluated.
    const text = () => modeToken(blockOf(), 'file-row-text', _name);
    const muted = () => modeToken(blockOf(), 'file-row-muted', _name);
    const hover = () => over(modeToken(blockOf(), 'file-row-hover', _name), page());

    it('the theme has a page colour to composite against', () => {
        expect(() => toRgb(page())).not.toThrow();
    });

    it('the row is distinguishable from the page it sits on', () => {
        /*
         * A row you cannot see is not a row. The light theme's is the tight one at
         * 1.11:1, and that is a consequence of the colour that was asked for
         * rather than an oversight: half a light blue over a light page is very
         * nearly the page. Asserted so that raising the row's alpha to tidy it up
         * has to be a decision rather than a quiet fix.
         */
        expect(contrast(rowColour(), page())).toBeGreaterThan(1.05);
    });

    it('the file name clears AA on the row', () => {
        expect(contrast(text(), rowColour())).toBeGreaterThanOrEqual(4.5);
    });

    it('the icon clears AA on the row', () => {
        expect(contrast(muted(), rowColour())).toBeGreaterThanOrEqual(4.5);
    });

    it('and both clear AA on the hover background', () => {
        expect(contrast(text(), hover())).toBeGreaterThanOrEqual(4.5);
        expect(contrast(muted(), hover())).toBeGreaterThanOrEqual(4.5);
    });

    it('the hover is visibly different from the resting row', () => {
        // Otherwise the hover state is invisible and reads as broken. Compared
        // composited, because two translucent greys on the same backdrop are much
        // closer together than their token values suggest.
        expect(contrast(hover(), rowColour())).toBeGreaterThan(1.1);
    });


});

describe('the icon override still points at the icon', () => {
    // The icon div carries `text-neutral-400` as a real DOM class, so the theme's
    // remap makes it --at-text-muted: a dark navy. The override is what stops
    // that, and it is the only thing that keeps the icon on the shared muted
    // token rather than on the theme's own muted colour.
    it('the icon is given its own colour, not the inherited one', () => {
        expect(filesCss).toMatch(/&\s*>\s*\.details\s*>\s*:first-child\s*\{[^}]*at-file-row-muted/);
    });

    // `:first-child` is a structural guess: the module class is hashed and the
    // markup has no hook of its own. If anything is inserted before the icon,
    // the selector starts matching that element instead and the icon reverts to
    // the remapped dark navy -- invisible, with no error anywhere.
    //
    // An earlier version of this sliced from the first `<div css=` to the first
    // `</div>`, which passed even with an element inserted before the icon: a
    // self-closing `<div />` has no `</div>`, so the slice ran past it and still
    // found the icon's class. It asserts the absence of any element between the
    // details element opening and the icon, which is the property `:first-child`
    // actually depends on.
    const detailsOpen = row.indexOf('<Clickable file={file}>');
    const iconAt = row.indexOf('text-neutral-400');

    it('finds the icon and the element that wraps it', () => {
        expect(detailsOpen).toBeGreaterThan(-1);
        expect(iconAt).toBeGreaterThan(detailsOpen);
    });

    it('nothing sits between the details element and the icon', () => {
        const afterOpen = row.indexOf('>', detailsOpen) + 1;

        // Bounded by the icon's OWN opening tag, not by the class: the class sits
        // inside that tag's tw template, so slicing to it would include the tag
        // and trip this assertion on a correct file.
        const iconTag = row.lastIndexOf('<', iconAt);
        const between = row.slice(afterOpen, iconTag);

        // Any opening tag in this gap is an element that :first-child would match
        // before the icon.
        expect(between.match(/<[A-Za-z]/g) ?? []).toEqual([]);
    });

    it('and the class is on the icon div itself, not on a wrapper', () => {
        const iconTag = row.lastIndexOf('<', iconAt);
        const tag = row.slice(iconTag, iconAt + 'text-neutral-400'.length);

        expect(tag).toMatch(/^<div\s+css=\{tw`/);
    });
});
