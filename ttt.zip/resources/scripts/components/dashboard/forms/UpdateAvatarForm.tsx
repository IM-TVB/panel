import React, { useRef, useState } from 'react';
import { Actions, State, useStoreActions, useStoreState } from 'easy-peasy';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Avatar from '@/components/Avatar';
import { Button } from '@/components/elements/button/index';
import { Options } from '@/components/elements/button/types';
import { ApplicationStore } from '@/state';
import tw from 'twin.macro';
import { AxiosError } from 'axios';
import { setAvatar, clearAvatar } from '@/api/user/avatar';

/**
 * A user's own profile picture.
 *
 * A plain file input rather than a drag-and-drop or a cropper. The point of this
 * is that a person can put their own face on their account without the panel
 * becoming an image editor; the server probes what was actually uploaded and
 * refuses anything too small or too large, so the preview below is the real
 * thing rather than an optimistic guess.
 *
 * The file input is not a styled <input type="file"> from the theme because the
 * account page is stock Pterodactyl UI, not Aternos-restyled. It is wrapped in a
 * label so the visible control is a button, which is what makes it obvious it is
 * clickable.
 */
export default () => {
    const user = useStoreState((state: State<ApplicationStore>) => state.user.data);
    const updateUserData = useStoreActions((actions: Actions<ApplicationStore>) => actions.user.updateUserData);
    const { addFlash, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const input = useRef<HTMLInputElement>(null);
    const [busy, setBusy] = useState(false);

    const error = (e: unknown) => {
        if (e instanceof AxiosError && e.response?.data?.errors) {
            return e.response.data.errors.map((err: { detail: string }) => err.detail).join(' ');
        }

        return 'The picture could not be uploaded.';
    };

    const upload = (file: File) => {
        setBusy(true);
        clearFlashes('account:avatar');

        setAvatar(file)
            .then((url) =>
                // The store drives the sidebar, so it is what has to be told --
                // otherwise the picture would only appear after a reload.
                updateUserData({ avatarUrl: url })
            )
            .then(() =>
                addFlash({
                    type: 'success',
                    key: 'account:avatar',
                    message: 'Your profile picture has been updated.',
                })
            )
            .catch((e) =>
                addFlash({
                    type: 'error',
                    key: 'account:avatar',
                    title: 'Error',
                    message: error(e),
                })
            )
            .then(() => setBusy(false));
    };

    const remove = () => {
        setBusy(true);
        clearFlashes('account:avatar');

        clearAvatar()
            .then(() => updateUserData({ avatarUrl: null }))
            .then(() =>
                addFlash({
                    type: 'success',
                    key: 'account:avatar',
                    message: 'Your profile picture has been removed.',
                })
            )
            .catch((e) =>
                addFlash({
                    type: 'error',
                    key: 'account:avatar',
                    title: 'Error',
                    message: error(e),
                })
            )
            .then(() => setBusy(false));
    };

    const hasImage = Boolean(user?.avatarUrl);

    return (
        <div css={tw`relative`}>
            <SpinnerOverlay size={'large'} visible={busy} />

            <div css={tw`flex items-center`}>
                {/*
                    The box is sized, not the avatar. Avatar.User's picture fills
                    whatever box it is in and covers it, so a width on the avatar
                    itself would be beaten by that and collapse to the width of an
                    auto-sized parent.
                */}
                <div className={'at-account__avatar'} css={tw`flex-shrink-0 w-16 h-16 rounded-full overflow-hidden bg-neutral-700`}>
                    <Avatar.User />
                </div>

                <div css={tw`ml-4 flex-1`}>
                    <p className={'text-sm text-neutral-400'}>
                        {hasImage
                            ? 'Your picture is shown in the sidebar and beside your name.'
                            : 'You are shown as a generated identicon. Upload a picture to use your own.'}
                    </p>

                    {/*
                        The file input is kept in the DOM and hidden rather than
                        removed, because a label pointing at nothing does nothing:
                        the browser needs the input to exist for the label's click
                        to open a file picker.
                    */}
                    <input
                        ref={input}
                        type="file"
                        accept="image/png,image/jpeg,image/gif,image/webp"
                        className={'hidden'}
                        onChange={(e) => {
                            const file = e.currentTarget.files?.[0];

                            if (file) {
                                upload(file);
                            }

                            // Cleared so choosing the same file twice in a row is
                            // still a change event, and so the input never holds a
                            // reference to a file that was rejected.
                            e.currentTarget.value = '';
                        }}
                    />

                    <div css={tw`mt-3 flex`}>
                        {/*
                            Enum values, not strings: Button's props are typed
                            against Options, so a string compiles to a type error
                            rather than quietly rendering the default size. And
                            `disabled` rather than a loading prop, because
                            Button has no such prop -- the sibling forms use the
                            overlay above for the same reason.
                        */}
                        <Button
                            type="button"
                            size={Options.Size.Small}
                            css={tw`mr-2`}
                            disabled={busy}
                            onClick={() => input.current?.click()}
                        >
                            {hasImage ? 'Replace' : 'Upload'}
                        </Button>

                        {/*
                            Only rendered when there is something to remove. A
                            disabled button that always sits there is one more
                            control to read past.
                        */}
                        {hasImage ? (
                            <Button
                                type="button"
                                size={Options.Size.Small}
                                variant={Options.Variant.Secondary}
                                disabled={busy}
                                onClick={remove}
                            >
                                Remove
                            </Button>
                        ) : null}
                    </div>

                    <p className={'text-xs text-neutral-500 mt-2'}>
                        PNG, JPEG, GIF or WebP, up to 2 MB and at least 64&times;64 pixels. Square works best
                        &mdash; it is drawn as a circle. SVG is not accepted: it can carry script.
                    </p>
                </div>
            </div>
        </div>
    );
};
