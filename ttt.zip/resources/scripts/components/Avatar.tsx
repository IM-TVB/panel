import React from 'react';
import BoringAvatar, { AvatarProps } from 'boring-avatars';
import { useStoreState } from '@/state/hooks';

const palette = ['#FFAD08', '#EDD75A', '#73B06F', '#0C8F8F', '#587291'];

type Props = Omit<AvatarProps, 'colors'>;

/**
 * boring-avatars types AvatarProps as just its own six fields, so there is no
 * style prop and no arbitrary SVG attributes to hang one on. Both are declared
 * here rather than cast at the call site, so a caller can restyle the avatar
 * without a type error and the identicon still accepts the same props.
 */
type UserAvatarProps = Omit<Props, 'name'> & { style?: React.CSSProperties };

const _Avatar = ({ variant = 'beam', ...props }: AvatarProps) => (
    <BoringAvatar colors={palette} variant={variant} {...props} />
);

/*
 * A user's own picture when they have set one, and the identicon when they have
 * not.
 *
 * avatar_url is null for a user who has not uploaded anything, which is the common
 * case, so the identicon is a fallback rather than a broken image. The `image`
 * field is deliberately not used: it is a Gravatar derived from the email address,
 * and switching the sidebar to it would replace a themed identicon on every
 * account at once -- which is not what "let people change their picture" should do.
 *
 * The <img> fills and crops rather than taking its intrinsic size. Every call
 * site is a fixed-size box with overflow: hidden, and an unsized <img> in one of
 * those is clipped to its top-left corner -- so a 600x800 phone photo came out as
 * a corner of a forehead. object-fit: cover scales it to the box and centres what
 * is left, which is what a profile picture is expected to do.
 *
 * The size is inline rather than a class so it beats the caller's own width and
 * height, and a caller's style is merged on top of it so a site can still
 * override. A call site that wants a specific size should size the *box* around
 * the avatar, not the avatar -- the styles here would win.
 */
const _UserAvatar = ({ variant = 'beam', style, ...props }: UserAvatarProps) => {
    const uuid = useStoreState((state) => state.user.data?.uuid);
    const avatarUrl = useStoreState((state) => state.user.data?.avatarUrl);

    if (avatarUrl) {
        return (
            <img
                src={avatarUrl}
                alt={''}
                style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', ...style }}
                {...props}
            />
        );
    }

    /*
     * `style` is deliberately not forwarded here. boring-avatars does not type it
     * and the identicon sizes itself through size/square rather than CSS, so
     * there is nothing for it to override -- passing it would be a type error
     * against a component that renders the same picture at the same size either
     * way. A caller styling the box around the avatar gets the same result on
     * both paths.
     */
    return <BoringAvatar colors={palette} name={uuid || 'system'} variant={variant} {...props} />;
};

_Avatar.displayName = 'Avatar';
_UserAvatar.displayName = 'Avatar.User';

/**
 * A particular person's picture, and the identicon when they have not set one.
 *
 * `Avatar.User` is the account that happens to be logged in, which is not the
 * same thing as "the user in this row". The activity log lists everybody's
 * actions and the subuser list lists other people's, so for those the picture
 * has to be the one belonging to the row -- passing the signed-in user's would
 * put my face next to somebody else's login.
 *
 * The subject is taken as a plain object with the two fields that matter, so
 * this does not care where the user came from.
 */
type AvatarSubject = { uuid?: string | null; avatarUrl?: string | null };

type ForProps = Omit<Props, 'name'> & {
    user?: AvatarSubject | null;
    name?: string;
    style?: React.CSSProperties;
};

const _AvatarOf = ({ user, name, variant = 'beam', style, ...props }: ForProps) => {
    if (user?.avatarUrl) {
        return (
            <img
                src={user.avatarUrl}
                alt={''}
                style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block', ...style }}
                {...props}
            />
        );
    }

    // The identicon is seeded from the uuid, so the same person is the same
    // shape on every page -- and the same shape they had before they uploaded
    // a picture.
    return (
        <BoringAvatar
            colors={palette}
            name={user?.uuid || name || 'system'}
            variant={variant}
            {...props}
        />
    );
};

_AvatarOf.displayName = 'Avatar.Of';

const Avatar = Object.assign(_Avatar, {
    User: _UserAvatar,
    Of: _AvatarOf,
});

export default Avatar;
