import React from 'react';
import MessageBox from '@/components/MessageBox';
import { useStoreState } from 'easy-peasy';
import { Transition, TransitionGroup } from 'react-transition-group';
import { FlashMessage } from '@/state/flashes';

/**
 * How long the load and unload run for.
 *
 * `Transition` swaps `entering` for `entered` when this elapses, so this and the
 * durations in `.at-flash` have to be the same number: CSS longer than the
 * timeout is cut off halfway, CSS shorter leaves the banner parked at its final
 * position for the remainder. 280ms reads as movement without feeling like a
 * wait, which matters most for the banners that clear themselves.
 */
const TRANSITION_MS = 280;

type Props = Readonly<{
    byKey?: string;
    className?: string;
}>;

/**
 * What TransitionGroup clones onto its children.
 *
 * Derived from the component rather than imported: this package's root only
 * re-exports the components, not `TransitionProps`, and the deep path for it is
 * a private detail of the DefinitelyTyped layout.
 */
type Injected = Partial<Omit<React.ComponentProps<typeof Transition>, 'children'>>;

/**
 * One flash, kept in the DOM while it leaves.
 *
 * Two things here could not be written inline in the map below:
 *
 *  - `nodeRef` is not optional in react-transition-group v4. Without it the
 *    transition looks the node up with findDOMNode, which is deprecated and
 *    warns in development. Getting one ref per item needs a component per item,
 *    because a hook cannot be called in a loop over a list whose length changes.
 *
 *  - TransitionGroup clones its children with `in`, `onExited`, `appear` and the
 *    rest. A `Flash` that swallowed them would never learn it was exiting, and
 *    so would never unmount: the banner would stay, invisible, forever.
 */
const Flash = ({ flash, ...transition }: { flash: FlashMessage } & Injected) => {
    const ref = React.useRef<HTMLDivElement>(null);

    return (
        <Transition nodeRef={ref} timeout={TRANSITION_MS} unmountOnExit {...transition}>
            {(state) => (
                <div ref={ref} className={`at-flash at-flash--${state}`}>
                    <MessageBox type={flash.type} title={flash.title}>
                        {flash.message}
                    </MessageBox>
                </div>
            )}
        </Transition>
    );
};

/**
 * The flash banners.
 *
 * A flash arrives by being pushed onto a global store and leaves by being
 * filtered back out of it. At that moment the DOM it lived in has nothing left
 * in it to animate, so a plain map gives a banner that pops in and vanishes.
 * Wrapping the list in a TransitionGroup is what holds each one on screen for
 * the length of its exit -- the same idea PageContentBlock uses for the page
 * transition.
 *
 * The layer itself is out of the flow. In flow it was a real bug: a banner
 * appearing pushed the page down and its removal pulled it back up, so anything
 * you were reaching for moved between the press and the release. See
 * `.at-flash-layer`.
 *
 * The motion itself is CSS (`.at-flash`); this component only decides when there
 * is still an element for the motion to apply to.
 */
const FlashMessageRender = ({ byKey, className }: Props) => {
    const flashes = useStoreState((state) =>
        state.flashes.items.filter((flash) => (byKey ? flash.key === byKey : true))
    );

    return flashes.length ? (
        // `appear` so a banner that mounts is animated in. Without it a
        // Transition mounts straight into `entered`, and there is no earlier
        // state to transition from.
        <TransitionGroup
            component={'div'}
            // The caller's className is kept rather than replaced: VariableBox
            // passes one, and dropping it would be a silent regression.
            className={className ? `at-flash-layer ${className}` : 'at-flash-layer'}
            appear
        >
            {flashes.map((flash) => (
                <Flash key={flash.id || flash.type + flash.message} flash={flash} />
            ))}
        </TransitionGroup>
    ) : null;
};

export default FlashMessageRender;