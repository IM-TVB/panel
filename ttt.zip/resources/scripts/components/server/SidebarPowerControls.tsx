// The classic runtime means JSX lowers to React.createElement, so React has to
// be bound by name even though no React.* member is used directly.
import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlay, faRedo, faStop } from '@fortawesome/free-solid-svg-icons';
import { Dialog } from '@/components/elements/dialog';
import { ServerContext } from '@/state/server';
import { usePermissions } from '@/plugins/usePermissions';

/**
 * Start / Restart / Stop for the server this sidebar is scoped to.
 *
 * The Console has had these since it shipped, but the Console is one page. The
 * sidebar is on all of them, so the controls go here too -- reaching for
 * "restart" while reading a file or a log should not mean navigating back first.
 *
 * Same mechanism as the console's PowerButtons, deliberately: the action is sent
 * over the websocket (`set state`), not a REST call, because the websocket is
 * what pushes the resulting status back. Sending it any other way would leave
 * the status the UI shows out of step with the daemon. The dialog is the same
 * one, too -- but portalled, see below.
 *
 * Status starts as `null` and the socket as `null`, so every button is disabled
 * on the first paint and until Wings has actually connected.
 */

const SidebarPowerControls = () => {
    const [confirmKill, setConfirmKill] = useState(false);
    const status = ServerContext.useStoreState((state) => state.status.value);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const [canStart, canRestart, canStop] = usePermissions([
        'control.start',
        'control.restart',
        'control.stop',
    ]);

    // A stop that has not completed is the only state where "kill" is the action
    // that is left; the button relabels itself and asks before doing something
    // that can corrupt the world.
    const killable = status === 'stopping';

    const send = (action: 'start' | 'restart' | 'stop' | 'kill') => {
        if (!instance) {
            return;
        }

        setConfirmKill(false);
        instance.send('set state', action);
    };

    useEffect(() => {
        // The prompt does not mean anything once the server is down, and leaving
        // it armed would reopen it against the next stop.
        if (status === 'offline') {
            setConfirmKill(false);
        }
    }, [status]);

    // Nothing to offer someone with none of the three controls. Without this the
    // grid renders empty and still takes its row of padding.
    if (!canStart && !canRestart && !canStop) {
        return null;
    }

    return (
        <div className={'at-power'} role={'group'} aria-label={'Server power'}>
            {canStart && (
                <button
                    type={'button'}
                    className={'at-power__btn at-power__btn--start'}
                    disabled={status !== 'offline'}
                    title={'Start'}
                    onClick={() => send('start')}
                >
                    <FontAwesomeIcon icon={faPlay} />
                    <span>Start</span>
                </button>
            )}
            {canRestart && (
                <button
                    type={'button'}
                    className={'at-power__btn at-power__btn--restart'}
                    disabled={!status}
                    title={'Restart'}
                    onClick={() => send('restart')}
                >
                    <FontAwesomeIcon icon={faRedo} />
                    <span>Restart</span>
                </button>
            )}
            {canStop && (
                <button
                    type={'button'}
                    className={'at-power__btn at-power__btn--stop'}
                    disabled={!status || status === 'offline'}
                    title={killable ? 'Kill' : 'Stop'}
                    onClick={() => (killable ? setConfirmKill(true) : send('stop'))}
                >
                    <FontAwesomeIcon icon={faStop} />
                    <span>{killable ? 'Kill' : 'Stop'}</span>
                </button>
            )}

            {/* Portalled to <body> on purpose. `.at-sidebar` sets
                `backdrop-filter`, which makes it the containing block for
                position:fixed descendants -- left in place, the dialog's
                `fixed inset-0` overlay would be clipped to the sidebar instead of
                covering the page. A portal only moves the DOM; the React context
                (and so ServerContext) still reaches the dialog. Kept mounted so
                AnimatePresence can play its exit animation. */}
            {createPortal(
                <Dialog.Confirm
                    open={confirmKill}
                    hideCloseIcon
                    onClose={() => setConfirmKill(false)}
                    title={'Forcibly Stop Process'}
                    confirm={'Continue'}
                    onConfirmed={() => send('kill')}
                >
                    Forcibly stopping a server can lead to data corruption.
                </Dialog.Confirm>,
                document.body
            )}
        </div>
    );
};

export default SidebarPowerControls;
