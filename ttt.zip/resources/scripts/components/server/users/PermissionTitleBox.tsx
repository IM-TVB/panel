import React, { memo, useCallback, useEffect, useRef } from 'react';
import { useField } from 'formik';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import tw from 'twin.macro';
import Input from '@/components/elements/Input';
import isEqual from 'react-fast-compare';

interface Props {
    isEditable: boolean;
    title: string;
    permissions: string[];
    className?: string;
}

/**
 * One permission group, with a header checkbox for the whole of it.
 *
 * The checkbox used to show "nothing selected" whenever the group was only
 * partly ticked, which is the one thing it cannot be telling you: someone who
 * has granted three of FILE's seven keys was looking at an empty box, with no
 * way to tell that from having granted none. `indeterminate` is the third
 * answer, and it takes the DOM property rather than another class, because a
 * checkbox only draws the mixed state when the property is set.
 *
 * The visible half of that is CSS: these inputs are `appearance: none`, so the
 * browser draws no dash of its own and `.at-check-indeterminate` is what makes
 * the state legible rather than invisible. That rule is not optional.
 *
 * `at-modal__group` goes on the box for the same reason the modal panel carries
 * `at-modal`: TitledGreyBox paints itself through twin's `css` prop, so neither
 * `bg-neutral-700` nor `bg-neutral-900` exists in the DOM for the light
 * palette's remap to match, and inside a light dialog the group would have
 * stayed a dark box. See Modal.tsx.
 */
const PermissionTitleBox: React.FC<Props> = memo(({ isEditable, title, permissions, className, children }) => {
    const [{ value }, , { setValue }] = useField<string[]>('permissions');
    const box = useRef<HTMLInputElement>(null);

    const onCheckboxClicked = useCallback(
        (e: React.ChangeEvent<HTMLInputElement>) => {
            if (e.currentTarget.checked) {
                setValue([...value, ...permissions.filter((p) => !value.includes(p))]);
            } else {
                setValue(value.filter((p) => !permissions.includes(p)));
            }
        },
        [permissions, value]
    );

    const ticked = permissions.filter((p) => value.includes(p)).length;
    const all = ticked === permissions.length;
    const partial = ticked > 0 && !all;

    useEffect(() => {
        if (box.current) {
            box.current.indeterminate = partial;
        }
    }, [partial]);

    return (
        <TitledGreyBox
            title={
                <div css={tw`flex items-center gap-3`}>
                    <p className={'at-modal__group-title'}>{title}</p>
                    <div css={tw`flex-1`} />
                    <span className={'at-modal__pill'}>
                        {ticked} of {permissions.length}
                    </span>
                    {isEditable && (
                        <Input
                            ref={box}
                            type={'checkbox'}
                            className={'at-check-indeterminate'}
                            checked={all}
                            onChange={onCheckboxClicked}
                            // A group is often granted partly, and a bare tick
                            // gives no clue which way clicking it will go.
                            title={
                                partial
                                    ? `${ticked} of ${permissions.length} granted — click to grant the rest`
                                    : all
                                    ? `Revoke every ${title.toLowerCase()} permission`
                                    : `Grant every ${title.toLowerCase()} permission`
                            }
                        />
                    )}
                </div>
            }
            className={className ? `at-modal__group ${className}` : 'at-modal__group'}
        >
            {children}
        </TitledGreyBox>
    );
}, isEqual);

export default PermissionTitleBox;