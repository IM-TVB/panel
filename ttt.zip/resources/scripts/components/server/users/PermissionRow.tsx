/**
 * A single permission, as a row in a group.
 *
 * Unchanged in behaviour -- same checkbox, same label, same detail line -- and
 * given two class names so the stylesheet can reach it. That is the whole
 * reason this file is in the package: twin's `css` prop compiles to a style
 * object and puts no class name on the element, so the light theme's remap for
 * `text-neutral-400` has nothing to match, and the detail line landed on a
 * light card at 1.48:1. See Modal.tsx for the longer version of that.
 */
import styled from 'styled-components/macro';
import tw from 'twin.macro';
import Checkbox from '@/components/elements/Checkbox';
import React from 'react';
import { useStoreState } from 'easy-peasy';
import Label from '@/components/elements/Label';

const Container = styled.label`
    ${tw`flex items-center border border-transparent rounded md:p-2 transition-colors duration-75`};
    text-transform: none;

    &:not(.disabled) {
        ${tw`cursor-pointer`};

        &:hover {
            ${tw`border-neutral-500 bg-neutral-800`};
        }
    }

    &:not(:first-of-type) {
        ${tw`mt-4 sm:mt-2`};
    }

    &.disabled {
        ${tw`opacity-50`};

        & input[type='checkbox']:not(:checked) {
            ${tw`border-0`};
        }
    }
`;

interface Props {
    permission: string;
    disabled: boolean;
}

const PermissionRow = ({ permission, disabled }: Props) => {
    const [key, pkey] = permission.split('.', 2);
    const permissions = useStoreState((state) => state.permissions.data);

    return (
        <Container
            htmlFor={`permission_${permission}`}
            className={`at-modal__row ${disabled ? 'disabled' : ''}`}
        >
            <div css={tw`p-2`}>
                <Checkbox
                    id={`permission_${permission}`}
                    name={'permissions'}
                    value={permission}
                    css={tw`w-5 h-5 mr-2`}
                    disabled={disabled}
                />
            </div>
            <div css={tw`flex-1`}>
                <Label as={'p'} className={'at-modal__row-name'} css={tw`font-medium`}>
                    {pkey}
                </Label>
                {permissions[key].keys[pkey].length > 0 && (
                    <p className={'at-modal__row-detail'} css={tw`text-xs text-neutral-400 mt-1`}>
                        {permissions[key].keys[pkey]}
                    </p>
                )}
            </div>
        </Container>
    );
};

export default PermissionRow;
