import React, { useContext, useEffect, useRef } from 'react';
import { Subuser } from '@/state/server/subusers';
import { Form, Formik, useField } from 'formik';
import { array, object, string } from 'yup';
import Field from '@/components/elements/Field';
import { Actions, useStoreActions, useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import createOrUpdateSubuser from '@/api/server/users/createOrUpdateSubuser';
import { ServerContext } from '@/state/server';
import FlashMessageRender from '@/components/FlashMessageRender';
import Can from '@/components/elements/Can';
import { usePermissions } from '@/plugins/usePermissions';
import { useDeepCompareMemo } from '@/plugins/useDeepCompareMemo';
import tw from 'twin.macro';
import Button from '@/components/elements/Button';
import Input from '@/components/elements/Input';
import PermissionTitleBox from '@/components/server/users/PermissionTitleBox';
import asModal from '@/hoc/asModal';
import PermissionRow from '@/components/server/users/PermissionRow';
import ModalContext from '@/context/ModalContext';

type Props = {
    subuser?: Subuser;
};

interface Values {
    email: string;
    permissions: string[];
}

/**
 * "Select every permission below", in one click.
 *
 * A component of its own, and not a matter of tidiness. It calls `useField`,
 * which reads the Formik context, and a hook reading that context only works in
 * something rendered *inside* `<Formik>` -- but `EditSubuserModal` is what
 * renders `<Formik>`, so a call in its own body is never a child of the provider
 * it just made. Formik answers that with an invariant, and every page that
 * mounts this modal dies in the error boundary with no visible cause.
 *
 * Same reason `PermissionTitleBox` is a component: it calls `useField` too.
 *
 * The `at-modal__muted` class on the tally is not decoration either -- it is
 * how the stylesheet reaches it. `text-neutral-400` is written through twin's
 * css prop, so the light palette's remap for it has no class to match and the
 * stock grey-400 lands on the dialog at 1.54:1. See Modal.tsx.
 */
const SelectAllPermissions = ({ grantable, total }: { grantable: string[]; total: number }) => {
    const [{ value }, , { setValue }] = useField<string[]>('permissions');
    const box = useRef<HTMLInputElement>(null);

    const all = grantable.length > 0 && grantable.every((p) => value.includes(p));
    // The middle answer is the common one: a form part way through its keys
    // should not be reported as unticked.
    const partial = !all && grantable.some((p) => value.includes(p));
    const withheld = total - grantable.length;

    useEffect(() => {
        if (box.current) {
            box.current.indeterminate = partial;
        }
    }, [partial]);

    const onSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
        setValue(
            e.currentTarget.checked
                ? Array.from(new Set([...value, ...grantable]))
                : value.filter((p) => !grantable.includes(p))
        );
    };

    return (
        <div
            className={'at-modal__selectall'}
            css={tw`mt-2 mb-4 flex flex-wrap items-center justify-between gap-3 rounded border border-neutral-600 px-3 py-2`}
        >
            <label css={tw`flex items-center gap-3 text-sm cursor-pointer select-none`}>
                <Input
                    ref={box}
                    type={'checkbox'}
                    className={'at-check-indeterminate'}
                    checked={all}
                    onChange={onSelectAll}
                />
                <span>Select every permission below</span>
            </label>
            <span className={'at-modal__muted'} css={tw`text-xs text-neutral-400`}>
                {withheld > 0
                    ? `${grantable.length} of ${total} — the rest are not yours to grant`
                    : `${grantable.length} permissions`}
            </span>
        </div>
    );
};

const EditSubuserModal = ({ subuser }: Props) => {
    const ref = useRef<HTMLHeadingElement>(null);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const appendSubuser = ServerContext.useStoreActions((actions) => actions.subusers.appendSubuser);
    const { clearFlashes, clearAndAddHttpError } = useStoreActions(
        (actions: Actions<ApplicationStore>) => actions.flashes
    );
    const { dismiss, setPropOverrides } = useContext(ModalContext);

    const isRootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const permissions = useStoreState((state) => state.permissions.data);
    // The currently logged in user's permissions. We're going to filter out any permissions
    // that they should not need.
    const loggedInPermissions = ServerContext.useStoreState((state) => state.server.permissions);
    const [canEditUser] = usePermissions(subuser ? ['user.update'] : ['user.create']);

    // The permissions that can be modified by this user.
    const editablePermissions = useDeepCompareMemo(() => {
        const cleaned = Object.keys(permissions).map((key) =>
            Object.keys(permissions[key].keys).map((pkey) => `${key}.${pkey}`)
        );

        const list: string[] = ([] as string[]).concat.apply([], Object.values(cleaned));

        if (isRootAdmin || (loggedInPermissions.length === 1 && loggedInPermissions[0] === '*')) {
            return list;
        }

        return list.filter((key) => loggedInPermissions.indexOf(key) >= 0);
    }, [isRootAdmin, permissions, loggedInPermissions]);

    /**
     * Every permission the form actually shows, websocket excluded because the
     * group is not rendered.
     *
     * Derived from the rendered groups rather than from `editablePermissions` on
     * purpose: `editablePermissions` includes `websocket.connect`, and a "grant
     * everything" control that silently ticked an invisible permission would be
     * granting something the person filling it in cannot see or undo.
     */
    const visiblePermissions = useDeepCompareMemo(
        () =>
            Object.keys(permissions)
                .filter((key) => key !== 'websocket')
                .reduce<string[]>(
                    (all, key) => all.concat(Object.keys(permissions[key].keys).map((pkey) => `${key}.${pkey}`)),
                    []
                ),
        [permissions]
    );

    const grantable = visiblePermissions.filter((p) => editablePermissions.indexOf(p) >= 0);

    const submit = (values: Values) => {
        setPropOverrides({ showSpinnerOverlay: true });
        clearFlashes('user:edit');

        createOrUpdateSubuser(uuid, values, subuser)
            .then((subuser) => {
                appendSubuser(subuser);
                dismiss();
            })
            .catch((error) => {
                console.error(error);
                setPropOverrides(null);
                clearAndAddHttpError({ key: 'user:edit', error });

                if (ref.current) {
                    ref.current.scrollIntoView();
                }
            });
    };

    useEffect(
        () => () => {
            clearFlashes('user:edit');
        },
        []
    );

    return (
        <Formik
            onSubmit={submit}
            initialValues={
                {
                    email: subuser?.email || '',
                    permissions: subuser?.permissions || [],
                } as Values
            }
            validationSchema={object().shape({
                email: string()
                    .max(191, 'Email addresses must not exceed 191 characters.')
                    .email('A valid email address must be provided.')
                    .required('A valid email address must be provided.'),
                permissions: array().of(string()),
            })}
        >
            <Form>
                <div css={tw`flex justify-between items-center gap-4`}>
                    <h2 className={'at-modal__title'} css={tw`text-2xl`} ref={ref}>
                        {subuser
                            ? `${canEditUser ? 'Modify' : 'View'} permissions for ${subuser.email}`
                            : 'Create new subuser'}
                    </h2>
                    <div>
                        <Button type={'submit'} css={tw`w-full sm:w-auto`}>
                            {subuser ? 'Save' : 'Invite User'}
                        </Button>
                    </div>
                </div>
                <FlashMessageRender byKey={'user:edit'} css={tw`mt-4`} />
                {!isRootAdmin && loggedInPermissions[0] !== '*' && (
                    <div className={'at-modal__notice'} css={tw`mt-4 pl-4 py-2 border-l-4 border-cyan-400`}>
                        <p css={tw`text-sm text-neutral-300`}>
                            Only permissions which your account is currently assigned may be selected when creating or
                            modifying other users.
                        </p>
                    </div>
                )}
                {!subuser && (
                    <div css={tw`mt-6`}>
                        <Field
                            name={'email'}
                            label={'User Email'}
                            description={
                                'Enter the email address of the user you wish to invite as a subuser for this server.'
                            }
                        />
                    </div>
                )}
                {/*
                    One control for the whole form.

                    "Give this person everything" is otherwise twelve group headers
                    and every key inside them -- and the thing an operator most
                    often wants for a new subuser is the one worst served by
                    ticking forty boxes.

                    It only ever ticks what the rows below it would let them tick.
                    `grantable` is the same filter `PermissionRow` is disabled by,
                    so "select all" cannot mean "select all I am not allowed to
                    give", which would produce a save the server rejects.
                */}
                {canEditUser && grantable.length > 0 && (
                    <SelectAllPermissions grantable={grantable} total={visiblePermissions.length} />
                )}
                <div css={tw`my-6`}>
                    {Object.keys(permissions)
                        .filter((key) => key !== 'websocket')
                        .map((key, index) => (
                            <PermissionTitleBox
                                key={`permission_${key}`}
                                title={key}
                                isEditable={canEditUser}
                                permissions={Object.keys(permissions[key].keys).map((pkey) => `${key}.${pkey}`)}
                                css={index > 0 ? tw`mt-4` : undefined}
                            >
                                <p className={'at-modal__group-desc'} css={tw`text-sm text-neutral-400 mb-4`}>
                                    {permissions[key].description}
                                </p>
                                {Object.keys(permissions[key].keys).map((pkey) => (
                                    <PermissionRow
                                        key={`permission_${key}.${pkey}`}
                                        permission={`${key}.${pkey}`}
                                        disabled={!canEditUser || editablePermissions.indexOf(`${key}.${pkey}`) < 0}
                                    />
                                ))}
                            </PermissionTitleBox>
                        ))}
                </div>
                <Can action={subuser ? 'user.update' : 'user.create'}>
                    <div className={'at-modal__actions'}>
                        <div css={tw`pb-2 flex justify-end`}>
                            <Button type={'submit'} css={tw`w-full sm:w-auto`}>
                                {subuser ? 'Save' : 'Invite User'}
                            </Button>
                        </div>
                    </div>
                </Can>
            </Form>
        </Formik>
    );
};

export default asModal<Props>({
    top: false,
})(EditSubuserModal);