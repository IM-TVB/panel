import React from 'react';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import SoftwarePicker from '@/components/server/plugins/SoftwarePicker';
import { ServerContext } from '@/state/server';

/**
 * The server's software, and the Minecraft version it installs as.
 *
 * This used to be a block at the very top of the Plugins page, which meant the
 * one control that changes what the server actually *is* was something you found
 * by accident while looking for a plugin. It has its own page -- and its own
 * sidebar entry -- now.
 *
 * Only the placement moved. The picker below is the same two-step wizard
 * (choose software, then choose a version) and still owns the request; this file
 * exists so the sidebar has something to route to.
 */
export default () => {
    const server = ServerContext.useStoreState((state) => state.server.data);

    // The router only mounts this after the server has loaded, but the store can
    // still be empty on the first render, and dereferencing it here would take
    // the whole view down instead of showing the spinner the router already
    // renders while it waits.
    if (!server) {
        return null;
    }

    return (
        <ServerContentBlock title={'Software & Version'} showFlashKey={'software'}>
            <SoftwarePicker identifier={server.identifier} />
        </ServerContentBlock>
    );
};
