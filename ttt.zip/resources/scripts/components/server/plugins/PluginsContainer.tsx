import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLightbulb, faPuzzlePiece, faSearch } from '@fortawesome/free-solid-svg-icons';
import PageContentBlock from '@/components/elements/PageContentBlock';
import Spinner from '@/components/elements/Spinner';
import { ServerContext } from '@/state/server';
import useSWR from 'swr';
import useFlash from '@/plugins/useFlash';
import useServerPlatform from '@/plugins/useServerPlatform';
import tw from 'twin.macro';
import {
    AddOnHit,
    AddOnSort,
    AddOnVersion,
    Provider,
    ProviderFailure,
    describeFailure,
    searchAddOns,
} from '@/api/server/plugins/providers';
import AddOnVersions from './AddOnVersions';
import { getProviderKeys } from '@/api/server/plugins/providerKeys';
import { spigotMarker } from '@/api/server/plugins/spigetFilename';
import { addonKey, addonKeyAliases } from '@/api/server/plugins/addonKey';
import { providerLabel, providerPageUrl } from '@/api/server/plugins/panelFallback';
import { InstallProgress, installFromProvider, listInstalled } from '@/api/server/plugins/install';
import { SoftwareResponse, getSoftware } from '@/api/server/software';
import { loadersFor } from '@/plugins/loaders';
import { usePermissions } from '@/plugins/usePermissions';

const PER_PAGE = 12;

/**
 * What each ordering actually does, in words.
 *
 * Named keys rather than the nested ternary this replaced: the old shape put the
 * wording three levels deep inside a `title` attribute, so reading any one
 * option's meaning meant working out which branch it fell into. A lookup also
 * gives the <select> a title describing the current choice, which is where a
 * user actually looks.
 */
const SORT_EXPLAINED: Record<AddOnSort, string> = {
    relevance: "Each source's own best match for what you typed, taken in turn so no source fills the page",
    downloads: 'Rank every source together by download count',
    name: 'Alphabetical by name',
    mixed: 'Take the top result from each source in turn, so no source fills the page',
};

// Bounded on purpose: this list is the one that used to be unbounded.
/** Modrinth's maximum page size. We fetch one window and page within it. */
const WINDOW = 100;

/**
 * How long the "installed" banner stays up.
 *
 * Three seconds is long enough to read a filename off it and short enough that
 * the next thing you do is not done underneath it.
 */
const SUCCESS_FLASH_MS = 3000;

/**
 * Failures get longer: five seconds rather than three.
 *
 * A failure is the one banner you have to act on rather than merely notice, and
 * the reason is usually on it -- a version that no longer exists, an add-on the
 * browser could not reach. Two seconds less of reading is two seconds more of
 * clicking something that will fail again.
 */
const FAILURE_FLASH_MS = 5000;

const bytes = (value: number): string => {
    if (value <= 0) return '0 B';
    const units = ['B', 'KiB', 'MiB', 'GiB'];
    const i = Math.min(Math.floor(Math.log(value) / Math.log(1024)), units.length - 1);

    return `${(value / 1024 ** i).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
};

/**
 * The key a card and the installed listing both derive a project from.
 *
 * One function on purpose. Written twice, the two disagreed: the listing reduced
 * `FastAsyncWorldEdit-Bukkit-2.15.4.jar` to the project it was installed as,
 * while the card derived `spigot-<id>` from the hit, so the card offered Install
 * for a plugin already in the directory. Both sides run through addonKey, so a
 * platform word in the title does not split a project from its own file.
 */
const markerFor = (hit: AddOnHit): string =>
    addonKey(
        hit.provider === 'spigot'
            ? spigotMarker(hit.spigotName ?? hit.title, hit.spigetId ?? 0)
            : (hit.projectId ?? hit.title)
    );

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid);
    const server = ServerContext.useStoreState((state) => state.server.data);
    const { addFlash, clearFlashes } = useFlash();

    // What the server is really running, read straight from GET /software. The
    // picker that changes it now lives on its own "Software & Version" page, so
    // this page only reads the response -- but it reads the server's answer
    // rather than guessing, because a guess that is wrong sends add-ons to the
    // wrong directory. The SWR key is the picker's, so a change made over there
    // is already in this cache when the user comes back.
    const identifier = server?.identifier;
    const { data: softwareData } = useSWR<SoftwareResponse>(
        identifier ? ['server:software', identifier] : null,
        () => getSoftware(identifier as string)
    );
    const currentSoftware = softwareData?.current;
    const software = currentSoftware
        ? {
              name: currentSoftware.name,
              supports: currentSoftware.supports,
              installDir: currentSoftware.install_dir,
              version: currentSoftware.version ?? currentSoftware.version_default ?? '',
          }
        : null;

    // The Minecraft version used to filter Modrinth results. Seeded from the
    // server's own version variable, then freely editable because Modrinth
    // publishes versions faster than this file can be updated.
    const { version: gameVersion, setVersion } = useServerPlatform(server?.identifier);
    const [query, setQuery] = useState('');
    const [term, setTerm] = useState('');
    const [page, setPage] = useState(1);
    const [hits, setHits] = useState<AddOnHit[]>([]);
    const [providers, setProviders] = useState<Provider[]>(['modrinth', 'spigot', 'hangar']);
    // Sources the panel can actually use right now. CurseForge needs an API key
    // it does not have until an operator sets one, so it is not offered at all
    // rather than offered and silently returning nothing.
    const [available, setAvailable] = useState<Record<string, { name: string; configured: boolean }>>({});
    const [keyHint, setKeyHint] = useState<string | null>(null);
    const [deadProviders, setDeadProviders] = useState<ProviderFailure[]>([]);
    const [total, setTotal] = useState(0);
    const [truncated, setTruncated] = useState(false);
    const [searching, setSearching] = useState(true);
    const [progress, setProgress] = useState<InstallProgress | null>(null);
    const [busySlug, setBusySlug] = useState<string | null>(null);
    // Which add-ons are present, keyed by the same rule the search cards use.
    // Only the badge needs this: the page deliberately does not list installed
    // add-ons, so the remove control lives on a search result and finding the
    // plugin you want to remove means searching for it.
    const [installed, setInstalled] = useState<Record<string, string>>({});
    // "Most downloaded" is the default: it is what someone opening a plugin
    // browser is looking for. The other two are a deliberate escape hatch
    // rather than a preference -- see the AddOnSort docblock.
    const [sort, setSort] = useState<AddOnSort>('relevance');

    const directory = software?.installDir ?? 'plugins';
    const isMod = software?.supports === 'mods';

    /**
     * Whether this user may install at all.
     *
     * `plugin.update` says "may install"; `file.*` says "may write to disk", and
     * the install needs both -- the jar is pushed through Wings' upload endpoint,
     * which the ordinary file permissions already backstop on the server. This
     * is the half that can be withheld without taking file access away.
     *
     * Owners and root admins get `*` and pass automatically.
     */
    const [canInstall] = usePermissions(['plugin.update']);
    // Memoised on the software NAME, not on `software`. loadersFor() returns a
    // fresh array, and this value is a dependency of the search effect below: an
    // unmemoised array changes identity on every render, the effect refires,
    // the search sets state, the component re-renders, and the page spins until
    // React throws "Maximum update depth exceeded" and the error boundary takes
    // over the whole view.
    const softwareName = software?.name;
    const loaders = useMemo(() => (softwareName ? loadersFor(softwareName) : []), [softwareName]);

    useEffect(() => {
        getProviderKeys()
            .then((keys) => {
                const map: Record<string, { name: string; configured: boolean }> = {};
                keys.forEach((k) => {
                    map[k.id] = { name: k.name, configured: k.configured };
                });
                setAvailable(map);

                const usable = keys.filter((k) => k.configured).map((k) => k.id as Provider);
                setProviders((prev) => prev.filter((p) => usable.includes(p)));

                // Explain a source that exists but is switched off, so its
                // absence is not mistaken for the panel not supporting it.
                const unconfigured = keys.find((k) => !k.configured && k.hint);
                setKeyHint(unconfigured ? `${unconfigured.name}: ${unconfigured.hint}` : null);
            })
            .catch(() => setAvailable({}));
    }, []);

    const refreshInstalled = useCallback(async () => {
        if (!uuid) return;

        try {
            const map: Record<string, string> = {};
            (await listInstalled(uuid, directory)).forEach((addon) => {
                // The key rule lives in addonKey so this and the card's marker
                // cannot drift apart. Written separately, they disagreed:
                // FastAsyncWorldEdit-Bukkit-2.15.4.jar and Simple-Tpa-8.0.jar
                // never matched their own project, so those cards offered an
                // Install button for something already installed and no way to
                // remove it.
                addonKeyAliases(addon.name).forEach((key) => {
                    map[key] = addon.name;
                });
            });
            setInstalled(map);
        } catch (e: any) {
            setInstalled({});
        }
    }, [uuid, directory]);

    // One window is fetched and the loader filter is applied inside search(),
    // so paging happens over the FILTERED list. Paging server-side instead
    // would show short pages and duplicate cards across boundaries.
    const runSearch = useCallback(
        async (nextTerm: string) => {
            setSearching(true);
            try {
                const result = await searchAddOns({
                    query: nextTerm,
                    loaders,
                    gameVersion,
                    supports: isMod ? 'mods' : 'plugins',
                    providers,
                    sort,
                    limit: WINDOW,
                });

                setHits(result.hits);
                setTotal(result.hits.length);
                setTruncated(result.truncated);
                setDeadProviders(result.failed);
            } catch (e: any) {
                setHits([]);
                setTotal(0);
                setTruncated(false);
                // The page renders only flashes carrying its own key (see
                // showFlashKey on PageContentBlock), so this must be keyed too
                // or a failed search says nothing at all.
                addFlash({
                    key: 'plugins',
                    type: 'error',
                    title: 'Error',
                    message: e?.response?.data?.error ?? e?.message ?? 'Could not reach the plugin providers.',
                });
                expireFlash('plugins', FAILURE_FLASH_MS);
            } finally {
                setSearching(false);
            }
        },
        [loaders, isMod, gameVersion, providers, sort, addFlash]
    );

    // Default list on open, and whenever the platform, version or ordering
    // changes. `sort` belongs here because the ordering is applied to what the
    // providers returned, not only to the rendered slice: picking "Most
    // downloaded" asks each source for its most-downloaded page, which is a
    // different request and not a re-order of the one already in hand.
    useEffect(() => {
        setPage(1);
        runSearch(term);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [loaders, isMod, gameVersion, providers, sort]);

    useEffect(() => {
        refreshInstalled();
    }, [refreshInstalled]);

    // Clamp if the page falls outside the (possibly smaller) filtered set.
    useEffect(() => {
        const max = Math.max(1, Math.ceil(hits.length / PER_PAGE));
        if (page > max) {
            setPage(max);
        }
    }, [hits.length, page]);


    /**
     * Where to send the user after an install that failed on every route.
     *
     * A flash saying "could not download X" with no way forward is a dead end, and
     * avoiding that dead end is the whole point of the fallback chain: the panel
     * could not reach the file either, so the provider's own page is what is
     * left. Held as state rather than folded into the flash because the link has
     * to outlive the banner -- the user reads the error, then goes looking for
     * the button.
     */
    const [escapeHatch, setEscapeHatch] = useState<{ title: string; provider: string; url: string } | null>(null);

    // The project whose versions are open. `null` is "closed"; there is no
    // point in the picker remembering a closed project's list.
    const [picking, setPicking] = useState<AddOnHit | null>(null);

    // Pending expiry for the success banner, so a second install replaces the
    // first one's timer instead of queueing a second clear behind it.
    const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

    /**
     * Put a flash up and take it away again on a timer.
     *
     * The flash store keys nothing it can expire -- a flash has no id, and the
     * renderer falls back to `type + message` as the React key -- so the only
     * thing that can be removed is the page's whole set, by key. That is why
     * this takes the key as an argument rather than hardcoding it, and why it
     * is only ever pointed at a key this component itself created.
     */
    const expireFlash = useCallback(
        (key: string, ms: number) => {
            if (flashTimer.current) {
                clearTimeout(flashTimer.current);
            }

            flashTimer.current = setTimeout(() => clearFlashes(key), ms);
        },
        [clearFlashes]
    );

    // A timer outliving the page would clear flashes belonging to whatever the
    // user has navigated to, since the store is global and outlives this view.
    useEffect(
        () => () => {
            if (flashTimer.current) {
                clearTimeout(flashTimer.current);
            }
        },
        []
    );

    /**
     * @param version the row picked in the version list, or null for a plain
     *   "install whatever is newest". A version that was asked for is never
     *   silently replaced by the newest one: that would install something other
     *   than the row the user clicked.
     */
    const onInstall = async (hit: AddOnHit, version: AddOnVersion | null = null) => {
        if (!uuid) return;

        setEscapeHatch(null);

        setBusySlug(hit.key);
        setProgress({ phase: 'resolving', percent: 0, message: 'Starting…' });
        try {
            const result = await installFromProvider(uuid, directory, hit, {
                loaders,
                gameVersions: gameVersion ? [gameVersion] : [],
                onProgress: setProgress,
                chosen: version,
            });

            // Closed only on success, so a failed install leaves the list open
            // with the version still selected and the error beside it.
            setPicking(null);
            addFlash({
                key: 'plugins',
                type: 'success',
                title: 'Installed',
                message:
                    hit.provider === 'spigot'
                        ? `${result.filename} — Spiget only serves this resource's newest build, and it is not checked against ${gameVersion || 'the selected version'}. Restart the server to load it.`
                        : `${result.filename} (${result.version}). Restart the server to load it.`,
            });
            expireFlash('plugins', SUCCESS_FLASH_MS);
            await refreshInstalled();
        } catch (e: any) {
            addFlash({
                key: 'plugins',
                type: 'error',
                title: 'Install failed',
                message: e?.response?.data?.error ?? e?.message ?? 'Installation failed.',
            });
            expireFlash('plugins', FAILURE_FLASH_MS);

            // Offered only when there is a page to go to. Any other failure has
            // no route, and a link here would be a guess dressed as a solution.
            const url = e?.webUrl ?? providerPageUrl(hit);

            if (url) {
                setEscapeHatch({ title: hit.title, provider: providerLabel(hit), url });
            }
        } finally {
            setBusySlug(null);
            setProgress(null);
        }
    };

    const pageCount = Math.max(1, Math.ceil(hits.length / PER_PAGE));
    const visible = useMemo(
        () => hits.slice((page - 1) * PER_PAGE, page * PER_PAGE),
        [hits, page]
    );

    return (
        <PageContentBlock title={isMod ? 'Mods' : 'Plugins'} showFlashKey={'plugins'}>
            <h1 className={'at-pagehead-blue'}>{isMod ? 'Mods' : 'Plugins'}</h1>

            {/* Which sources to search. Spigot is only useful for Bukkit-family
                software: its results are jars for a Spigot/Paper server, so
                offering them for a Forge or Fabric server would be noise. */}
            {!isMod && (
                <div className={'at-providers'} role={'group'} aria-label={'Plugin sources'}>
                    {(['modrinth', 'spigot', 'hangar', 'curseforge'] as Provider[])
                        .filter((id) => available[id]?.configured !== false)
                        .map((id) => {
                        const on = providers.includes(id);
                        const label = available[id]?.name ?? id;

                        return (
                            <button
                                key={id}
                                type={'button'}
                                className={`at-chipbtn${on ? ' at-chipbtn--on' : ''}`}
                                aria-pressed={on}
                                onClick={() =>
                                    setProviders((prev) =>
                                        prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
                                    )
                                }
                            >
                                {label}
                            </button>
                        );
                    })}
                    {keyHint && <span className={'at-providers__hint'}>{keyHint}</span>}
                    {deadProviders.length > 0 && (
                        <span className={'at-providers__warn'}>
                            {deadProviders
                                .map((f) => `${f.provider === 'spigot' ? 'Spigot' : f.provider} ${describeFailure(f)}`)
                                .join('; ')}
                        </span>
                    )}
                </div>
            )}

            {/* Shown only after an install that failed on every route. It is the
                last tier: the browser could not fetch the file, the panel could not
                either, and the provider's own page is what remains. */}
            {escapeHatch && (
                <div className={'at-escape'} role={'status'}>
                    <span className={'at-escape__text'}>
                        {escapeHatch.title} could not be downloaded from {escapeHatch.provider} — neither your
                        browser nor the panel could reach it.
                    </span>
                    <a
                        className={'at-btn at-btn--sm at-btn--secondary at-pcard__visit'}
                        href={escapeHatch.url}
                        target={'_blank'}
                        rel={'noopener noreferrer'}
                    >
                        Open on {escapeHatch.provider}
                    </a>
                </div>
            )}

            {/*
                A <select> rather than a row of chips. Four options with names
                this similar is what a dropdown is for, and it costs one control
                of toolbar instead of four -- which matters because the row above
                already carries a chip per source and the two rows together were
                pushing the search box onto its own line on a narrow screen.

                Each option still says what it actually does, because "Even mix"
                in particular is not obviously round-robin. Browsers are
                inconsistent about showing an <option>'s title, so the same text
                is also on the control itself, describing whichever option is
                currently chosen.
            */}
            <div className={'at-sort'}>
                <label className={'at-sort__label'} htmlFor={'plugin-sort'}>
                    Sort
                </label>
                <select
                    id={'plugin-sort'}
                    className={'at-sort__select'}
                    value={sort}
                    onChange={(e) => setSort(e.target.value as AddOnSort)}
                    title={SORT_EXPLAINED[sort]}
                >
                    {(
                        [
                            ['relevance', 'Relevance'],
                            ['downloads', 'Most downloaded'],
                            ['name', 'A–Z'],
                            ['mixed', 'Even mix'],
                        ] as [AddOnSort, string][]
                    ).map(([value, label]) => (
                        <option key={value} value={value} title={SORT_EXPLAINED[value]}>
                            {label}
                        </option>
                    ))}
                </select>
            </div>

            {/* toolbar: suggest, search */}
            <div className={'at-toolbar'}>
                <a
                    className={'at-suggest'}
                    href={'https://modrinth.com/'}
                    target={'_blank'}
                    rel={'noopener noreferrer'}
                    title={'Suggest an add-on on Modrinth'}
                >
                    <FontAwesomeIcon icon={faLightbulb} />
                    Suggest {isMod ? 'a mod' : 'a plugin'}
                </a>

                <form
                    className={'at-search'}
                    onSubmit={(e) => {
                        e.preventDefault();
                        setPage(1);
                        runSearch(query);
                    }}
                >
                    <input
                        type={'search'}
                        placeholder={'Search…'}
                        aria-label={'Search add-ons'}
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                    />
                    <button type={'submit'} aria-label={'Search'}>
                        {searching ? <Spinner size={'small'} /> : <FontAwesomeIcon icon={faSearch} />}
                    </button>
                </form>
            </div>

            {/* The installed-plugins strip used to live here. It was removed
                because it grew without bound: a server with a hundred add-ons
                pushed everything else down the page, and the list was the only
                thing on it that got longer over time.

                Nothing was lost by dropping it. `installed` is still fetched and
                still drives the "Installed" badge on each card, which is also
                where removal happens, and the panel's file manager can delete a
                jar for anything not in the current results. */}

            {/* Be honest that the browsable window is capped, instead of
                implying every result is one click away. */}
            {truncated && !term && (
                <p className={'at-text-muted'} css={tw`text-xs mb-3`}>
                    Showing the {hits.length} most-downloaded {isMod ? 'mods' : 'plugins'} of{' '}
                    {total.toLocaleString()}. Use the search box to narrow it down.
                </p>
            )}

            {/* card grid */}
            {searching && hits.length === 0 && (
                <div css={tw`flex justify-center py-12`}>
                    <Spinner size={'large'} />
                </div>
            )}

            {!searching && hits.length === 0 && (
                <div className={'at-empty'}>
                    <div className={'at-empty__icon'}>
                        <FontAwesomeIcon icon={faPuzzlePiece} css={tw`text-2xl`} />
                    </div>
                    <div className={'at-empty__title'}>Nothing found</div>
                    <p className={'at-empty__text'}>
                        {term
                            ? `No ${isMod ? 'mods' : 'plugins'} matched “${term}” for this platform.`
                            : `No ${isMod ? 'mods' : 'plugins'} available for this platform.`}
                    </p>
                </div>
            )}

            <div className={'at-pgrid'}>
                {visible.map((hit) => {
                    const busy = busySlug === hit.key;
                    const marker = markerFor(hit);
                    const already = installed[marker];
                    // Null for an installable project, so the Install button stays the
                    // primary action and this is never worked out for one.
                    const externalUrl = hit.external ? providerPageUrl(hit) : null;

                    return (
                        <div key={hit.key} className={'at-pcard'}>
                            <button
                                type={'button'}
                                className={'at-pcard__head at-pcard__head--link'}
                                title={`Choose a version of ${hit.title}`}
                                onClick={() => setPicking(hit)}
                            >
                                {hit.title}
                                <span className={`at-pcard__src at-pcard__src--${hit.provider}`}>
                                    {available[hit.provider]?.name ?? hit.provider}
                                </span>
                            </button>
                            <div className={'at-pcard__body'}>
                                <span className={'at-pcard__desc'}>{hit.description}</span>
                            </div>
                            <div className={'at-pcard__foot'}>
                                <span className={'at-pcard__type'}>
                                    {hit.provider === 'modrinth'
                                        ? isMod
                                            ? 'Mod'
                                            : 'Plugin'
                                        : 'Plugin · latest build'}
                                </span>
                    {/*
                        A project whose jar is published elsewhere cannot be installed
                        from here, so an Install button on it could only ever fail. The
                        link is the useful action instead: the user can still get the
                        plugin, just not from this panel.
                    */}
                    {already ? (
                        /* A status, not a control. This used to be a button that
                           removed the file, which put a destructive action in the
                           same place as a browse-and-install list. Removing an
                           add-on is done in the File Manager; here the card only
                           reports what is already there. */
                        <span
                            className={'at-pcard__installed'}
                            title={`${already} is in ${directory}/`}
                        >
                            Installed
                        </span>
                    ) : externalUrl ? (
                        <a
                            className={'at-btn at-btn--sm at-btn--secondary at-pcard__visit'}
                            href={externalUrl}
                            target={'_blank'}
                            rel={'noopener noreferrer'}
                            title={`Open ${hit.title} on ${providerLabel(hit)} to download it there`}
                        >
                            Open on {providerLabel(hit)}
                        </a>
                    ) : (
                        <button
                            type={'button'}
                            className={'at-btn at-btn--sm at-btn--primary'}
                            css={tw`!py-0.5 !px-2.5 !text-[11px]`}
                            disabled={busySlug !== null || !canInstall}
                            // A reason on hover rather than a missing button: a
                            // card you can see with no Install on it is a
                            // question, and this is the answer.
                            title={
                                !canInstall
                                    ? `You need the plugin.update permission to install ${hit.title}`
                                    : `Install ${hit.title}`
                            }
                            onClick={() => onInstall(hit)}
                        >
                            {busy ? (
                                <>
                                    <Spinner size={'small'} /> {progress?.percent ?? 0}%
                                </>
                            ) : (
                                'Install'
                            )}
                        </button>
                    )}
                                <span className={'at-pcard__src'}>modrinth.com</span>
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* pagination */}
            {pageCount > 1 && (
                <div className={'at-pager'}>
                    <button
                        type={'button'}
                        className={'at-pager__btn'}
                        disabled={page <= 1}
                        onClick={() => setPage(page - 1)}
                    >
                        ‹
                    </button>
                    {Array.from({ length: Math.min(pageCount, 7) }, (_, i) => i + 1).map((n) => (
                        <button
                            key={n}
                            type={'button'}
                            className={`at-pager__btn${n === page ? ' at-pager__btn--active' : ''}`}
                            onClick={() => setPage(n)}
                        >
                            {n}
                        </button>
                    ))}
                    <button
                        type={'button'}
                        className={'at-pager__btn'}
                        disabled={page >= pageCount}
                        onClick={() => setPage(page + 1)}
                    >
                        ›
                    </button>
                </div>
            )}
            {/*
                Inside PageContentBlock rather than beside it: the component's
                return is a single root, so a sibling here would need a fragment
                around everything.
            */}
            {picking ? (
                <AddOnVersions
                    hit={picking}
                    busy={busySlug !== null}
                    // The picker is a second way to install, so it has to ask the
                    // same question the card's Install button does.
                    canInstall={canInstall}
                    // The same loaders the search filtered by, so the version list
                    // and the result list agree on what this server can run. A
                    // search that hid the NeoForge builds and a version list that
                    // recommended one would be describing different worlds.
                    loaders={loaders}
                    gameVersion={gameVersion}
                    onClose={() => setPicking(null)}
                    onInstall={(target, version) => onInstall(target, version)}
                />
            ) : null}
        </PageContentBlock>
    );
};
