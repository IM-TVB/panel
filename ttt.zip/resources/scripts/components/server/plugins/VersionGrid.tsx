// The default React import is required even though no React.* member is used
// directly: this panel compiles JSX with the classic runtime, so JSX lowers to
// React.createElement() and needs React in scope. Without it the page throws
// "ReferenceError: React is not defined" and the error boundary swallows the
// whole view.
import React, { useMemo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBoxOpen, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import { MINECRAFT_VERSIONS } from '@/api/server/plugins/versions';
import useAddonCounts from '@/plugins/useAddonCounts';

interface Props {
    /** Software name, shown as the blue heading above the grid. */
    softwareName: string;
    loaders: string[];
    supports: 'plugins' | 'mods';
    /** Currently chosen version; empty means "any version". */
    value: string;
    onChange: (version: string) => void;
    /**
     * Sets the free-text mode explicitly rather than toggling it. A toggle
     * looked harmless but was not: clicking a listed version called
     * onCustom() -> true, so picking "1.21.8" also opened the "Other…" field
     * and marked that card current. The version and the free-text field have to
     * be mutually exclusive, so the grid states which one is active.
     */
    onCustomChange: (custom: boolean) => void;
    custom: boolean;
}

/**
 * Aternos' version picker: a grid of green cards, newest release first, each
 * showing the version and how many add-ons Modrinth offers for it, with the
 * active version ringed.
 *
 * The version list comes from Mojang's manifest rather than from the software's
 * own API, because each server software publishes a different subset of
 * versions and a per-software integration would need its own endpoint. Versions
 * the chosen software does not publish are handled by the egg's install script,
 * which falls back to its newest build and says so in the install log.
 */
export default ({
    softwareName,
    loaders,
    supports,
    value,
    onChange,
    onCustomChange,
    custom,
}: Props) => {
    const projectType = supports === 'mods' ? 'mod' : 'plugin';

    // Memoised on the values that actually change the query, not on the array
    // identity, so the effect inside the hook does not restart every render.
    const versions = useMemo(() => MINECRAFT_VERSIONS, []);
    const counts = useAddonCounts(versions, loaders, projectType);

    const noun = projectType === 'mod' ? 'mods' : 'plugins';

    return (
        <div className={'at-vgrid-wrap'}>
            <h2 className={'at-vgrid__head'}>{softwareName}</h2>

            <div className={'at-vgrid'} role={'group'} aria-label={'Minecraft version'}>
                {versions.map((version) => {
                    const active = !custom && value === version;
                    const count = counts[version];

                    return (
                        <button
                            key={version}
                            type={'button'}
                            className={`at-vcard${active ? ' at-vcard--current' : ''}`}
                            aria-pressed={active}
                            title={`${version} — ${count === undefined ? 'counting add-ons…' : `${count} ${noun}`}`}
                            onClick={() => {
                                onCustomChange(false);
                                onChange(version);
                            }}
                        >
                            <FontAwesomeIcon icon={faBoxOpen} css={{ marginRight: '6px' }} />
                            <span className={'at-vcard__version'}>{version}</span>
                            <span className={'at-vcard__count'}>
                                {count === undefined ? '…' : `(${count})`}
                            </span>
                            {active && (
                                <FontAwesomeIcon
                                    icon={faCheckCircle}
                                    css={{ position: 'absolute', right: '6px', top: '6px', fontSize: '10px' }}
                                />
                            )}
                        </button>
                    );
                })}

                <button
                    type={'button'}
                    className={`at-vcard at-vcard--other${custom ? ' at-vcard--current' : ''}`}
                    aria-pressed={custom}
                    onClick={() => onCustomChange(true)}
                >
                    <FontAwesomeIcon icon={faBoxOpen} css={{ marginRight: '6px' }} />
                    <span className={'at-vcard__version'}>Other…</span>
                </button>
            </div>

            {custom && (
                <input
                    type={'text'}
                    className={'at-input at-vgrid__custom'}
                    autoFocus
                    placeholder={'e.g. 1.99.9'}
                    aria-label={'Custom Minecraft version'}
                    value={custom ? value : ''}
                    onChange={(e) => onChange(e.target.value)}
                />
            )}
        </div>
    );
};
