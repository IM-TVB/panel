// The default React import is required even though no React.* member is used
// directly: this panel compiles JSX with the classic runtime, so JSX lowers to
// React.createElement() and needs React in scope. Without it the page throws
// "ReferenceError: React is not defined" and the error boundary swallows the
// whole view.
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import useSWR from 'swr';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faArrowLeft,
    faBoxOpen,
    faCheckCircle,
    faExclamationTriangle,
    faLock,
    faPuzzlePiece,
    faSyncAlt,
} from '@fortawesome/free-solid-svg-icons';
import type { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import Modal from '@/components/elements/Modal';
import Spinner from '@/components/elements/Spinner';
import { ServerBackup } from '@/api/server/types';
import useServerBackups from '@/api/swr/getServerBackups';
import useFlash from '@/plugins/useFlash';
import Switch from '@/components/elements/Switch';
import VersionGrid from '@/components/server/plugins/VersionGrid';
import {
    SoftwareResponse,
    SoftwareOption,
    changeSoftware,
    changeSoftwareError,
    getSoftware,
} from '@/api/server/software';
// The software-to-loader table lives in its own module: it decides whether a
// search result is shown at all, and inside a component it could not be
// imported into a test without dragging the whole Babel pipeline along.
import { loadersFor } from '@/plugins/loaders';

/**
 * Modrinth loaders per software, derived from the software the server actually
 * runs. Keyed by egg name because that is what the panel knows the server by.
 *
 * A server whose software is not listed here still gets a usable result: we
 * fall back to matching the software name against the loader vocabulary rather
 * than showing an empty store. What we never do is invent a software that has
 * no install script behind it.
 */

const iconFor = (supports: 'plugins' | 'mods', name: string): IconDefinition => {
    if (name.toLowerCase().includes('bungee')) return faPuzzlePiece;
    if (supports === 'mods') return faBoxOpen;
    return faCheckCircle;
};

interface Props {
    identifier: string;
    /**
     * Reported upward so the add-on list can filter for the software that is
     * really installed rather than for a guess held in the browser.
     */
    onSoftwareChange?: (value: { name: string; supports: 'plugins' | 'mods'; installDir: string; version: string }) => void;
}

export default ({ identifier, onSoftwareChange }: Props) => {
    const { data, mutate, error: loadError } = useSWR<SoftwareResponse>(
        ['server:software', identifier],
        () => getSoftware(identifier)
    );

    const [version, setVersion] = useState('');
    const [saving, setSaving] = useState(false);
    const [pending, setPending] = useState<SoftwareOption | null>(null);
    const [changeError, setChangeError] = useState<string | null>(null);
    // Two steps, as on Aternos: pick the software, then pick one of its
    // versions. The version grid lives on the second step, not on the page, so
    // a reinstall can never be one click away from the software list.
    const [step, setStep] = useState<'software' | 'version'>('software');
    const [chosen, setChosen] = useState<SoftwareOption | null>(null);
    // True once the user picks "Other…" in the version grid, revealing a
    // free-text field for a version newer than Mojang's published list.
    const [custom, setCustom] = useState(false);
    const { data: backups } = useServerBackups();
    const { addFlash, clearFlashes } = useFlash();

    // How long the "Reinstalling ..." message stays up. The plugin page's
    // success message uses the same three seconds, so the two pages behave the
    // same way.
    const SUCCESS_FLASH_MS = 3000;

    // Pending expiry for that message, so a second reinstall replaces the
    // first one's timer instead of queueing a second clear behind it.
    const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

    /**
     * Put the message up and take it away again on a timer.
     *
     * The flash store keys nothing it can expire -- a flash has no id, and the
     * renderer falls back to `type + message` as the React key -- so the only
     * thing that can be removed is the page's whole set, by key. That is why
     * this takes the key as an argument rather than hardcoding it, and why it
     * is only ever pointed at a key this component itself created.
     */
    const expireFlash = useCallback(
        (key: string, ms: number) => {
            if (flashTimer.current) {
                clearTimeout(flashTimer.current);
            }

            flashTimer.current = setTimeout(() => clearFlashes(key), ms);
        },
        [clearFlashes]
    );

    // A timer outliving the page would clear flashes belonging to whatever the
    // user has navigated to, since the store is global and outlives this view.
    // The message itself goes with it: the store is global too, so a flash
    // left behind would still be sitting there when the user came back, and
    // would be shown again as though the reinstall were still running.
    useEffect(
        () => () => {
            if (flashTimer.current) {
                clearTimeout(flashTimer.current);
            }

            clearFlashes('software');
        },
        [clearFlashes]
    );

    const current = data?.current;

    // Seed the field from the server, and re-seed whenever the server changes.
    useEffect(() => {
        setVersion(current?.version ?? current?.version_default ?? '');
    }, [current?.egg_id, current?.version]);

    const restorable = useMemo(
        () => (backups?.items ?? []).filter((b: ServerBackup) => b.isSuccessful && !!b.completedAt),
        [backups]
    );

    // While the user is on the version step, browsing the add-on list should
    // reflect the software they are about to install, not the one still running.
    const effective = chosen ?? current;

    useEffect(() => {
        if (!effective || !onSoftwareChange) return;
        onSoftwareChange({
            name: effective.name,
            supports: effective.supports,
            installDir: effective.install_dir,
            version: version || effective.version || '',
        });
    }, [effective?.name, effective?.supports, effective?.install_dir, version]);

    const loaders = useMemo(() => (effective ? loadersFor(effective.name) : []), [effective?.name]);

    // A reinstall is needed when the software differs, *or* when only the version
    // does. Comparing egg ids alone made "same software, different version" look
    // like nothing to do, so the one change that keeps the software and moves the
    // game version was impossible to make.
    const needsReinstall =
        !!chosen &&
        !!current &&
        (chosen.egg_id !== current.egg_id ||
            (!!version && version !== (current.version ?? current.version_default ?? '')));

    const confirmChange = useCallback(
        async (backup: ServerBackup | null, deleteFiles: boolean) => {
            if (!pending) return;
            setSaving(true);
            setChangeError(null);

            try {
                const next = await changeSoftware(identifier, {
                    egg_id: pending.egg_id,
                    // The version picked on the second step. This was missing, and
                    // the button above promises "Reinstall as Paper 1.21.4" -- so
                    // the server was reinstalled with the egg's *default* version
                    // and the chosen one was silently discarded. The endpoint has
                    // always accepted and validated `version`; nothing sent it.
                    ...(version ? { version } : {}),
                    // Always sent, never inferred. The endpoint treats an absent
                    // flag as "delete", so omitting it here would make the
                    // choice the user just made depend on a default.
                    delete_files: deleteFiles,
                    // Optional: the operator does not require a recovery point
                    // before a software change. Sent only when one was chosen.
                    ...(backup ? { backup: backup.uuid } : {}),
                    acknowledged: true,
                });
                await mutate(next, false);
                setPending(null);

                // A reinstall is asynchronous: the panel has only asked the
                // daemon to do it, so the server sits in "installing" until
                // Wings finishes. Saying so is the difference between "it
                // worked" and "nothing happened".
                addFlash({
                    // Keyed so the "Software & Version" page renders it: that
                    // page shows the flash by this key, and an unkeyed message
                    // would render nowhere.
                    key: 'software',
                    type: 'success',
                    title: `Reinstalling ${next.current.name}`,
                    message: [
                        next.current.version
                            ? `The server is being reinstalled as ${next.current.name} ${next.current.version}.`
                            : `The server is being reinstalled as ${next.current.name}.`,
                        deleteFiles
                            ? 'Its existing files were deleted, including the world.'
                            : 'Its existing files were kept, so old plugins and configs are still there — some may not load on the new software.',
                        backup ? 'Your backup is untouched — restore it afterwards to get the world back.' : 'No backup was taken, so the world cannot be brought back.',
                    ].join(' '),
                });

                // The message is a report, not a state: the reinstall itself is
                // asynchronous and the panel has no way of watching it, so the
                // banner is all the confirmation there is. It has to go away on
                // its own, the way the plugin page's does -- otherwise it sits
                // there for the rest of the session looking like something that
                // is still happening.
                expireFlash('software', SUCCESS_FLASH_MS);
            } catch (e) {
                setChangeError(changeSoftwareError(e));
            } finally {
                setSaving(false);
            }
        },
        // `version` is read inside, so a change of it has to re-create the
        // callback -- otherwise a stale closure would reinstall the version that
        // was selected when the dialog was opened, not the one now shown.
        [pending, identifier, version, mutate, addFlash, expireFlash]
    );

    if (loadError) {
        return <p className={'at-software-error'}>Could not load the software list for this server.</p>;
    }

    if (!data || !current) {
        return (
            <div className={'at-software-loading'}>
                <Spinner />
                <span>Loading software…</span>
            </div>
        );
    }

    const canSwitch = data.can_switch;

    return (
        <div className={'at-software'}>
            {step === 'software' ? (
                <>
                    <div className={'at-software__head'}>
                        <span className={'at-edition'}>Java Edition</span>
                        <span className={'at-software__running'}>
                            Running <strong>{current.name}</strong>
                        </span>
                    </div>

                    <div className={'at-scards'}>
                        {data.options.map((option: SoftwareOption) => {
                            const active = option.egg_id === current.egg_id;
                            const Icon = iconFor(option.supports, option.name);
                            const locked = !active && !canSwitch;

                            return (
                                <button
                                    key={option.egg_id}
                                    type={'button'}
                                    className={`at-scard${active ? ' at-scard--active' : ''}${locked ? ' at-scard--locked' : ''}`}
                                    aria-pressed={active}
                                    title={
                                        locked
                                            ? 'Only an administrator can install this software'
                                            : option.description
                                    }
                                    disabled={locked}
                                    onClick={() => {
                                        // Step one only records the choice; nothing
                                        // is reinstalled until the version step.
                                        setChangeError(null);
                                        setChosen(option);
                                        setStep('version');
                                    }}
                                >
                                    <span className={'at-scard__badge'}>{option.badge}</span>
                                    {locked && (
                                        <span className={'at-scard__lock'}>
                                            <FontAwesomeIcon icon={faLock} />
                                        </span>
                                    )}
                                    <span className={'at-scard__icon'}>
                                        <FontAwesomeIcon icon={Icon} />
                                    </span>
                                    <span className={'at-scard__name'}>{option.name}</span>
                                </button>
                            );
                        })}
                    </div>
                </>
            ) : (
                chosen && (
                    <div className={'at-wizard'}>
                        <button
                            type={'button'}
                            className={'at-wizard__back'}
                            onClick={() => {
                                setChosen(null);
                                setStep('software');
                            }}
                        >
                            <FontAwesomeIcon icon={faArrowLeft} css={{ marginRight: '6px' }} />
                            All software
                        </button>

                        <p className={'at-wizard__lead'}>
                            {needsReinstall ? (
                                <>
                                    Choose the Minecraft version to install as <strong>{chosen.name}</strong>.
                                </>
                            ) : (
                                <>
                                    Choose a Minecraft version to browse add-ons for{' '}
                                    <strong>{chosen.name}</strong>. Pick a version different from the one
                                    running to reinstall onto it.
                                </>
                            )}
                        </p>

                        {/* The version grid lives here, on the step reached after
                            choosing software -- not on the plugins page. */}
                        <VersionGrid
                            softwareName={chosen.name}
                            loaders={loaders}
                            supports={chosen.supports}
                            value={version}
                            onChange={setVersion}
                            custom={custom}
                            onCustomChange={setCustom}
                        />

                        <div className={'at-wizard__actions'}>
                            {needsReinstall ? (
                                <>
                                    <button
                                        type={'button'}
                                        className={'at-btn'}
                                        onClick={() => {
                                            setChosen(null);
                                            setStep('software');
                                        }}
                                        disabled={saving}
                                    >
                                        Back
                                    </button>
                                    <button
                                        type={'button'}
                                        className={'at-btn at-btn--danger'}
                                        disabled={saving}
                                        onClick={() => {
                                            setChangeError(null);
                                            setPending(chosen);
                                        }}
                                    >
                                        <FontAwesomeIcon icon={faExclamationTriangle} css={{ marginRight: '8px' }} />
                                        Reinstall as {chosen.name}
                                        {version ? ` ${version}` : ''}
                                    </button>
                                </>
                            ) : (
                                <button
                                    type={'button'}
                                    className={'at-btn at-btn--primary'}
                                    onClick={() => {
                                        setChosen(null);
                                        setStep('software');
                                    }}
                                >
                                    Use this version to browse
                                </button>
                            )}
                        </div>
                    </div>
                )
            )}

            <ChangeSoftwareModal
                visible={!!pending}
                target={pending}
                backups={restorable}
                saving={saving}
                error={changeError}
                onClose={() => {
                    setPending(null);
                    setChangeError(null);
                }}
                onConfirm={confirmChange}
            />
        </div>
    );
};

/**
 * Aternos' confirmation: changing software reinstalls the server and deletes its
 * files. The backup is not optional here, so it is a required choice rather
 * than a checkbox -- there is no path through this dialog without naming a
 * backup that can be restored.
 */
const ChangeSoftwareModal = ({
    visible,
    target,
    backups,
    saving,
    error,
    onClose,
    onConfirm,
}: {
    visible: boolean;
    target: SoftwareOption | null;
    backups: ServerBackup[];
    saving: boolean;
    error: string | null;
    onClose: () => void;
    onConfirm: (backup: ServerBackup | null, deleteFiles: boolean) => void;
}) => {
    const [selected, setSelected] = useState<string>('');
    // Defaults to deleting. That is what a reinstall has always done, and it is
    // the safe direction: keeping files across a software change leaves the old
    // software's plugins in a directory the new software will read.
    const [deleteFiles, setDeleteFiles] = useState(true);

    useEffect(() => {
        // Default to starting fresh rather than silently restoring something.
        if (visible) {
            setSelected('');
            setDeleteFiles(true);
        }
    }, [visible]);

    return (
        <Modal visible={visible} onDismissed={onClose}>
            <div className={'at-modal'}>
                <h2 className={'at-modal__title'}>Change server software</h2>
                <div className={'at-modal__warn'}>
                    <FontAwesomeIcon icon={faExclamationTriangle} />
                    <p>
                        Changing to <strong>{target?.name}</strong> reinstalls this server. Your world, configuration
                        and installed add-ons will be deleted. Aternos behaves the same way — download anything you
                        want to keep first.
                    </p>
                </div>

                {backups.length > 0 ? (
                    <>
                        <p className={'at-modal__label'}>
                            Restore from a backup afterwards? (optional)
                        </p>
                        <ul className={'at-modal__backups'}>
                            <li>
                                <label>
                                    <input
                                        type={'radio'}
                                        name={'at-backup'}
                                        value={''}
                                        checked={selected === ''}
                                        onChange={() => setSelected('')}
                                    />
                                    <span>No — start fresh</span>
                                    <span className={'at-modal__meta'}>the world will be gone</span>
                                </label>
                            </li>
                            {backups.map((backup) => (
                                <li key={backup.uuid}>
                                    <label>
                                        <input
                                            type={'radio'}
                                            name={'at-backup'}
                                            value={backup.uuid}
                                            checked={selected === backup.uuid}
                                            onChange={() => setSelected(backup.uuid)}
                                        />
                                        <span>{backup.name}</span>
                                        <span className={'at-modal__meta'}>
                                            {backup.completedAt
                                                ? new Date(backup.completedAt).toLocaleString()
                                                : 'unknown'}
                                        </span>
                                    </label>
                                </li>
                            ))}
                        </ul>
                    </>
                ) : null}

                {/* What happens to what is already there. A reinstall and a wipe
                    are different operations and the operator is the only one who
                    knows which they want, so it is asked rather than assumed.

                    A switch rather than two radios, so the state is one glance: the
                    label says what ON does, and the description under it changes
                    with the position rather than leaving the consequence to be
                    inferred from which option is ticked.

                    The key is what makes this work. Switch is uncontrolled -- it
                    reads defaultChecked once on mount -- so without a remount the
                    knob would keep the last position while React state said
                    otherwise the next time the dialog opened. Keying on `visible`
                    re-reads the default each time it is shown, which is also the
                    value the effect above resets state to, so the two agree. */}
                <div className={'at-modal__section'}>
                    <Switch
                        key={visible ? 'files-open' : 'files-closed'}
                        name={'at-files'}
                        defaultChecked
                        onChange={(e) => setDeleteFiles(e.target.checked)}
                        label={'Delete existing files'}
                        description={
                            deleteFiles
                                ? 'The world, configs and add-ons are removed. This is what a reinstall has always done.'
                                : 'They stay. The new software is installed over the top, and anything it cannot read is left behind.'
                        }
                    />
                    {!deleteFiles && (
                        <p className={'at-modal__note'}>
                            Plugins built for a different platform will be in the add-on folder but
                            will never load &mdash; and they will not show as installed either, so
                            the failure is silent.
                        </p>
                    )}
                </div>

                {error && <p className={'at-modal__error'}>{error}</p>}

                <div className={'at-modal__actions'}>
                    <button type={'button'} className={'at-btn'} onClick={onClose} disabled={saving}>
                        Cancel
                    </button>
                    <button
                        type={'button'}
                        className={'at-btn at-btn--danger'}
                        disabled={saving}
                        onClick={() => onConfirm(backups.find((b) => b.uuid === selected) ?? null, deleteFiles)}
                    >
                        {saving ? (
                            <>
                                <FontAwesomeIcon icon={faSyncAlt} spin css={{ marginRight: '8px' }} /> Reinstalling…
                            </>
                        ) : (
                            <>
                                <FontAwesomeIcon icon={faExclamationTriangle} css={{ marginRight: '8px' }} />{' '}
                                {deleteFiles ? 'Reinstall' : 'Install over'} {target?.name}
                            </>
                        )}
                    </button>
                </div>
            </div>
        </Modal>
    );
};
