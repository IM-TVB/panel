/**
 * Guards the dependency-identity rules that decide whether the Plugins & Mods
 * page settles or spins.
 *
 * The page shipped broken: `loaders` was assigned an unmemoised array literal
 * and then used as a dependency of the search effect. Every render produced a
 * new array identity, the effect refired, its state updates re-rendered, and
 * React threw "Maximum update depth exceeded" -- which the app-level
 * ErrorBoundary renders as "An error was encountered by the application while
 * rendering this view. Try refreshing the page."
 *
 * This is a source-level check rather than a render test on purpose: this
 * panel's babel toolchain cannot transform TSX under jest (@babel/core 7.18.5
 * against a plugin requiring ^7.22.0), so a .tsx render test cannot run at all.
 * These are exactly the mistakes that a type checker and the bundler both miss,
 * so they are worth asserting even without rendering the component.
 */
import { readFileSync } from 'fs';
import { resolve } from 'path';

const source = readFileSync(
    resolve(__dirname, 'PluginsContainer.tsx'),
    'utf8'
);

/** Every `}, [ ... ])` dependency array in the file. */
const dependencyArrays = (): string[] => {
    const found: string[] = [];
    const pattern = /\}, \[([^\]]*)\]\)/g;
    let match: RegExpExecArray | null;

    while ((match = pattern.exec(source)) !== null) {
        found.push(match[1]);
    }

    return found;
};

describe('PluginsContainer dependency arrays', () => {
    it('declares at least one dependency array to check', () => {
        expect(dependencyArrays().length).toBeGreaterThan(0);
    });

    it('never depends on an inline array or object literal', () => {
        // `}, [[], {}])` or `}, [{ a: 1 }])` would give a fresh identity on every
        // render and re-fire the effect forever.
        const offenders = dependencyArrays().filter((deps) => /\[\s*[\]{}]/.test(deps));

        expect(offenders).toEqual([]);
    });

    it('memoises `loaders` instead of rebuilding it inline', () => {
        // The regression was `const loaders = software ? loadersFor(...) : []`.
        // The discriminator is the useMemo call itself, not the surrounding
        // expression -- an earlier version of this assertion tried to forbid the
        // shape `? loadersFor(x) : []`, which the correct memoised line also
        // contains, so it failed against the very fix it was meant to protect.
        const declaration = source.match(/^\s*const loaders = .*$/m);

        expect(declaration).not.toBeNull();
        expect(declaration![0].trim()).toMatch(/^const loaders = useMemo\(/);
    });

    it('does not render the version grid itself', () => {
        // The grid moved into SoftwarePicker's second step, so a reinstall is
        // never one click away from the software list on the page.
        expect(source).not.toMatch(/<VersionGrid/);
        expect(source).not.toMatch(/<select[\s\S]{0,200}Minecraft version/);
    });

    it('keys the loaders memo on a primitive, not the object', () => {
        // Depending on the `software` object is the same trap wearing a
        // different hat: a new SWR payload object re-runs the memo.
        expect(source).toMatch(/const softwareName = software\?\.name;/);
        expect(source).toMatch(/\[softwareName\]/);
    });
});
