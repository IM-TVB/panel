import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
    faChevronDown,
    faChevronUp,
    faGlobe,
    faHdd,
    faMemory,
    faMicrochip,
    IconDefinition,
} from '@fortawesome/free-solid-svg-icons';
import { ServerContext } from '@/state/server';
import { SocketEvent } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import PowerButtons from '@/components/server/console/PowerButtons';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import { capitalize } from '@/lib/strings';

type Stats = { cpu: number; memory: number; disk: number };

interface Row {
    icon: IconDefinition;
    label: string;
    value: string;
}

/**
 * The card a phone gets above the console.
 *
 * Below 1024px the sidebar is an off-canvas drawer, so the three things it
 * carries on desktop -- the server's name, its address, and its power controls
 * -- are not reachable at all. This puts them back on the page rather than
 * expecting a phone user to open a menu to start their server: the name with a
 * live status pill, the four numbers someone joining actually wants, and
 * Start / Restart / Stop.
 *
 * Desktop renders none of it. The sidebar has the name, the address and the same
 * buttons there, and the console page keeps its own header, so this would be a
 * second copy of all three.
 *
 * Two things are reused rather than rewritten: `PowerButtons` already gates on
 * `control.start` / `restart` / `stop`, sends over the websocket and owns the
 * kill confirmation; and the websocket stats subscription is the same one
 * ServerDetailsBlock uses. The card's own numbers are read here rather than
 * lifted out of that component because a phone shows four of the seven tiles,
 * not all seven.
 */
export default () => {
    const [stats, setStats] = useState<Stats>({ cpu: 0, memory: 0, disk: 0 });
    const [open, setOpen] = useState(true);

    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const status = ServerContext.useStoreState((state) => state.status.value);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);

    // The same rule ServerDetailsBlock and the sidebar's address row use: an
    // allocation can have an alias that resolves where its address does not.
    const address = ServerContext.useStoreState((state) => {
        const allocation = state.server.data!.allocations.find((a) => a.isDefault);

        return allocation ? `${allocation.alias || ip(allocation.ip)}:${allocation.port}` : 'n/a';
    });

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let values: any = {};

        try {
            values = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({ cpu: values.cpu_absolute, memory: values.memory_bytes, disk: values.disk_bytes });
    });

    const offline = !status || status === 'offline';
    // Three states, because "not running" and "changing state" are different
    // answers and a single grey pill cannot say which one is happening.
    const tone = offline ? 'off' : status === 'running' ? 'on' : 'busy';
    const label = offline ? 'Offline' : status === 'running' ? 'Online' : capitalize(status);

    const rows: Row[] = [
        { icon: faGlobe, label: 'Address', value: address },
        {
            icon: faMicrochip,
            label: 'CPU',
            value: offline ? 'Offline' : `${stats.cpu.toFixed(2)}% / ${limits?.cpu ?? 0}%`,
        },
        {
            icon: faMemory,
            label: 'Memory',
            value: offline
                ? 'Offline'
                : `${bytesToString(stats.memory)} / ${bytesToString(mbToBytes(limits?.memory ?? 0))}`,
        },
        {
            icon: faHdd,
            label: 'Disk',
            value: offline
                ? 'Offline'
                : `${bytesToString(stats.disk)} / ${bytesToString(mbToBytes(limits?.disk ?? 0))}`,
        },
    ];

    return (
        <div className={'at-mobcard'}>
            <div className={'at-mobcard__head'}>
                {/* The desktop header's h1 is display:none at this width, so it is
                    out of the accessibility tree and this is the page's only
                    heading here. */}
                <h1 className={'at-mobcard__name'}>{name}</h1>
                <span className={`at-mobcard__pill at-mobcard__pill--${tone}`}>{label}</span>
            </div>

            {description ? <p className={'at-mobcard__desc'}>{description}</p> : null}

            {/*
                The rows sit under their own header rather than above it. The
                reference layout puts "Server stats" below the figures, which can
                only mean the header belongs to whatever comes after it -- and
                what comes after it there is the button row. A toggle that hides
                the power buttons is not what a collapsible is for, so the header
                goes above the rows it collapses.
            */}
            <button
                type={'button'}
                className={'at-mobcard__toggle'}
                onClick={() => setOpen((prev) => !prev)}
                aria-expanded={open}
            >
                Server stats
                <FontAwesomeIcon icon={open ? faChevronUp : faChevronDown} />
            </button>

            {open ? (
                <dl className={'at-mobcard__rows'}>
                    {rows.map((row) => (
                        <div key={row.label} className={'at-mobcard__row'}>
                            <dt className={'at-mobcard__row-label'}>
                                <FontAwesomeIcon icon={row.icon} />
                                {row.label}
                            </dt>
                            <dd className={'at-mobcard__row-value'}>{row.value}</dd>
                        </div>
                    ))}
                </dl>
            ) : null}

            <hr className={'at-mobcard__rule'} />

            <PowerButtons className={'at-mobcard__power'} />
        </div>
    );
};