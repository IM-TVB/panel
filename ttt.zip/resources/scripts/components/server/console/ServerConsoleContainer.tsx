import React, { memo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTerminal } from '@fortawesome/free-solid-svg-icons';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import Spinner from '@/components/elements/Spinner';
import Features from '@feature/Features';
import Console from '@/components/server/console/Console';
import StatGraphs from '@/components/server/console/StatGraphs';
import ServerDetailsBlock from '@/components/server/console/ServerDetailsBlock';
import MobileServerSummary from '@/components/server/console/MobileServerSummary';
import InstalledAddons from '@/components/server/console/InstalledAddons';
import { Alert } from '@/components/elements/alert';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

const ServerConsoleContainer = () => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const eggFeatures = ServerContext.useStoreState((state) => state.server.data!.eggFeatures, isEqual);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);

    return (
        <ServerContentBlock title={'Console'}>
            {(isNodeUnderMaintenance || isInstalling || isTransferring) && (
                <Alert type={'warning'} className={'mb-4'}>
                    {isNodeUnderMaintenance
                        ? 'The node of this server is currently under maintenance and all actions are unavailable.'
                        : isInstalling
                        ? 'This server is currently running its installation process and most actions are unavailable.'
                        : 'This server is currently being transferred to another node and all actions are unavailable.'}
                </Alert>
            )}
            {/*
                Phones, and only phones. Below 1024px the sidebar is an off-canvas
                drawer, so the three things it carries on desktop -- the name, the
                address, the power controls -- are not reachable from it at all.
                The card puts them back on the page; the header below and the stat
                tiles beside the console are hidden at this width so none of it
                appears twice.
            */}
            <div className={'lg:hidden'}>
                <MobileServerSummary />
            </div>

            <div className={'at-mobhead lg:hidden'}>
                <FontAwesomeIcon icon={faTerminal} />
                Console
            </div>

            {/* The server's Start / Restart / Stop live in the sidebar on desktop
                and in the card above on mobile, so they are not repeated here.
                This row used to be a grid whose second column held them; that
                column is gone, leaving the name and description as a plain block,
                and hidden below 1024px because the card above has already said it. */}
            <div className={'hidden lg:block mb-4'}>
                <h1 className={'font-header font-medium text-2xl text-gray-50 leading-relaxed line-clamp-1'}>
                    {name}
                </h1>
                <p className={'text-sm line-clamp-2'}>{description}</p>
            </div>
            <div className={'grid grid-cols-4 gap-2 sm:gap-4 mb-4'}>
                <div className={'flex col-span-4 lg:col-span-3'}>
                    <Spinner.Suspense>
                        <Console />
                    </Spinner.Suspense>
                </div>
                {/* Wrapped rather than given a responsive class of its own: the
                    block sets its own `grid` display, so a `hidden`/`lg:grid`
                    pair on it would depend on which utility the stylesheet emits
                    last. A plain wrapper keeps that decision unambiguous. */}
                <div className={'hidden lg:block lg:col-span-1'}>
                    <ServerDetailsBlock />
                </div>
            </div>
            <div className={'grid grid-cols-1 md:grid-cols-3 gap-2 sm:gap-4'}>
                <Spinner.Suspense>
                    <StatGraphs />
                </Spinner.Suspense>
            </div>
            <Can action={'file.read'}>
                <div className={'mt-4'}>
                    <InstalledAddons />
                </div>
            </Can>
            <Features enabled={eggFeatures} />
        </ServerContentBlock>
    );
};

export default memo(ServerConsoleContainer, isEqual);
