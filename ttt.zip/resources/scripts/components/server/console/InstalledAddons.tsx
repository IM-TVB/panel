import React from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowRight, faBan, faPuzzlePiece } from '@fortawesome/free-solid-svg-icons';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import useSWR from 'swr';
import tw from 'twin.macro';
import { InstalledAddon, listInstalled } from '@/api/server/plugins/install';
import { getSoftware } from '@/api/server/software';

/**
 * Compact "installed add-ons" strip, shown on the server's landing page the way
 * Aternos does — without needing to open a separate tab.
 *
 * Reads the same directory the Plugins & Mods tab uses, so the two can never
 * disagree. Silently renders nothing when the user cannot read files, or when
 * the add-on directory does not exist yet.
 */
const InstalledAddons = () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data?.uuid);
    const server = ServerContext.useStoreState((state) => state.server.data);

    // The add-on directory comes from the server's real software rather than a
    // guess off the server object. Guessing here meant this strip could read
    // plugins/ on a server that actually keeps its add-ons in mods/, and would
    // disagree with the Plugins & Mods page that shows the same list.
    //
    // The API call uses the long `serv_` identifier and the link below uses the
    // short one, and that is deliberate: the API path is not a URL anyone
    // reads, while the link is the address in the bar. See the note on the
    // link for why the short one is the one to show.
    const { data: software } = useSWR(
        server?.identifier ? ['server:software', server.identifier] : null,
        () => getSoftware(server!.identifier),
        { revalidateOnFocus: false, shouldRetryOnError: false }
    );

    const directory = software?.current.install_dir;

    const { data: installed } = useSWR<InstalledAddon[]>(
        uuid && directory ? ['addons:strip', uuid, directory] : null,
        () => listInstalled(uuid!, directory!),
        { revalidateOnFocus: false, shouldRetryOnError: false }
    );

    if (!installed || installed.length === 0) {
        return null;
    }

    const shown = installed.slice(0, 12);
    const overflow = installed.length - shown.length;

    return (
        <div className={'at-addon-strip'}>
            <div className={'at-addon-strip__head'}>
                <span className={'at-addon-strip__title'}>
                    <FontAwesomeIcon icon={faPuzzlePiece} css={tw`mr-2 text-at-primary-500`} />
                    Installed {directory === 'mods' ? 'mods' : 'plugins'}
                </span>
                <Can action={'file.*'}>
                    {/*
                     * `server.id` and not `server.identifier`.
                     *
                     * The identifier is the server's realtime identifier --
                     * `serv_` followed by the base32 of its uuid -- and it is
                     * long: `serv_oza3h4rr2jak7lthp2fdsngsnq`. `id` is the eight
                     * character short uuid, `7641b3f2`, which the API sends in
                     * the `identifier` field while the `new_server_identifiers`
                     * feature is off. The panel resolves all three forms, so
                     * either works; the short one is what a person reads out
                     * loud or pastes into a chat.
                     */}
                    <Link
                        to={`/server/${server?.id}/plugins`}
                        className={'at-addon-strip__more'}
                    >
                        Manage
                        <FontAwesomeIcon icon={faArrowRight} css={tw`ml-1.5`} />
                    </Link>
                </Can>
            </div>

            <ul className={'at-addon-strip__list'}>
                {shown.map((addon) => (
                    <li
                        key={addon.file.key}
                        className={`at-chip${addon.disabled ? ' at-chip--disabled' : ''}`}
                        title={addon.file.name}
                    >
                        <FontAwesomeIcon
                            icon={addon.disabled ? faBan : faPuzzlePiece}
                            css={tw`mr-1.5 text-[10px]`}
                        />
                        <span className={'at-chip__name'}>{addon.name}</span>
                    </li>
                ))}
                {overflow > 0 && <li className={'at-chip at-chip--more'}>+{overflow} more</li>}
            </ul>
        </div>
    );
};

export default React.memo(InstalledAddons);
