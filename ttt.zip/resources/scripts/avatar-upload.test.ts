/**
 * The profile-picture upload leaves the browser as a real multipart body.
 *
 * The bug this exists for: the shared `http` instance sets
 * `Content-Type: application/json` as a default, and axios only strips that
 * default for FormData *inside the adapter*, which runs after
 * transformRequest. transformRequest does this first:
 *
 *     if (isFormData) {
 *         return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
 *     }
 *
 * So the FormData was flattened to a plain object and stringified. A File has no
 * own enumerable properties, so it serialised to `{}` and the request went out as
 * the literal body `{"image":{}}`. PHP decoded that to `image => []`, an empty
 * array, the `required` rule failed, and the panel told the user "Choose a
 * picture to upload." -- for a picture they had just chosen.
 *
 * Nothing about the file input, the controller or the service was involved. It
 * read as a form problem the whole time, which is why it is worth a test that
 * runs axios's real transform rather than asserting on the source text.
 */

import axios, { AxiosHeaders, AxiosRequestTransformer, InternalAxiosRequestConfig } from 'axios';
import { readFileSync } from 'fs';
import { join } from 'path';

/**
 * axios types `transformRequest` as a single function *or* an array of them, so
 * indexing it blind is an error. Narrowed here rather than with a cast, because a
 * cast would have hidden the very thing this test depends on: that the first
 * entry is the one that runs, and that it is the function quoted above.
 */
const transformers = axios.defaults.transformRequest as AxiosRequestTransformer | AxiosRequestTransformer[];
const transformRequest = Array.isArray(transformers) ? transformers[0] : transformers;



const source = readFileSync(join(__dirname, 'api/user/avatar.ts'), 'utf8');
const httpInstance = readFileSync(join(__dirname, 'api/http.ts'), 'utf8');

/** The instance default, read from the file so a change to http.ts is caught here. */
const instanceDefault = /['"]Content-Type['"]\s*:\s*['"]([^'"]+)['"]/.exec(httpInstance)?.[1];

const aFile = new File([new Uint8Array([0x89, 0x50, 0x4e, 0x47])], 'me.png', { type: 'image/png' });

const bodyFor = (extraHeaders: Record<string, string>) => {
    const form = new FormData();

    form.append('image', aFile);

    // The headers axios actually hands transformRequest: the instance default,
    // then the per-request config, exactly as Axios.prototype.request merges them.
    const headers = new AxiosHeaders({
        'X-Requested-With': 'XMLHttpRequest',
        Accept: 'application/json',
        'Content-Type': instanceDefault ?? 'application/json',
        ...extraHeaders,
    });

    /*
     * axios types the transform's `this` as an InternalAxiosRequestConfig, which
     * is what the adapter really passes. The FormData branch reads nothing from
     * it -- the fields it does use are only touched on the object-payload path --
     * but the call still needs a context of that type rather than an implicit
     * void, so the headers it was handed are put back into one.
     */
    const transformed = transformRequest.call({ headers } as InternalAxiosRequestConfig, form, headers);

    return { body: transformed, isFormData: transformed instanceof FormData, contentType: headers.getContentType() };
};

describe('the avatar upload body', () => {
    it('the shared http instance really does default to JSON', () => {
        // If this ever changes, the rest of this file stops describing reality
        // and the assertions below would be testing a scenario that cannot occur.
        expect(instanceDefault).toBe('application/json');
    });

    it('is destroyed by the instance default on its own', () => {
        // The regression, kept as a live demonstration: this is what the upload
        // looked like before the per-request content type was added.
        const { body, isFormData } = bodyFor({});

        expect(isFormData).toBe(false);
        expect(body).toBe('{"image":{}}');
    });

    it('survives when the upload declares multipart', () => {
        const { isFormData, contentType } = bodyFor({ 'Content-Type': 'multipart/form-data' });

        expect(isFormData).toBe(true);
        expect(contentType).toBe('multipart/form-data');
    });

    it('the file is still a File in the body that goes out', () => {
        const form = new FormData();

        form.append('image', aFile);

        const sent = bodyFor({ 'Content-Type': 'multipart/form-data' }).body as FormData;

        expect(sent.get('image')).toBeInstanceOf(File);
        expect((sent.get('image') as File).name).toBe('me.png');
    });

    it('the upload call is the one that declares it', () => {
        // Guards the wiring, not the transform: a future edit that adds a second
        // post to this file, or moves the config off the upload call, would leave
        // the transform correct and the request broken again.
        const upload = /http\.post<[^>]*>\(\s*['"]\/api\/client\/account\/avatar['"]\s*,\s*body\s*,\s*(\w+)\s*\)/.exec(source);

        expect(upload).not.toBeNull();
        expect(source).toContain("const MULTIPART = { headers: { 'Content-Type': 'multipart/form-data' } };");

        // toContain on the tail of the call rather than a RegExp built from the
        // captured name. The first version looked for a `${MULTIPART}` template
        // literal that the source never had -- the identifier is passed directly
        // -- so the assertion failed on the test's own construction twice over.
        expect(source).toContain(', ' + upload?.[1] + ');');
    });

    it('the reset call does not, because it sends no file', () => {
        // A JSON body is correct there. Adding multipart to it would be a second
        // way for this to break, so the asymmetry is asserted rather than assumed.
        expect(source).toMatch(/http\.post\('\/api\/client\/account\/avatar\/reset'\)/);
    });
});
