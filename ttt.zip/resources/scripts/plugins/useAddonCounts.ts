import { useEffect, useRef, useState } from 'react';
import { countAddonsForVersion } from '@/api/server/plugins/modrinth';

/**
 * How many add-ons Modrinth offers for each Minecraft version, for the given
 * server software.
 *
 * Modrinth has no endpoint that returns these counts in bulk, so each version
 * needs its own search. Doing that for all ~76 versions at once would fire 76
 * requests on page load, which is hostile to the API and slow to settle, so:
 *
 *  - results are cached in localStorage per (software, project type) for a day,
 *    so a returning visit costs nothing;
 *  - uncached versions are fetched through a small concurrency pool, and each
 *    result lands in state as it arrives so the grid fills in progressively
 *    rather than appearing all at once.
 *
 * Aternos shows the same numbers next to each version.
 */

const CACHE_TTL = 24 * 60 * 60 * 1000;
const CONCURRENCY = 6;

interface CacheShape {
    [version: string]: { count: number; at: number };
}

const cacheKey = (loaders: string[], projectType: 'plugin' | 'mod') =>
    `pterodactyl:addon-counts:${projectType}:${[...loaders].sort().join('+')}`;

const readCache = (key: string): CacheShape => {
    try {
        const raw = JSON.parse(window.localStorage.getItem(key) ?? '{}');
        const now = Date.now();

        return Object.fromEntries(
            Object.entries(raw as CacheShape).filter(([, v]) => now - v.at < CACHE_TTL)
        );
    } catch (e) {
        return {};
    }
};

const writeCache = (key: string, data: CacheShape) => {
    try {
        window.localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
        /* storage disabled; the counts still work for this page view */
    }
};

export default (
    versions: string[],
    loaders: string[],
    projectType: 'plugin' | 'mod'
): Record<string, number> => {
    const [counts, setCounts] = useState<Record<string, number>>({});

    // Identity of the query. A change here invalidates everything in flight.
    const signature = `${projectType}:${[...loaders].sort().join('+')}`;
    const started = useRef<string>('');

    useEffect(() => {
        if (loaders.length === 0) {
            setCounts({});

            return;
        }

        const key = cacheKey(loaders, projectType);
        const cached = readCache(key);

        setCounts(Object.fromEntries(Object.entries(cached).map(([v, d]) => [v, d.count])));

        // Re-running for an unchanged signature would refetch the same versions.
        if (started.current === signature) return;
        started.current = signature;

        const missing = versions.filter((v) => cached[v] === undefined);
        if (missing.length === 0) return;

        let cancelled = false;
        const collected: CacheShape = { ...cached };
        let cursor = 0;

        const worker = async () => {
            while (!cancelled) {
                const version = missing[cursor++];
                if (!version) return;

                try {
                    const count = await countAddonsForVersion(version, loaders, projectType);
                    if (cancelled) return;
                    collected[version] = { count, at: Date.now() };
                    setCounts((prev) => ({ ...prev, [version]: count }));
                } catch (e) {
                    // A failed lookup is left uncached so it is retried next visit
                    // rather than remembered as a real zero.
                }
            }
        };

        const pool = Array.from({ length: Math.min(CONCURRENCY, missing.length) }, worker);
        Promise.all(pool).then(() => {
            if (!cancelled) writeCache(key, collected);
        });

        return () => {
            cancelled = true;
        };
    }, [signature, versions.join(',')]);

    return counts;
};
