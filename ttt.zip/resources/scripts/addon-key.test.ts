/**
 * Telling an installed file and a search result apart.
 *
 * These two describe the same thing in incompatible ways: one is a filename
 * somebody's build produced, the other is a project name a provider API returns.
 * When the two reductions are written separately they disagree, and the symptom
 * is always the same -- a plugin that is plainly installed looks uninstalled, so
 * the badge never appears and there is no remove button.
 *
 * Every case below is a real jar from this server or a real project name from
 * Spiget. The two that used to fail are the reason this file exists:
 * FastAsyncWorldEdit-Bukkit-2.15.4.jar and Simple-Tpa-8.0.jar.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

import { addonKey, addonKeyAliases } from './api/server/plugins/addonKey';

describe('addonKey', () => {
    it('reduces a real installed jar to its project', () => {
        expect(addonKey('EssentialsX-2.22.0')).toBe('essentialsx');
        expect(addonKey('EssentialsXChat-2.22.0')).toBe('essentialsxchat');
        expect(addonKey('Set-Home-6.2.3')).toBe('sethome');
    });

    it('drops a platform suffix the project name does not carry', () => {
        // The jar is platform-specific; the project is not. This one silently
        // failed before, so FastAsyncWorldEdit never showed as installed.
        expect(addonKey('FastAsyncWorldEdit-Bukkit-2.15.4')).toBe('fastasyncworldedit');
        expect(addonKey('LuckPerms-Bukkit-5.5.71')).toBe('luckperms');
        expect(addonKey('SomePlugin-Paper-1.0.0')).toBe('someplugin');
        expect(addonKey('TrafficCop-BungeeCord-2.0.0')).toBe('trafficcop');
    });

    it('ignores punctuation, so a hyphenated file matches an unhyphenated project', () => {
        // Simple-Tpa-8.0.jar is the project "SimpleTpa". The other one.
        expect(addonKey('Simple-Tpa-8.0')).toBe('simpletpa');
        expect(addonKey('Vault-1.7.3')).toBe('vault');
        expect(addonKey('EssentialsXChat-2.22.0')).toBe('essentialsxchat');
    });

    it('strips a trailing version of every shape', () => {
        expect(addonKey('Plugin-1.0')).toBe('plugin');
        expect(addonKey('Plugin-1.0.0')).toBe('plugin');
        expect(addonKey('Plugin-5.12.1-SNAPSHOT+635')).toBe('plugin');
        expect(addonKey('Plugin-2023.1.4')).toBe('plugin');
        expect(addonKey('Plugin-1.0-BETA')).toBe('plugin');
    });

    it('handles a version-shaped platform suffix in the right order', () => {
        // Platform first, then version -- stripping the version must not leave
        // "-Bukkit" to be mistaken for part of the name.
        expect(addonKey('Foo-Bukkit-1.0')).toBe('foo');
        expect(addonKey('Foo-1.0')).toBe('foo');
    });

    it('keeps a project genuinely named after a platform', () => {
        // A project called "Bukkit" must not reduce to nothing just because
        // "bukkit" is in the suffix list.
        expect(addonKey('Bukkit-1.0')).toBe('bukkit');
        expect(addonKey('Paper-1.0')).toBe('paper');
        expect(addonKey('Velocity-3.0')).toBe('velocity');
        expect(addonKey('Fabric-1.0')).toBe('fabric');
    });

    it('does not strip two suffixes at once', () => {
        // Only one platform marker is removed, so this cannot cascade into
        // matching something that merely shares a suffix.
        expect(addonKey('Foo-Bukkit-Paper-1.0')).not.toBe('foo');
    });

    it('tolerates the shapes it will actually be handed', () => {
        expect(addonKey('')).toBe('');
        expect(addonKey('.jar')).toBe('');
        expect(addonKey('Plugin.jar')).toBe('plugin');
        expect(addonKey('Plugin-1.0.jar')).toBe('plugin');
        expect(addonKey('Plugin-1.0-disabled.jar')).toBe('plugin');
        expect(addonKey('Plugin-1.0-DISABLED')).toBe('plugin');
    });

    it('ignores case and accents on both sides', () => {
        expect(addonKey('Café-1.0')).toBe('cafe');
        expect(addonKey('LUCKPERMS-5.5.71')).toBe('luckperms');
    });
});

describe('a real jar matches its real project', () => {
    // filename on disk, and the name Spiget/Hangar/Modrinth returns for it.
    const cases: [string, string][] = [
        ['EssentialsX-2.22.0', 'EssentialsX'],
        ['EssentialsXChat-2.22.0', 'EssentialsXChat'],
        ['EssentialsXSpawn-2.22.0', 'EssentialsXSpawn'],
        ['FastAsyncWorldEdit-Bukkit-2.15.4', 'FastAsyncWorldEdit'],
        ['Set-Home-6.2.3', 'Set-Home'],
        ['Simple-Tpa-8.0', 'SimpleTpa'],
        ['LuckPerms-5.5.71', 'LuckPerms'],
        // A Modrinth-shaped pair, to cover the other source's filename style.
        // Deliberately a different plugin: the distinctness check below needs
        // the set to hold distinct projects, and LuckPerms is already in it.
        ['sodium-fabric-0.6.0', 'sodium'],
        ['ProtocolLib-5.3.0', 'ProtocolLib'],
    ];

    it.each(cases)('%s is recognised as %s', (file, project) => {
        expect(addonKey(file)).toBe(addonKey(project));
    });

    it('does not collapse distinct plugins into one key', () => {
        // The suffixes are stripped from both sides, so if the sanitiser were too
        // aggressive every one of these would reduce to the same string and each
        // round-trip above would still pass.
        const keys = cases.map(([file, project]) => addonKey(project));

        expect(new Set(keys).size).toBe(cases.length);
    });
});

describe('addonKeyAliases', () => {
    it('offers the unreduced form as well, so nothing is lost to the stripping', () => {
        // Foo-Bukkit and Foo-Paper both reduce to "foo". Whichever was written
        // last would win the map, so the unreduced key is offered too and a
        // project whose name really contains a platform word still matches.
        const aliases = addonKeyAliases('Foo-Bukkit-1.0');

        expect(aliases).toContain('foo');
        expect(aliases).toContain('foobukkit');
    });

    it('does not duplicate when there is nothing extra to offer', () => {
        expect(addonKeyAliases('LuckPerms-5.5.71')).toEqual(['luckperms']);
        expect(addonKeyAliases('EssentialsX-2.22.0')).toEqual(['essentialsx']);
    });
});

describe('the page is actually wired to it', () => {
    // Without this the whole file tests a function nothing calls. The badge broke
    // before precisely because the card built its marker inline while the
    // installed list derived its key elsewhere, and a unit test of the helper
    // passed throughout.
    const source = readFileSync(
        join(__dirname, 'components/server/plugins/PluginsContainer.tsx'),
        'utf8'
    );

    it('reduces the search marker with addonKey, not inline', () => {
        expect(source).toMatch(/addonKey\(/);
        expect(source).not.toMatch(/\(hit\.projectId \?\? ''\)\.toLowerCase\(\)/);
    });

    it('keys the installed map with the same function', () => {
        expect(source).toContain('addonKeyAliases');
    });

    // The page deliberately does not list installed add-ons: that was asked for
    // and then asked to be taken away again. Uninstall therefore lives on the
    // search card, which makes this matching accuracy the whole of whether remove
    // works -- a card that fails to match offers Install for something already
    // installed, and no way to remove it.
    it('does not add an installed list back', () => {
        expect(source).not.toContain('at-installed');
        expect(source).not.toMatch(/installedList/);
    });

    it('shows a status on a matched card, not a remove control', () => {
        // The card reports what is installed and nothing more. Removal happens in
        // the File Manager, so there is deliberately no delete on this page.
        expect(source).toContain('at-pcard__installed');
        expect(source).toMatch(/<span\s+className=\{'at-pcard__installed'\}/);
        expect(source).not.toMatch(/onUninstall/);
        expect(source).not.toMatch(/Installed ✕/);
    });

    it('carries no delete call at all', () => {
        expect(source).not.toMatch(/deleteFiles/);
        expect(source).not.toMatch(/\buninstall\b/);
    });
});
