/**
 * The desktop sidebar collapse.
 *
 * The burger is a class on <html> plus a set of CSS rules, and the ways it can
 * be wrong are all invisible in the source: a class applied a beat after first
 * paint (a visible snap on every load), two burgers fighting over the same
 * drawer at one breakpoint, or a rail that leaves a dead gap where the labels
 * were.
 *
 * That last one is why the rail is a width change and not `display: none`.
 * `.at-shell` is a flex row and the content is `flex: 1`, so narrowing the
 * sidebar's basis hands the space over and nothing else in the theme has to
 * know the new width. `display: none` would have given the same width -- and
 * taken the sidebar out of flow, leaving nothing to click to bring it back,
 * which is the entire reason the floating restore button used to exist. The
 * rail keeps that control where it always was, so the button is gone.
 */

import { readFileSync } from 'fs';
import { join } from 'path';

const css = readFileSync(join(__dirname, 'assets/aternos.css'), 'utf8');
const nav = readFileSync(join(__dirname, 'components/NavigationBar.tsx'), 'utf8');
const serverRouter = readFileSync(join(__dirname, 'routers/ServerRouter.tsx'), 'utf8');
const power = readFileSync(
    join(__dirname, 'components/server/SidebarPowerControls.tsx'),
    'utf8'
);
const hook = readFileSync(join(__dirname, 'plugins/useCollapsibleNav.ts'), 'utf8');
const wrapper = readFileSync(join(__dirname, '../views/templates/wrapper.blade.php'), 'utf8');

/**
 * The rail's rules, sliced between the desktop breakpoint that opens them and
 * the mobile one that follows.
 *
 * Sliced on those two rather than on a selector, because the point of several
 * assertions below is about rules that hide things -- and a slice cut at the
 * first `.at-nav-collapsed` selector would end before them.
 */
const rail = css.slice(
    css.indexOf('@media (min-width: 1024px)'),
    // The burger's own rules come next, and they carry colours of their own --
    // legitimately, since they are always-dark chrome. Stopping at the comment
    // that introduces them keeps the "no colour of its own" assertion about the
    // rail alone.
    css.indexOf('/* In the brand row, where the close button already sits for mobile.')
);

describe('the choice is applied before the first frame', () => {
    it('the pre-paint script reads it', () => {
        // Applied from the bundle instead, the sidebar renders at full width and
        // then snaps shut a moment later on every load, for anyone who chose to
        // collapse it. That reads as a glitch, not as their setting.
        expect(wrapper).toContain("window.localStorage.getItem('pterodactyl:nav-collapsed')");
        expect(wrapper).toContain("classList.add('at-nav-collapsed')");
    });

    it('it is inside the same script that applies the theme, before it closes', () => {
        // Two scripts would mean one runs after paint, which is the thing being
        // avoided.
        const start = wrapper.indexOf('pterodactyl:nav-collapsed');
        const end = wrapper.indexOf('</script>', start);

        expect(start).toBeGreaterThan(-1);
        expect(end).toBeGreaterThan(start);
    });

    it('and a disabled localStorage leaves the sidebar expanded rather than throwing', () => {
        const block = wrapper.slice(wrapper.indexOf('pterodactyl:nav-collapsed') - 120, wrapper.indexOf('</script>', wrapper.indexOf('pterodactyl:nav-collapsed')));

        expect(block).toMatch(/try\s*\{[\s\S]*catch/);
    });
});

describe('the hook and the script agree', () => {
    it('same storage key, same class', () => {
        const key = 'pterodactyl:nav-collapsed';
        const cls = 'at-nav-collapsed';

        expect(hook).toContain(`'${key}'`);
        expect(wrapper).toContain(`'${key}'`);
        expect(hook).toContain(`'${cls}'`);
        expect(wrapper).toContain(`'${cls}'`);
    });

    it('the hook reads the DOM rather than localStorage', () => {
        // The pre-paint script is the one that knows the truth; reading
        // localStorage independently would let the two disagree.
        expect(hook).toContain('classList.contains(CLASS)');
    });

    it('it writes both the class and the stored value', () => {
        expect(hook).toContain('classList.toggle(CLASS, collapsed)');
        expect(hook).toContain('localStorage.setItem(STORAGE_KEY');
    });
});

describe('collapsing narrows the sidebar rather than removing it', () => {
    it('the rail is a width, not display: none', () => {
        // `display: none` would produce the same content width, and it is the
        // obvious way to write this -- which is why it is pinned off. It takes
        // the sidebar out of flow, so nothing is left to click to bring it back.
        expect(css).not.toMatch(/\.at-nav-collapsed \.at-sidebar\s*\{\s*display:\s*none;/);
        expect(rail).toMatch(/\.at-nav-collapsed \.at-sidebar\s*\{[^}]*width:\s*72px;/);
    });

    it('and the basis is narrowed too, because flex-basis is what decides it', () => {
        // `.at-sidebar` sets `flex: 0 0 248px`. Setting width alone leaves that
        // basis in force and the sidebar does not move at all.
        expect(rail).toMatch(/\.at-nav-collapsed \.at-sidebar\s*\{[^}]*flex-basis:\s*72px;/);
    });

    it('the content is the thing that grows into the space', () => {
        // If the content were a fixed width, narrowing the sidebar would leave a
        // hole rather than giving the space back.
        expect(css).toMatch(/\.at-shell__main[^{]*\{[^}]*flex:\s*1/);
    });

    it('and none of it applies to the mobile drawer', () => {
        // Below 1024px the sidebar is a drawer someone opened on purpose from the
        // top bar, and it is always full width. A rail inside it would be a bug,
        // not a preference -- so the whole block is scoped the other way round.
        expect(rail).toContain('@media (min-width: 1024px)');
        expect(rail).not.toContain('@media (max-width');
    });

    it('the rail rules add no colour of their own', () => {
        // They only narrow and hide. A colour here would sit outside the block
        // sidebar-always-dark.test.ts scans, so nothing else would catch it.
        expect(rail.match(/--at-[a-z0-9-]+/g) ?? []).toEqual([]);
    });
});

describe('the rail hides labels and keeps icons', () => {
    /**
     * The rule that hides them, cut at its `display: none`. Several of these
     * selectors appear again later in the rail -- `.at-sidebar__section` for
     * its padding, `.at-power` for its layout -- so asserting on the whole slice
     * would pass on a mention rather than on the hiding.
     */
    const hidden = (() => {
        const start = rail.indexOf('.at-nav-collapsed .at-sidebar__name');
        const end = rail.indexOf('display: none;', start);

        return rail.slice(start, end);
    })();

    it.each([
        ['the brand name', '.at-sidebar__name'],
        ['the panel logo', '.at-sidebar__logo'],
        ['section headings', '.at-sidebar__section'],
        ['the address chip', '.at-sidebar__address'],
        ['the username', '.at-sidebar__username'],
        ['link labels', '.at-sidebar__link span'],
        ['the search label', '.at-sidebar__search span'],
        ['the theme toggle label', '.at-theme-toggle span:not(.at-theme-toggle__icon)'],
    ])('%s is hidden in the rail', (_label, selector) => {
        expect(hidden).toContain(selector);
    });

    it('and hidden, rather than merely unstyled', () => {
        expect(rail).toContain('display: none;');
    });

    it('and the link that wrapped the logo goes with it', () => {
        // Hiding only the logo leaves an <a> with nothing in it: still focusable,
        // still announced, and still a link home to nowhere in particular. The
        // burger beside it is the only thing the rail's top row needs.
        expect(rail).toMatch(/\.at-nav-collapsed \.at-sidebar__brandlink\s*\{[^}]*display:\s*none;/);
    });

    it('a heading with no text is not left behind as a gap', () => {
        // Hiding the text alone would leave its padding: an 18px gap seven times
        // down the nav, with nothing in it.
        expect(rail).toMatch(/\.at-nav-collapsed \.at-sidebar__section\s*\{[^}]*padding:\s*0;/);
    });

    it('what is left is centred, and the row rhythm is kept', () => {
        // The power row was three across a 248px nav; in a 72px rail it stacks.
        expect(rail).toMatch(/\.at-nav-collapsed \.at-power\s*\{[^}]*grid-template-columns:\s*none;/);
        expect(rail).toMatch(/\.at-nav-collapsed \.at-sidebar__link,[^}]*justify-content:\s*center;/);
    });

    it('the footer stops being the scroll container, or the account menu is clipped', () => {
        // The menu opens upward out of the footer and is 224px wide. While
        // `.at-sidebar` is `overflow-x: hidden` it would be cut off at the rail's
        // edge -- and a menu with its right-hand side missing is worse than none.
        expect(rail).toMatch(/\.at-nav-collapsed \.at-sidebar\s*\{[^}]*overflow:\s*visible;/);
        expect(rail).toMatch(/\.at-nav-collapsed \.at-sidebar__nav\s*\{[^}]*overflow-y:\s*auto;/);
    });
});

describe('the collapse is animated', () => {
    it('desktop only, because the drawer animates its own transform', () => {
        // Both transitions are declared on `.at-sidebar`, so a desktop-scoped one
        // is what keeps the drawer's 0.25s slide from being overwritten -- and
        // the drawer is always full width, so a width transition would be inert.
        expect(rail).toMatch(/\.at-sidebar\s*\{[^}]*transition:[^}]*width[^}]*flex-basis/s);
        expect(css).toMatch(
            /\.at-sidebar\s*\{[^}]*transition:\s*transform 0\.25s cubic-bezier\(0\.4, 0, 0\.2, 1\)/s
        );
    });

    it('both properties, because the basis is what decides the width', () => {
        // The base rule is `flex: 0 0 248px`. Transitioning width alone would
        // resize the box without moving the flex line, and the content would
        // stand still and then jump.
        expect(rail).toMatch(/width 0\.45s cubic-bezier\(0\.4, 0, 0\.2, 1\)/);
        expect(rail).toMatch(/flex-basis 0\.45s cubic-bezier\(0\.4, 0, 0\.2, 1\)/);
    });

    it('and it reuses the drawer\'s easing, because it is the same motion', () => {
        const easing = rail.match(/cubic-bezier\([^)]*\)/g) ?? [];

        // One easing for the whole rail, and it is the drawer's.
        expect(new Set(easing).size).toBe(1);
        expect(easing[0]).toBe('cubic-bezier(0.4, 0, 0.2, 1)');
    });

    it('slower than the drawer, because it hands over 176px rather than nothing', () => {
        const ms = (v: string) => Math.round(parseFloat(v) * 1000);

        expect(ms(rail.match(/width ([\d.]+)s/)?.[1] ?? '0')).toBeGreaterThan(ms('0.25'));
    });
});

describe('bare icons say what they are', () => {
    it('the shared links get a tooltip only while collapsed', () => {
        // Not always: with the label on screen, a title repeating it is noise on
        // every hover. Only the rail is a state where there is nothing to read.
        expect(nav).toContain('title={collapsed ? label : undefined}');
    });

    it('and so do the search, admin and account controls', () => {
        expect(nav).toContain("title={collapsed ? 'Search servers' : undefined}");
        expect(nav).toContain("title={collapsed ? 'Admin Panel' : undefined}");
        expect(nav).toContain('title={collapsed ? username : undefined}');
        // The toggle's tooltip carries the mode NAME in the rail, because
        // "Switch to blue mode" describes an action the icon already implies.
        expect(nav).toContain('title={collapsed ? themeName : themeAction}');
    });

    it('the server links are built in ServerRouter, so they are titled there', () => {
        // These are the sidebar's children. NavigationBar cannot reach them, so
        // without this the rail would label the shared links and leave every
        // per-server link an anonymous icon.
        expect(serverRouter).toContain('useCollapsibleNav');
        expect(serverRouter).toContain('title={collapsed && route.name ? route.name : undefined}');
        expect(serverRouter).toContain("title={collapsed ? 'View in Admin' : undefined}");
    });

    it('and the power buttons name their action', () => {
        // Icon-only, so the name lives on the tooltip. Stop relabels itself to
        // Kill while stopping, so that one has to follow it rather than say
        // "Stop" over a stop sign that is about to be forced.
        expect(power).toContain("title={'Start'}");
        expect(power).toContain("title={'Restart'}");
        expect(power).toContain("title={killable ? 'Kill' : 'Stop'}");
        // Unconditional, because the caption is hidden at every width now -- not
        // only in the rail.
        expect(power).not.toContain('useCollapsibleNav');
    });

    it('the power captions are hidden visually but kept for a screen reader', () => {
        // Icon-only is right for these buttons. `display: none` would be wrong,
        // though: it takes the text out of the accessibility tree as well, and a
        // button whose only content is an unlabelled <svg> is announced as just
        // "button". Clipped to a pixel, the caption is gone from the page and
        // still the accessible name.
        const caption = css.slice(css.indexOf('.at-power__btn span {'), css.indexOf('.at-power__btn svg'));

        expect(caption).toMatch(/position:\s*absolute;/);
        expect(caption).toMatch(/clip:\s*rect\(0, 0, 0, 0\)/);
        expect(caption).not.toMatch(/display:\s*none/);
    });
});

describe('there is one control per breakpoint, and one collapse control', () => {
    it('the drawer burger is hidden when the sidebar can be collapsed', () => {
        // Below 1024px the sidebar is an off-canvas drawer opened from the top
        // bar. Leaving the collapse burger visible there would put two hamburgers
        // on screen, each opening something different.
        //
        // Located by the rule it contains, not by index: there are several
        // `@media (max-width: 1023px)` blocks in this file and picking the last
        // one finds an unrelated rule further down.
        const blocks = [...css.matchAll(/@media \(max-width: 1023px\) \{([\s\S]*?)\n\}/g)]
            .map((m) => m[1])
            .filter((body) => body.includes('.at-sidebar__burger'));

        expect(blocks).toHaveLength(1);
        expect(blocks[0]).toMatch(/\.at-sidebar__burger[\s\S]*display:\s*none/);
    });

    it('and the top bar is still the drawer control there', () => {
        expect(css).toMatch(/\.at-topbar\s*\{\s*display:\s*none;/);
        expect(nav).toContain("className={'at-topbar__burger'}");
    });

    it('the floating restore button is gone from both the markup and the stylesheet', () => {
        // It existed only to bring back a sidebar that had left flow. The rail
        // keeps the burger in place, so a second control floating over the page
        // would have nothing to do.
        expect(nav).not.toContain('at-nav-restore');
        expect(css).not.toContain('at-nav-restore');
    });
});

describe('the collapse control is reachable and announced', () => {
    it('the burger is still the only one, and it still says which way it goes', () => {
        // Counted rather than matched once: this file briefly carried TWO restore
        // buttons, stacked on the same spot and both in the tab order, and a "does
        // it appear at least once" assertion is exactly what failed to notice.
        expect(nav.match(/aria-expanded=\{!collapsed\}/g)).toHaveLength(1);
        expect(nav.match(/className=\{'at-sidebar__burger'\}/g)).toHaveLength(1);
        expect(nav).toMatch(/at-sidebar__burger[\s\S]{0,260}aria-expanded=\{!collapsed\}/);
    });

    it('and the label follows the state, because it no longer hides anything', () => {
        // "Hide the sidebar" described the old behaviour. Collapsing it now
        // narrows it, and a label that says otherwise is a control lying about
        // what it does.
        expect(nav).toContain(
            "const collapseLabel = collapsed ? 'Expand the sidebar' : 'Collapse the sidebar';"
        );
        expect(nav).toMatch(/aria-label=\{collapseLabel\}/);
        expect(nav).toMatch(/title=\{collapseLabel\}/);
    });
});

describe('the sidebar colours are used, not the page ones', () => {
    it('the in-sidebar burger follows the always-dark sidebar', () => {
        // The sidebar is dark in BOTH modes and is styled from --at-side-* tokens.
        // Using a page token here would put dark navy on a dark background the
        // moment the light theme is active -- invisible, and only on that theme.
        const burger = css.slice(css.indexOf('.at-sidebar__burger {'), css.indexOf('.at-sidebar__burger:hover'));

        expect(burger).toMatch(/color:\s*var\(--at-side-muted\)/);
        expect(burger).toMatch(/background:\s*transparent/);
        expect(css.slice(css.indexOf('.at-sidebar__burger:hover'), css.indexOf('@media (max-width: 1023px)'))).toMatch(
            /color:\s*var\(--at-side-text\)/
        );
    });
});