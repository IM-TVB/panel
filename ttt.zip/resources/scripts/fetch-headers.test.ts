/**
 * No browser-side module may set a Fetch-forbidden request header.
 *
 * `User-Agent` is on the Fetch spec's forbidden header list, so a browser
 * rejects any attempt to set it and axios reports "Headers User-Agent forbidden".
 * Node permits it, which is the trap: a server-side test of the same module
 * passes green while every request from the browser fails. That is exactly how
 * the Spigot provider shipped broken -- the integration test ran in Node and
 * the search returned nothing in the app.
 *
 * Same reasoning applies to Origin and Referer.
 */
import { readdirSync, readFileSync, statSync } from 'fs';
import { join } from 'path';

const ROOT = join(__dirname);
const SKIP = new Set(['node_modules', 'dist', 'build', '__tests__']);

// Headers a browser refuses to let script set.
const FORBIDDEN = ['User-Agent', 'Origin', 'Referer', 'Host', 'Cookie', 'Connection'];

const walk = (dir: string, out: string[] = []): string[] => {
    for (const entry of readdirSync(dir)) {
        if (SKIP.has(entry)) continue;
        const full = join(dir, entry);
        if (statSync(full).isDirectory()) walk(full, out);
        else if (/\.tsx?$/.test(full)) out.push(full);
    }

    return out;
};

describe('fetch request headers', () => {
    const files = walk(ROOT);
    const offenders: string[] = [];

    it('finds files to check', () => {
        expect(files.length).toBeGreaterThan(10);
    });

    it('sets no fetch-forbidden header', () => {
        for (const file of files) {
            const source = readFileSync(file, 'utf8');

            // Strip comments so the explanatory notes about this very rule do
            // not read as violations.
            const code = source
                .replace(/\/\*[\s\S]*?\*\//g, '')
                .replace(/(^|[^:])\/\/.*$/gm, '$1');

            for (const header of FORBIDDEN) {
                const pattern = new RegExp(`['"\`]${header}['"\`]\\s*:`, 'i');
                if (pattern.test(code)) {
                    offenders.push(`${file.replace(ROOT, '')} sets ${header}`);
                }
            }
        }

        expect(offenders).toEqual([]);
    });
});
