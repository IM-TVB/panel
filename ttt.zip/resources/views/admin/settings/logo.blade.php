@extends('layouts.admin')
@include('partials.admin.settings.nav', ['activeTab' => 'logo'])

@section('title')
    Logo
@endsection

@section('content-header')
    <h1>Panel Logo<small>The mark in the sidebar. Leave it unset to keep the default tile.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')

    {{--
        The preview is styled inline, deliberately.

        It used to carry the sidebar's own classes (at-sidebar__logo and
        friends), which is the honest way to show "this is what the sidebar will
        draw". Those classes live in the theme stylesheet, and that stylesheet is
        bundled into the *client* JavaScript -- layouts/admin.blade.php loads no
        theme CSS at all, only Font Awesome and Ionicons from a CDN. So in the
        admin area the class matched nothing, the span had no width or height, and
        the preview rendered as a full-width black slab with an enormous letter.

        The values below are copied from that CSS on purpose. Inline is what the
        background settings page does for the same reason, and duplicating four
        declarations here is cheaper than either shipping the whole theme
        stylesheet to the admin area or letting the preview lie about the size.
    --}}
    <form action="{{ route('admin.settings.logo.update') }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PATCH')

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Sidebar Logo</h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-3 text-center">
                                <span
                                    style="
                                        display:inline-grid;
                                        place-items:center;
                                        width:34px;
                                        height:34px;
                                        border-radius:10px;
                                        overflow:hidden;
                                        color:#fff;
                                        font-weight:800;
                                        font-size:15px;
                                        background:linear-gradient(135deg,#007bff 0%,#3ea2ff 100%);
                                        box-shadow:0 2px 8px rgba(0,123,255,0.3);
                                    "
                                >
                                    @if($hasImage)
                                        <img
                                            src="{{ $url }}"
                                            alt="Current logo"
                                            style="display:block;width:100%;height:100%;object-fit:cover"
                                        />
                                    @else
                                        {{ $initial }}
                                    @endif
                                </span>
                                <p class="text-muted">
                                    <small>
                                        @if($hasImage)
                                            Current logo, at the size it is actually drawn
                                        @else
                                            No logo set &mdash; the sidebar draws this tile
                                        @endif
                                    </small>
                                </p>
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label class="control-label">Upload a logo</label>
                                    <input
                                        type="file"
                                        name="image"
                                        accept="image/png,image/jpeg,image/gif,image/webp"
                                    />
                                    <p class="text-muted">
                                        <small>
                                            PNG, JPEG, GIF or WebP, up to {{ number_format($maxBytes / 1048576, 0) }} MB
                                            and at least {{ $minDimension }}&times;{{ $minDimension }} pixels.
                                            SVG is not accepted &mdash; it can carry script, and this file is
                                            downloaded on every page. The file is written into
                                            <code>public/branding/</code> and served straight from there,
                                            so replacing it fetches the new one rather than a cached old one.
                                            Square works best: it is drawn into a 34px rounded square and
                                            cropped to fill.
                                        </small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Reset</h3>
                </div>
                <div class="box-body">
                    <p class="text-muted" style="margin:0">
                        Removes the logo and puts the default tile back. This does not touch the browser
                        icon, the browser theme colour or the background &mdash; those have their own reset
                        on the Branding and Background pages.
                    </p>
                </div>
                @if($hasImage)
                    <div class="box-footer">
                        <form
                            action="{{ route('admin.settings.logo.reset') }}"
                            method="POST"
                            onsubmit="return confirm('Remove the logo and restore the default tile?')"
                        >
                            @csrf
                            <button type="submit" class="btn btn-sm btn-danger">Restore default</button>
                        </form>
                    </div>
                @else
                    <div class="box-footer">
                        <button type="button" class="btn btn-sm btn-danger pull-right" disabled>
                            Restore default
                        </button>
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
