@extends('layouts.admin')
@include('partials.admin.settings.nav', ['activeTab' => 'colors'])

@section('title')
    Colors
@endsection

@section('content-header')
    <h1>Theme Colours<small>Recolour the panel without editing files or rebuilding.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')

    @php
        $labels = [
            'primary' => ['Primary colour', 'Buttons, links, focus rings and every accent.'],
            'success' => ['Success', 'Confirmations and "online" states.'],
            'warning' => ['Warning', 'Caution banners and pending states.'],
            'danger' => ['Danger', 'Errors, deletes and "offline" states.'],
            'sidebar' => ['Sidebar background', 'The left navigation surface. Dark in both modes by default.'],
            'sidebarText' => ['Sidebar text', 'Labels inside the sidebar.'],
            'nav' => ['Top bar', 'The bar across the top. Light mode draws it at 88% opacity over the page colour.'],
            'pageBlue' => ['Page background', 'Shown behind every card in the light theme.'],
            'surfaceBlue' => ['Card colour', 'The surface cards and panels are drawn on, light theme.'],
            'textBlue' => ['Text colour', 'Body text in the light theme; muted/faint steps are derived.'],
            'borderBlue' => ['Border colour', 'Separators and card outlines, light theme.'],
            'pageDark' => ['Page background', 'Shown behind every card in the dark theme.'],
            'surfaceDark' => ['Card colour', 'The surface cards and panels are drawn on, dark theme.'],
            'textDark' => ['Text colour', 'Body text in the dark theme; muted/faint steps are derived.'],
            'borderDark' => ['Border colour', 'Separators and card outlines, dark theme.'],
        ];

        $groups = [
            'Accent' => ['primary', 'success', 'warning', 'danger'],
            'Navigation chrome' => ['sidebar', 'sidebarText', 'nav'],
            'Light mode' => ['pageBlue', 'surfaceBlue', 'textBlue', 'borderBlue'],
            'Dark mode' => ['pageDark', 'surfaceDark', 'textDark', 'borderDark'],
        ];
    @endphp

    <form action="{{ route('admin.settings.colors.update') }}" method="POST">
        @csrf
        @method('PATCH')

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Colours</h3>
                    </div>
                    <div class="box-body">
                        <p class="text-muted">
                            <small>
                                Tick a row to override that colour; every shade the panel needs is derived
                                automatically. Unticked rows keep the stock colour. Only ticked rows are written,
                                so an untouched row can never be accidentally set.
                            </small>
                        </p>

                        @foreach($groups as $group => $ids)
                            <h4 style="margin-top:18px;margin-bottom:4px"><strong>{{ $group }}</strong></h4>
                            @foreach($ids as $field)
                                @php $isCustom = isset($customised[$field]); @endphp
                                <div class="row" style="padding:10px 0;border-bottom:1px solid #f0f0f0">
                                    <div class="col-md-2">
                                        <label>
                                            <input type="checkbox" name="custom_{{ $field }}" value="1" @if($isCustom) checked @endif />
                                            <strong>{{ $labels[$field][0] }}</strong>
                                        </label>
                                    </div>
                                    <div class="col-md-2">
                                        <span style="display:inline-block;width:34px;height:34px;border-radius:8px;border:1px solid rgba(0,0,0,0.12);background:{{ $values[$field] }};vertical-align:middle"></span>
                                        <input type="color" name="{{ $field }}" value="{{ $values[$field] }}" style="width:46px;height:34px;padding:1px;border:1px solid #d2d6de;border-radius:6px;background:#fff;vertical-align:middle" />
                                    </div>
                                    <div class="col-md-3">
                                        <input type="text" name="{{ $field }}_text" value="{{ $values[$field] }}" class="form-control input-sm" style="max-width:130px" />
                                    </div>
                                    <div class="col-md-3 text-muted">
                                        <small>
                                            {{ $labels[$field][1] }}
                                            <em>Default: <code>{{ $defaults[$field] }}</code></em>
                                        </small>
                                    </div>
                                    <div class="col-md-2 text-right">
                                        <button
                                            type="submit"
                                            class="btn btn-default btn-xs"
                                            @if(!$isCustom) disabled @endif
                                            formaction="{{ route('admin.settings.colors.reset-field') }}"
                                            formmethod="post"
                                            name="field"
                                            value="{{ $field }}"
                                        >Reset to default</button>
                                    </div>
                                </div>
                            @endforeach
                        @endforeach

                        <h4 style="margin-top:18px;margin-bottom:4px"><strong>Footer</strong></h4>
                        <div class="form-group">
                            <label class="control-label">Footer text</label>
                            <input type="text" name="footer_text" value="{{ $footerText ?? '' }}" class="form-control" maxlength="200" placeholder="e.g. &copy; 2026 My Hosting. All rights reserved." />
                            <p class="text-muted"><small>Shown at the bottom of every page and the login screen. Leave empty to keep the default copyright line.</small></p>
                        </div>
                    </div>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-primary">Save Colours</button>
                        <span class="text-muted" style="margin-left:10px"><small>Applies on the next page load &mdash; no rebuild needed.</small></span>
                    </div>
                </div>
            </div>
        </div>
    </form>

    @if($custom)
        <form action="{{ route('admin.settings.colors.reset') }}" method="POST">
            @csrf
            <div class="row">
                <div class="col-xs-12">
                    <div class="box box-danger">
                        <div class="box-body">
                            <label>
                                <input type="checkbox" name="confirm" value="1" required />
                                I understand this resets every customised colour to the default
                            </label>
                            @if($updatedAt)
                                <small class="text-muted">Last change: {{ $updatedAt }}</small>
                            @endif
                        </div>
                        <div class="box-footer">
                            <button type="submit" class="btn btn-danger">Restore All Defaults</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    @endif

    <script>
        // Keep each colour picker and its text box in sync; the picker's value
        // is what the form submits. Editing a row ticks its override checkbox
        // for the operator -- otherwise a changed-but-unticked row silently
        // saves as "keep the default" and the colour never takes effect, which
        // is the most common way this page appears to do nothing.
        (function () {
            document.querySelectorAll('input[type="color"]').forEach(function (picker) {
                var text = document.querySelector('input[name="' + picker.name + '_text"]');
                var toggle = document.querySelector('input[name="custom_' + picker.name + '"]');
                var watch = function () { if (toggle) toggle.checked = true; };
                if (!text) return;
                picker.addEventListener('input', function () { text.value = picker.value; watch(); });
                text.addEventListener('change', function () {
                    var v = text.value.trim();
                    if (v.charAt(0) !== '#') v = '#' + v;
                    if (/^#[0-9a-fA-F]{6}$/.test(v)) { picker.value = v; watch(); }
                });
            });
        })();
    </script>
@endsection
