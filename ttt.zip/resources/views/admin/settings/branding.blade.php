@extends('layouts.admin')
@include('partials.admin.settings.nav', ['activeTab' => 'branding'])

@section('title')
    Branding
@endsection

@section('content-header')
    <h1>Panel Branding<small>Change the icon and browser theme colour.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')
    <form action="{{ route('admin.settings.branding.update') }}" method="POST" enctype="multipart/form-data">
        {{-- Two bugs lived here: the form posted to the index route instead of
             the update route, and the update route is PATCH, so a plain POST
             matched nothing and returned 405. --}}
        @method('PATCH')
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Site Icon</h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-3 text-center">
                                <img
                                    src="/favicons/favicon-96x96.png?v={{ filemtime(public_path('favicons/favicon-96x96.png')) }}"
                                    alt="Current icon"
                                    class="img-rounded"
                                    style="width:96px;height:96px;object-fit:contain"
                                    onerror="this.style.visibility='hidden'"
                                />
                                <p class="text-muted"><small>Current icon (96×96)</small></p>
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label class="control-label">Upload a new icon</label>
                                    <input type="file" name="icon" accept="image/png,image/jpeg,image/gif" />
                                    <p class="text-muted">
                                        <small>
                                            One image is enough — every size browsers and platforms ask for
                                            is generated for you. PNG, JPEG or GIF, up to 4&nbsp;MB.
                                            512×512 or larger gives the sharpest result. SVG is not supported.
                                        </small>
                                    </p>
                                </div>

                                <div class="form-group" style="margin-top:20px">
                                    <label class="control-label">Crop to square</label>
                                    <div class="btn-group" data-toggle="buttons">
                                        <label class="btn btn-primary @if(old('crop', true)) active @endif">
                                            <input type="radio" name="crop" value="1" autocomplete="off" @if(old('crop', true)) checked @endif> Centre crop
                                        </label>
                                        <label class="btn btn-primary @unless(old('crop', true)) active @endunless">
                                            <input type="radio" name="crop" value="0" autocomplete="off" @unless(old('crop', true)) checked @endunless> Fit (letterbox)
                                        </label>
                                    </div>
                                    <p class="text-muted">
                                        <small>Centre crop fills the tile and trims the edges. Fit keeps the whole image and pads the sides.</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title">Browser Theme</h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label class="control-label">Theme colour</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    name="color"
                                    value="{{ old('color', $color) }}"
                                    placeholder="#007bff"
                                    pattern="#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})"
                                />
                                <p class="text-muted">
                                    <small>Used for the Safari pinned-tab icon, the Windows tile, and the browser address bar on mobile.</small>
                                </p>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="control-label">Web app name</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    name="name"
                                    value="{{ old('name', $name) }}"
                                    maxlength="64"
                                />
                                <p class="text-muted"><small>Written into <code>manifest.json</code> for "add to home screen".</small></p>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        @if($updatedAt)
                            <span class="text-muted pull-left" style="padding-top:6px">
                                <small>Last changed {{ $updatedAt }}</small>
                            </span>
                        @endif
                        {{-- The update route is PATCH, but a multipart form cannot
                             send PATCH, so Laravel's method spoofing is required.
                             Without this the browser POSTs to a GET/PATCH-only URL
                             and gets a 405. --}}
                        <input type="hidden" name="_method" value="PATCH" />
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    @if($canReset)
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-danger">
                    <div class="box-header with-border">
                        <h3 class="box-title">Restore Default Icon</h3>
                    </div>
                    <div class="box-body">
                        <p class="text-muted">
                            Puts the icons that shipped with the panel back and clears the branding
                            colour. The theme changes you made to the layout are not affected.
                        </p>
                    </div>
                    <div class="box-footer">
                        <form
                            action="{{ route('admin.settings.branding.reset') }}"
                            method="POST"
                            onsubmit="return confirm('Restore the default panel icon?')"
                        >
                            {!! csrf_field() !!}
                            <input type="hidden" name="confirm" value="1" />
                            <button type="submit" class="btn btn-sm btn-danger pull-right">Restore default</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    @endif
@endsection
