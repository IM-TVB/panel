@extends('layouts.admin')
@include('partials.admin.settings.nav', ['activeTab' => 'providers'])

@section('title')
    Plugin Sources
@endsection

@section('content-header')
    <h1>Plugin Sources<small>Where the plugin browser looks for add-ons.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Settings</li>
    </ol>
@endsection

@section('content')
    @yield('settings::nav')

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Sources</h3>
                </div>
                <div class="box-body">
                    <p class="text-muted">
                        The plugin browser merges the sources that are switched on. A source that
                        needs an API key is hidden from the browser until a key is saved here — the
                        key is used by the panel server-side and is never sent to visitors.
                    </p>
                    <p class="text-muted">
                        <strong>What to paste:</strong> the key exactly as the provider issued it, as
                        plain text. A key is <em>not</em> hashed, and it does not begin with
                        <code>$2a$</code> or <code>$2y$</code> — that prefix means the value is a
                        hashed password, which is what a database column looks like, not a key. If
                        you are copying from a database or a phpMyAdmin cell, you are looking at the
                        wrong column; find the provider's own API keys page instead.
                    </p>

                    @foreach ($providers as $provider)
                        <div class="box" style="margin-bottom:16px">
                            <div class="box-header with-border" style="display:flex;align-items:center;gap:10px">
                                <h3 class="box-title" style="margin:0;flex:1">{{ $provider['name'] }}</h3>
                                @if ($provider['configured'])
                                    <span class="label label-success">Ready</span>
                                @elseif ($provider['refused_at'])
                                    {{-- Stored but refused. Deliberately not "No API
                                         key": a key *is* saved here, and the operator
                                         needs to replace it, not go looking for it. --}}
                                    <span class="label label-danger">Key refused</span>
                                @elseif ($provider['needs_key'])
                                    <span class="label label-warning">No API key</span>
                                @else
                                    <span class="label label-default">Unavailable</span>
                                @endif
                            </div>
                            <div class="box-body">
                                @if (! $provider['needs_key'])
                                    <p class="text-muted" style="margin-bottom:0">
                                        No API key needed — this source is public and already switched on.
                                        There is nothing to paste on this one.
                                    </p>
                                @else
                                    @if ($provider['refused_at'])
                                        <p style="margin-bottom:8px">
                                            <span class="label label-danger">This key was refused</span>
                                        </p>
                                        <p class="text-muted">
                                            A key is saved
                                            ({{ $provider['key_length'] }} characters) but
                                            {{ $provider['name'] }} rejected it, so this source is
                                            <strong>hidden from the plugin browser</strong> &mdash;
                                            every search against it would fail. Last refused
                                            {{ \Carbon\Carbon::createFromTimestamp($provider['refused_at'])->diffForHumans() }}.
                                            Replace the key below.
                                        </p>
                                        <p class="text-muted">
                                            <small>
                                                A refused key is nearly always the wrong kind of
                                                token rather than a wrong value: a session or
                                                account token from the provider's own site, a token
                                                belonging to a different product, or a password
                                                hash pasted by mistake. Check that what you pasted
                                                came from the page linked below.
                                            </small>
                                        </p>
                                    @elseif ($provider['configured'])
                                        <p class="text-muted">
                                            A key is saved for this source
                                            ({{ $provider['key_length'] }} characters). It is not shown
                                            again; replace it below to change it.
                                        </p>
                                    @else
                                        <p class="text-muted">{{ $provider['hint'] }}</p>
                                    @endif


                                    @if ($provider['url'])
                                        <p style="margin-bottom:0">
                                            <a href="{{ $provider['url'] }}" target="_blank" rel="noopener noreferrer">
                                                {{ $provider['url'] }}
                                            </a>
                                        </p>
                                    @endif

                                    @if ($provider['shape'])
                                        <p class="text-muted" style="margin-bottom:0">
                                            <small>A key from this source is {{ $provider['shape'] }}.</small>
                                        </p>
                                    @endif

                                    @if ($provider['id'] === 'curseforge')
                                        <p class="text-muted" style="margin-top:10px;margin-bottom:0">
                                            <small>
                                                Getting a key is a manual step, not a copy-and-paste.
                                                CurseForge issues API keys from the CurseForge for
                                                Studios console above &mdash; sign in, create an
                                                organisation if asked, and generate a key there. The
                                                older <code>/account/api-proxies</code> page no longer
                                                exists. If you are not a game developer and the
                                                console will not issue you a key, the
                                                <a href="https://forms.monday.com/forms/dce5ccb7afda9a1c21dab1a1aa1d84eb?r=use1" target="_blank" rel="noopener noreferrer">3rd-party application form</a>
                                                is the other route, and it is reviewed by hand.
                                            </small>
                                        </p>
                                    @endif

                                    <form
                                        method="POST"
                                        action="{{ route('admin.plugins.providers.update') }}"
                                        style="margin-top:12px"
                                    >
                                        <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                                        <input type="hidden" name="provider" value="{{ $provider['id'] }}" />

                                        <div class="input-group" style="max-width:640px">
                                            <input
                                                type="text"
                                                name="key"
                                                class="form-control"
                                                data-key-check="{{ $provider['id'] }}"
                                                placeholder="{{ $provider['configured'] ? 'Enter a new key to replace the saved one' : 'Paste the API key' }}"
                                                autocomplete="off"
                                                spellcheck="false"
                                            />
                                            <span class="input-group-btn">
                                                <button type="submit" class="btn btn-primary">Save &amp; test</button>
                                            </span>
                                        </div>
                                        <p
                                            class="help-block at-keycheck"
                                            data-for="{{ $provider['id'] }}"
                                            style="display:none;margin-top:6px"
                                        ></p>
                                    </form>

                                    @if ($provider['configured'])
                                        <form
                                            method="POST"
                                            action="{{ route('admin.plugins.providers.update') }}"
                                            style="margin-top:8px"
                                        >
                                            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                                            <input type="hidden" name="provider" value="{{ $provider['id'] }}" />
                                            <input type="hidden" name="clear" value="1" />
                                            <button type="submit" class="btn btn-danger btn-sm">
                                                Remove this key
                                            </button>
                                        </form>
                                    @endif
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">About Bukkit</h3>
                </div>
                <div class="box-body">
                    <p class="text-muted" style="margin-bottom:0">
                        <strong>Bukkit plugins are served by CurseForge</strong>, under the same key as
                        everything else on that source — there is no separate Bukkit field, because
                        there is no separate operator behind one. CurseForge hosts the Bukkit plugin
                        category, and it also runs <code>dev.bukkit.org</code> (the site's own
                        navigation, Twitch sign-in and assets are all CurseForge's), so a second
                        source would have been a second name for one credential.
                    </p>
                    <p class="text-muted" style="margin-top:10px;margin-bottom:0">
                        The <strong>bukkit.org</strong> apex domain cannot be used at all: every request
                        to it is answered with an HTTP 403 behind a Cloudflare challenge, it publishes
                        no API, and its catalogue has been superseded by SpigotMC since 2014. No key
                        would change that. For Bukkit plugins, Spigot and Hangar are the two sources
                        that work without any key at all, and CurseForge is the third.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script>
        /**
         * Tell the operator what they pasted, at the moment they paste it.
         *
         * Server-side validation already refuses a password hash, but that only
         * happens after a round trip and a Save click, which is a slow way to
         * learn that the thing in your clipboard is a database column. This
         * catches the one mistake that has actually been made here, and stays
         * quiet about everything else: no provider documents its key format
         * reliably, so guessing "this does not look right" for an unfamiliar
         * shape would be worse than saying nothing.
         */
        (function () {
            var looksHashed = function (value) {
                // bcrypt and argon2, the two a PHP database will realistically
                // hold. Both are unmistakably not API keys.
                return /^\$(2[abxy]\$\d{2}\$[./A-Za-z0-9]{53}|argon2(id|i|d)\$)/.test(value);
            };

            Array.prototype.forEach.call(
                document.querySelectorAll('input[data-key-check]'),
                function (input) {
                    var provider = input.getAttribute('data-key-check');
                    var note = document.querySelector('.at-keycheck[data-for="' + provider + '"]');
                    if (!note) return;

                    var say = function (text, tone) {
                        if (!text) {
                            note.style.display = 'none';
                            note.textContent = '';

                            return;
                        }
                        note.style.display = 'block';
                        note.textContent = text;
                        note.className = 'help-block at-keycheck text-' + tone;
                    };

                    var check = function () {
                        var value = input.value.trim();

                        if (value === '') return say('', null);

                        if (looksHashed(value)) {
                            return say(
                                'That is a hashed password, not an API key. Keys are issued as plain ' +
                                    'text and never start with $2a$ or $2y$. Copy the key from the ' +
                                    "provider's API page, not from a database column.",
                                'danger'
                            );
                        }

                        if (/\s/.test(value)) {
                            return say(
                                'That contains a space. A key is a single unbroken string — check ' +
                                    'for a stray newline or a truncated paste.',
                                'warning'
                            );
                        }

                        say('Looks like a key. Save & test will confirm it against the provider.', 'muted');
                    };

                    input.addEventListener('input', check);
                    input.addEventListener('paste', function () {
                        // Run after the paste has landed, not before.
                        setTimeout(check, 0);
                    });
                }
            );
        })();
    </script>
@endsection
