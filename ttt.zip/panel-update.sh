#!/usr/bin/env bash
#
# Update a Pterodactyl panel that carries the Aternos theme, without losing data.
#
#   ./panel-update.sh <panel-dir> backup [dest]      # data backup only
#   ./panel-update.sh <panel-dir> verify            # theme + data check, no changes
#   ./panel-update.sh <panel-dir> update <tag>      # backup, update, re-theme, verify
#   ./panel-update.sh <panel-dir> update --latest   # ...same, newest published release
#
# Why this exists
#
# A Pterodactyl update replaces every stock file the panel ships. The theme is 145
# files inside that tree, and most of them are MODIFICATIONS to stock files --
# AssetComposer, the client settings interface, the dashboard container, the admin
# settings routes. An update therefore reverts them, while leaving the theme's own
# new files in place. The result is not a broken panel: it boots, and it looks
# half-themed. Nothing crashes, no log fills with errors, and the theme's own test
# suites mostly still pass because most of them assert on the theme's files, which
# survived.
#
# So an update here is: back the data up, take the panel apart, put it back
# together, re-apply the theme BEFORE the client is built, and then prove it --
# comparing the theme file by file and counting the rows in the tables that hold
# people's data. A step that fails stops the run and says which one.
#
# This is a wrapper around the official procedure, not a replacement for it. The
# update itself is exactly what pterodactyl.io documents: drop the release over the
# panel root, composer install, migrate, rebuild the client.

set -euo pipefail

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_DIR=""
ACTION=""
TAG=""
DEST=""

for arg in "$@"; do
    case "$arg" in
        --latest) TAG='--latest' ;;
        -*) echo "Unknown flag: $arg" >&2; exit 1 ;;
        *)
            if [[ -z "$PANEL_DIR" ]]; then PANEL_DIR="$arg"
            elif [[ -z "$ACTION" ]]; then ACTION="$arg"
            elif [[ "$ACTION" == 'update' ]]; then
                # update takes a tag
                [[ -z "$TAG" ]] || { echo "Unexpected argument: $arg" >&2; exit 1; }
                TAG="$arg"
            else
                # backup and verify take a destination / reference directory.
                #
                # Action-aware, because it was not: the first extra argument went
                # to TAG for every action, so the documented
                # `panel-update.sh <panel> verify <backupdir>` put the backup
                # directory where the tag goes and left the comparison with
                # nothing to compare against -- which then printed "Everything
                # checks out", having checked nothing.
                [[ -z "$DEST" ]] || { echo "Unexpected argument: $arg" >&2; exit 1; }
                DEST="$arg"
            fi
            ;;
    esac
done

if [[ -z "$PANEL_DIR" || -z "$ACTION" ]]; then
    cat >&2 <<'USAGE'
Usage: panel-update.sh <panel-directory> <action> [tag] [dest]

Actions
  backup [dest]      back up the database, uploads and daemon data
  verify            check the theme and the data; changes nothing
  update <tag>      back up, update, re-apply the theme, verify
                    <tag> may be a release tag (v1.11.13) or --latest

Examples
  panel-update.sh /var/www/pterodactyl backup
  panel-update.sh /var/www/pterodactyl verify
  panel-update.sh /var/www/pterodactyl update --latest
USAGE
    exit 1
fi

[[ -d "$PANEL_DIR" ]] || { echo "Error: '$PANEL_DIR' is not a directory." >&2; exit 1; }
[[ -f "$PANEL_DIR/artisan" ]] || { echo "Error: no artisan in '$PANEL_DIR' -- not a panel root." >&2; exit 1; }

# The panel runs as its own user and its files are root-owned; every write goes
# through the same escalation the installer uses.
SUDO=""
if [[ ! -w "$PANEL_DIR" ]]; then
    if sudo -n true 2>/dev/null; then
        SUDO="sudo"
    else
        echo "Error: '$PANEL_DIR' is not writable and passwordless sudo is unavailable." >&2
        exit 1
    fi
fi

# Run artisan as the panel's own user, never as root: Blade views and compiled
# assets end up owned by whoever compiled them, and a root-owned cache is a panel
# that 500s on the next deploy.
#
# PANEL_USER is derived from the ownership of the panel's own storage directory
# rather than left unset: it was never assigned anywhere, so this always fell
# back to hard-coded www-data, which is the wrong user on any install that runs
# the panel as nginx, apache or a dedicated pterodactyl user. storage/logs is
# written by the panel itself on every request, so whoever owns it is who the
# panel runs as.
if [[ -z "${PANEL_USER:-}" ]]; then
    PANEL_USER="$(stat -c %U "$PANEL_DIR/storage/logs" 2>/dev/null || true)"
    [[ -n "$PANEL_USER" && "$PANEL_USER" != 'root' ]] || PANEL_USER="www-data"
fi

as_panel() {
    # ${PANEL_USER:-} rather than $PANEL_USER: with `set -u` an unset PANEL_USER
    # aborts the function, and because the caller captures stdout with 2>/dev/null
    # the abort looks like the thing being called failed. It cost a confusing
    # "could not read the panel's database settings" to find.
    if [[ -n "${PANEL_USER:-}" ]]; then
        sudo -u "$PANEL_USER" env HOME=/tmp "$@"
    else
        sudo -u www-data env HOME=/tmp "$@"
    fi
}

# Set by do_backup, read by its callers. Not echoed on stdout, because do_backup
# narrates on stdout too and a caller that wants the path should not have to
# filter the narration out of it -- which is how the `backup` action ended up
# taking two backups instead of one.
BACKUP_PATH=""

# Corepack, asked not to ask.
#
# COREPACK_HOME points at an empty directory, so on a machine that has never run
# yarn through corepack, `yarn build:production` stops on
#
#     ! Corepack is about to download https://registry.yarnpkg.com/yarn/-/yarn-1.22.22.tgz
#     ? Do you want to continue? [Y/n]
#
# and waits for a keypress. That never showed up here because this box already had
# a populated corepack cache from earlier work, so the prompt was skipped -- which
# is exactly how a bug like this survives being tested on the machine that built
# it. On a fresh box, run from a script, or over a non-interactive ssh, it hangs.
export COREPACK_ENABLE_DOWNLOAD_PROMPT=0
export COREPACK_ENABLE_TELEMETRY=0
export COREPACK_HOME="${COREPACK_HOME:-/tmp/corepack}"

step()  { printf '\n\033[1m==> %s\033[0m\n' "$1"; }
info()  { printf '    %s\n' "$1"; }
die()   { printf '\n\033[1;31mFAILED: %s\033[0m\n' "$1" >&2; exit 1; }

# ------------------------------------------------------------------- config ---
# The database settings come from the panel itself, not from parsing .env.
#
# The .env route was tried and got the password wrong -- 64 characters, and the
# parse handed mysqldump a truncated one, which refused with "access denied" and
# left a backup directory containing nothing. A .env value can be quoted, can
# contain a '#' that a shell would treat as a comment, and can be overridden in
# config/database.php, which the panel's own bootstrap resolves and a text parse
# does not. Asking the panel is also what makes this portable: the same answer on
# any install.
#
# The password goes into a temporary defaults-file rather than onto the command
# line, because `ps` shows every user's command lines and a 64-character password
# belongs in neither. The file is 0600 and removed on exit.
DB_DEFAULTS=""

cleanup() {
    [[ -n "$DB_DEFAULTS" && -f "$DB_DEFAULTS" ]] && rm -f "$DB_DEFAULTS"
    [[ -n "${WORK_DIR:-}" && -d "${WORK_DIR:-}" ]] && rm -rf "$WORK_DIR"
    return 0
}
trap cleanup EXIT

resolve_db() {
    local helper="$THEME_DIR/db-config.php"
    [[ -f "$helper" ]] || die "db-config.php is missing from this package"

    local resolved
    resolved="$(as_panel php "$helper" "$PANEL_DIR" 2>/dev/null)"         || die "could not read the panel's database settings"

    eval "$resolved"

    DB_VIA_SOCKET="${DB_VIA_SOCKET:-no}"

    # mysqldump and mysql both read [client] from a defaults-file. Written with a
    # restrictive umask so the password is never briefly world-readable.
    DB_DEFAULTS="$(mktemp)"
    chmod 600 "$DB_DEFAULTS"
    {
        echo '[client]'
        echo "user=$DB_USERNAME"
        echo "password=$DB_PASSWORD"
        if [[ "$DB_VIA_SOCKET" == 'yes' ]]; then
            echo "socket=$DB_SOCKET"
        else
            echo "host=$DB_HOST"
            echo "port=$DB_PORT"
        fi
    } > "$DB_DEFAULTS"
}

resolve_db

# One place that runs a query and prints rows, whichever way it connects.
db_query() {
    $SUDO mysql --defaults-extra-file="$DB_DEFAULTS" -N -B -e "$1" "$DB_DATABASE"
}

# The tables whose row counts are worth comparing across an update: the things
# that are people's work rather than the panel's own bookkeeping.
COUNT_SQL="
    SELECT 'users', COUNT(*) FROM users
    UNION ALL SELECT 'servers', COUNT(*) FROM servers
    UNION ALL SELECT 'settings', COUNT(*) FROM settings
    UNION ALL SELECT 'eggs', COUNT(*) FROM eggs
    UNION ALL SELECT 'subusers', COUNT(*) FROM subusers;"

BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/pterodactyl}"
STATE_DIR="$BACKUP_ROOT/state"

# ------------------------------------------------------------------ backup ----
#
# What counts as data, and what does not:
#
#   the database          every user, server, egg, nest and setting. 2 MB here.
#   public/backgrounds    the panel and sign-in page background images
#   public/branding       the logo
#   storage/              plugin assets and the framework's writable state
#   /etc/pterodactyl      the daemon config, when the daemon is on this host
#   /var/lib/pterodactyl  the game server files, when the daemon is on this host
#
# The theme is NOT backed up here. It is a file list in this package, sealed with
# checksums, and it is re-applied rather than restored -- a restored copy could be
# a stale one, and a re-applied one cannot.
do_backup() {
    local dest="${1:-$BACKUP_ROOT}"
    local stamp out
    stamp="$(date +%Y%m%d-%H%M%S)"
    out="$dest/$stamp"

    step "Backing up to $out"
    $SUDO mkdir -p "$out"

    # --- database
    if [[ "$DB_VIA_SOCKET" == 'yes' ]]; then
        info "database: $DB_DATABASE over socket $DB_SOCKET"
    else
        info "database: $DB_DATABASE at $DB_HOST:$DB_PORT as $DB_USERNAME"
    fi
    # --single-transaction so a consistent snapshot without locking anybody out of
    # a panel that is still serving traffic.
    $SUDO mysqldump --defaults-extra-file="$DB_DEFAULTS" \
        --single-transaction --quick --routines --triggers --events \
        "$DB_DATABASE" | $SUDO tee "$out/database.sql" >/dev/null
    [[ -s "$out/database.sql" ]] || die "the database dump is empty -- refusing to call this a backup"
    info "  $(wc -c < "$out/database.sql") bytes of SQL"

    # --- row counts, so a later verify can prove the data survived
    $SUDO mkdir -p "$STATE_DIR"
    db_query "$COUNT_SQL" | $SUDO tee "$out/row-counts.txt" >/dev/null
    info "row counts recorded, to be compared after the update:"
    sed 's/^/    /' "$out/row-counts.txt"

    # --- files
    for d in public/backgrounds public/branding public/avatars storage/app/public storage/logs; do
        if [[ -d "$PANEL_DIR/$d" ]]; then
            $SUDO tar -C "$PANEL_DIR" -czf "$out/$(echo "$d" | tr / _).tar.gz" "$d" 2>/dev/null \
                && info "  $d" || info "  $d (skipped)"
        fi
    done

    # --- daemon, only if it is on this host
    local daemon_here=0
    for d in etc/pterodactyl var/lib/pterodactyl; do
        if [[ -d "/$d" ]]; then
            $SUDO tar -C / -czf "$out/${d//\//_}.tar.gz" "$d"
            info "  /$d  (this host runs the daemon too, so the game files are included)"
            daemon_here=1
        fi
    done
    if [[ "$daemon_here" -eq 0 ]]; then
        info "no daemon on this host, so no game files to copy -- the panel is"
        info "the only thing here, and the backup is complete without them"
    fi

    # --- the theme's own state, so a restore knows what it should end up with
    if [[ -x "$THEME_DIR/install.sh" ]]; then
        local theme_state="drifted"
        "$THEME_DIR/install.sh" "$PANEL_DIR" --check >/dev/null 2>&1 && theme_state="intact"
        echo "$theme_state" | $SUDO tee "$out/theme-state.txt" >/dev/null
        info "theme state at backup time: $theme_state"
    fi

    # --- checksums, so a restore can prove the archive is whole.
    # No `|| true`: the first version had one, and because the write failed on
    # permissions the backup was quietly produced with no checksums at all --
    # indistinguishable, from the outside, from a correct one.
    # `for f in "$out"/*.tar.gz` rather than a bare ./*.tar.gz inside sh -c:
    # with no tar.gz present the glob stays literal, sha256sum fails on the
    # nonexistent file, and set -e kills the script after a successful backup.
    $SUDO sh -c "cd '$out' && for f in ./*.tar.gz; do [ -e \"\$f\" ] && echo \"\$f\"; done | xargs sha256sum database.sql > SHA256SUMS"
    info "checksums written: $(wc -l < "$out/SHA256SUMS") files"

    BACKUP_PATH="$out"

    printf '\n\033[1mBackup complete: %s\033[0m\n' "$out"
    info "restore the database with:"
    # database.sql is written uncompressed (mysqldump | tee), so it is fed to
    # mysql directly -- an earlier version of this hint said `gunzip -c`, which
    # fails on a file that was never gzipped.
    info "  mysql --defaults-extra-file=<your.cnf> $DB_DATABASE < $out/database.sql"
    info "  (or: mysql -u $DB_USERNAME -p $DB_DATABASE < $out/database.sql)"
    info "restore the files with:"
    info "  tar -C $PANEL_DIR -xzf $out/public_backgrounds.tar.gz   # and the rest"
}

# ------------------------------------------------------------------ verify ----
do_verify() {
    local ref="${1:-}"
    local bad=0

    step "Theme"
    if [[ -x "$THEME_DIR/install.sh" ]]; then
        if "$THEME_DIR/install.sh" "$PANEL_DIR" --check; then
            :
        else
            bad=1
        fi
    else
        info "no installer next to this script; skipping the theme check"
    fi

    step "Data"
    if [[ -n "$ref" && ! -f "$ref/row-counts.txt" ]]; then
        info "'$ref' has no row-counts.txt -- is it a backup directory?"
        bad=1
    elif [[ -n "$ref" && -f "$ref/row-counts.txt" ]]; then
        local now
        now="$(mktemp)"
        db_query "$COUNT_SQL" > "$now"

        if diff -u "$ref/row-counts.txt" "$now" >/dev/null 2>&1; then
            info "row counts unchanged:"
            sed 's/^/    /' "$now"
        else
            info "ROW COUNTS CHANGED since $ref:"
            diff -u "$ref/row-counts.txt" "$now" | sed 's/^/    /' || true
            bad=1
        fi
        $SUDO rm -f "$now"
    else
        info "no reference counts given; pass a backup directory to compare against"
    fi

    step "Result"
    if [[ "$bad" -eq 0 ]]; then
        printf '\033[1;32m    Everything checks out.\033[0m\n'
    else
        printf '\033[1;31m    Something needs attention (see above).\033[0m\n'
    fi
    return $bad
}

# ------------------------------------------------------------------ update ----
do_update() {
    local tag="$1"
    local backup_dir work

    if [[ "$tag" == '--latest' || -z "$tag" ]]; then
        step "Finding the latest release"
        tag="$(curl -fsSL --max-time 30 https://api.github.com/repos/pterodactyl/panel/releases/latest \
            | grep -m1 '"tag_name"' | cut -d'"' -f4)"
        [[ -n "$tag" ]] || die "could not read the latest release from GitHub; pass a tag explicitly"
        info "latest is $tag"
    fi

    # 1. Back up first. Not "probably fine" -- first.
    do_backup
    backup_dir="$BACKUP_PATH"
    [[ -n "$backup_dir" && -d "$backup_dir" ]] || die "the backup step produced no directory; not continuing"
    info "backup at $backup_dir -- if anything below goes wrong, that is the way back"

    WORK_DIR="$(mktemp -d)"
    work="$WORK_DIR"

    # 2. Fetch the release.
    step "Downloading $tag"
    local url="https://github.com/pterodactyl/panel/releases/download/${tag}/panel.tar.gz"
    info "$url"
    curl -fsSL --max-time 300 -o "$work/panel.tar.gz" "$url" \
        || die "could not download $url -- check the tag exists"
    info "$(wc -c < "$work/panel.tar.gz") bytes"

    # 3. Take the panel down politely.
    step "Taking the panel down"
    as_panel php "$PANEL_DIR/artisan" down --render="errors::503" 2>/dev/null \
        || info "could not set maintenance mode; continuing"

    # 4. Lay the release over the panel root. THIS is the step that reverts the
    #    theme: it overwrites every stock file, which is most of what the theme is.
    step "Laying the release over $PANEL_DIR"
    info "config/ and .env are preserved: the tarball ships a .env.example, not a .env"
    $SUDO tar -xzf "$work/panel.tar.gz" -C "$PANEL_DIR" --exclude='.env' --exclude='config/*' \
        || die "extracting the release failed; restore from $backup_dir"
    $SUDO chown -R www-data:www-data "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache" 2>/dev/null || true

    # 5. PHP dependencies and migrations, on STOCK code. Deliberately before the
    #    theme goes back on: a migration must not have to boot a theme written
    #    against the previous release.
    step "composer install"
    ( cd "$PANEL_DIR" && $SUDO composer install --no-dev --optimize-autoloader --no-interaction ) \
        || die "composer install failed; restore from $backup_dir"

    step "migrations"
    as_panel php "$PANEL_DIR/artisan" migrate --force --no-interaction \
        || die "a migration failed; restore from $backup_dir. Do NOT re-apply the theme yet --"
    info "  the panel's own migrations ran and succeeded"

    # 6. The theme, back on, BEFORE the client is built. The client build compiles
    #    whatever is in resources/scripts, so the theme has to be in place first or
    #    the bundle is built from stock and looks unthemed with no error anywhere.
    step "Re-applying the Aternos theme"
    "$THEME_DIR/install.sh" "$PANEL_DIR" --force \
        || die "the theme would not apply; the panel is currently stock. Restore from $backup_dir"

    # 7. Build the client.
    step "Building the client"
    # build-client.sh, not an inline yarn call: it sets the heap limit explicitly
    # rather than letting V8 guess from total memory, and separates "the box ran
    # out of memory" from "this does not compile". Guessing wrong in an update is
    # expensive, because the panel is already half replaced by this point.
    if ! "$THEME_DIR/build-client.sh" "$PANEL_DIR"; then
        die "the client build failed. The reason is printed above. The theme WAS
    re-applied in step 6, so the panel is themed but the assets are stale --
    re-run the build (\"$THEME_DIR/build-client.sh\" $PANEL_DIR) or restore
    from $backup_dir."
    fi

    # 8. Caches and permissions.
    step "Clearing caches"
    as_panel php "$PANEL_DIR/artisan" config:clear >/dev/null 2>&1 || true
    as_panel php "$PANEL_DIR/artisan" view:clear   >/dev/null 2>&1 || true
    as_panel php "$PANEL_DIR/artisan" route:clear  >/dev/null 2>&1 || true
    $SUDO chown -R www-data:www-data "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache" 2>/dev/null || true
    $SUDO chmod -R 775 "$PANEL_DIR/storage" "$PANEL_DIR/bootstrap/cache" 2>/dev/null || true
    info "done"

    # 9. Prove it.
    step "Verifying"
    do_verify "$backup_dir" || true

    step "Bringing the panel back up"
    as_panel php "$PANEL_DIR/artisan" up || info "could not clear maintenance mode; clear it by hand"

    printf '\n\033[1mUpdated to %s. Backup kept at %s\033[0m\n' "$tag" "$backup_dir"
}

case "$ACTION" in
    # One call, and the path comes back in BACKUP_PATH rather than by listing the
    # directory afterwards -- which would have been right by accident, since two
    # runs inside the same second share a stamp.
    backup)  do_backup "$DEST" ;;
    verify)  do_verify "$DEST" ;;
    update)  do_update "$TAG" ;;
    *) echo "Unknown action: $ACTION" >&2; exit 1 ;;
esac
