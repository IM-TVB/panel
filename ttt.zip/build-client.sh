#!/usr/bin/env bash
#
# Build the panel's client bundle, on a box that may not have much memory.
#
#   ./build-client.sh <panel-directory>
#
# Exists because "run yarn build:production" is not a portable instruction.
#
# The failure it exists for: on a 1 GB VPS the build died with
#
#     <--- Last few GCs --->
#     FATAL ERROR: Ineffective mark-compacts near heap limit
#                  Allocation failed - JavaScript heap out of memory
#
# which reads like the panel is too big to build and is not. The build needs
# roughly 400 MB of heap -- it completes here with the cap set to 384. The problem
# is that V8 picks its own heap limit from total system memory, and on a 956 MB box
# it picks about 486 MB. The build's peak sat right at that number, with MySQL,
# PHP-FPM and Wings all resident, and it ran out. Nothing was wrong with the theme,
# the panel, or the machine -- the limit was simply never stated.
#
# So this states it, derived from what is actually free rather than from total
# memory, and leaves room for everything else on the box. It also tells the
# difference between "out of memory" and "your panel does not compile", because
# the first is a machine problem and the second is a code problem, and the two need
# opposite responses.

set -euo pipefail

PANEL="${1:-}"
[[ -n "$PANEL" ]] || { echo "Usage: $0 <panel-directory>" >&2; exit 1; }
[[ -d "$PANEL" ]] || { echo "Error: '$PANEL' is not a directory." >&2; exit 1; }

# A little shared helper so the yarn calls below and those in the other scripts
# agree. Not sourced -- a sourced file that fails to parse takes the caller with
# it, and there is nothing here worth that risk.
yarn_env() {
    # Corepack, told not to ask. An empty COREPACK_HOME on a machine that has
    # never run yarn makes it stop on a [Y/n] prompt, which hangs a script.
    echo "COREPACK_ENABLE_DOWNLOAD_PROMPT=0 COREPACK_ENABLE_TELEMETRY=0 HOME=/tmp COREPACK_HOME=${COREPACK_HOME:-/tmp/corepack}"
}

# --------------------------------------------------------------- memory ------
#
# MemAvailable from /proc/meminfo, not MemFree: it accounts for reclaimable page
# cache, which on a box that has just been running a build is most of the
# difference between "has memory" and "does not". free(1) is the fallback for
# anything that is not Linux.
available_mb() {
    local kb
    if [[ -r /proc/meminfo ]]; then
        kb="$(awk '/^MemAvailable:/ {print $2; exit}' /proc/meminfo 2>/dev/null || true)"
        if [[ -n "$kb" ]]; then
            echo $(( kb / 1024 ))
            return
        fi
    fi
    free -m 2>/dev/null | awk '/^Mem:/ {print $7; exit}'
}

AVAIL="$(available_mb || echo 0)"
[[ "$AVAIL" =~ ^[0-9]+$ ]] || AVAIL=0
TOTAL="$(awk '/^MemTotal:/ {print int($2/1024); exit}' /proc/meminfo 2>/dev/null || echo 0)"

# The build needs about 400 MB. Give it that plus room to grow, take a fixed
# allowance off the top for MySQL, PHP-FPM, Wings and the kernel, and cap it so a
# big machine does not let V8 sit on a 3 GB heap it will never use.
#
# The 200 MB allowance is not arbitrary: it is what this box was using with
# everything resident, and going under it invites the OOM killer, which would take
# MySQL out instead of V8 -- a much worse outcome than a failed build.
HEAP=$(( AVAIL > 200 ? AVAIL - 200 : 448 ))
(( HEAP < 448 )) && HEAP=448
(( HEAP > 2048 )) && HEAP=2048

echo "    memory: ${TOTAL} MiB total, ${AVAIL} MiB available -> heap cap ${HEAP} MiB"

if [[ "$AVAIL" -lt 500 ]]; then
    echo "    warning: under 500 MiB available. The build needs about 400 MB of heap"
    echo "    and may still fail. If it does, see the note it prints."
fi

# ---------------------------------------------------------------- build ------
# Same sudo probe as install.sh / setup.sh / panel-update.sh: setting SUDO=sudo
# unconditionally fails on hosts that have no sudo at all (containers, root
# shells), which is exactly where this script is often run.
SUDO=""
if [[ ! -w "$PANEL" ]]; then
    if sudo -n true 2>/dev/null; then
        SUDO="sudo"
    else
        echo "Error: '$PANEL' is not writable and passwordless sudo is unavailable." >&2
        exit 1
    fi
fi

if [[ ! -d "$PANEL/node_modules" ]]; then
    echo "    node_modules is missing, running yarn install first (several minutes)"
    # shellcheck disable=SC2046
    ( cd "$PANEL" && $SUDO env $(yarn_env) yarn install --network-timeout 600000 ) \
        || { echo "    yarn install failed" >&2; exit 1; }
fi

LOG="$(mktemp)"
trap 'rm -f "$LOG"' EXIT

echo "    yarn build:production"
# shellcheck disable=SC2046
if ( cd "$PANEL" && $SUDO env $(yarn_env) NODE_OPTIONS="--max-old-space-size=$HEAP" \
        yarn build:production ) >"$LOG" 2>&1; then
    tail -2 "$LOG" | sed 's/^/      /'
    exit 0
fi

# ------------------------------------------------------------- diagnose ------
#
# The two failures worth telling apart, because they need opposite responses.
#
# Out of memory is a machine problem: the fix is more RAM, more swap, fewer
# services during the build, or building the assets somewhere with room and
# copying the result in. Nothing about the panel or the theme is wrong.
#
# A compile error is a code problem: the fix is in this package, and the error
# names the file.
if grep -qE "heap out of memory|heap limit|OutOfMemory" "$LOG"; then
    echo >&2
    echo "    The build ran out of memory. This is the machine, not the theme:" >&2
    echo "    the panel is not too big to build -- it needs about 400 MB of heap and" >&2
    echo "    was given ${HEAP} MB on a box with ${AVAIL} MiB free." >&2
    echo >&2
    echo "    Any of these will do it:" >&2
    echo >&2
    echo "      1. Free memory first. Wings and the panel's own services are the" >&2
    echo "         usual pair on a small box:" >&2
    echo "             systemctl stop wings" >&2
    echo "             $0 $PANEL" >&2
    echo "             systemctl start wings" >&2
    echo >&2
    echo "      2. Add swap, if there is not enough already:" >&2
    echo "             fallocate -l 2G /swapfile && chmod 600 /swapfile" >&2
    echo "             mkswap /swapfile && swapon /swapfile" >&2
    echo >&2
    echo "      3. Build the assets somewhere with room and copy them in. The build" >&2
    echo "         output is one self-contained directory -- public/assets, hashed" >&2
    echo "         chunk names and all -- and nothing outside it is needed at" >&2
    echo "         runtime. So on any machine with a few GB:" >&2
    echo "             ./install.sh <panel>          # get the files in place" >&2
    echo "             yarn build:production        # over there" >&2
    echo "             rsync -a public/assets/ <this-box>:$PANEL/public/assets/" >&2
    echo >&2
    echo "      4. Give the panel its own box. A 1 GB VPS is under what a Pterodactyl" >&2
    echo "         panel wants to run, independent of this theme." >&2
    echo >&2
    echo "    The last lines of the build said:" >&2
    tail -6 "$LOG" | sed 's/^/      /' >&2
    exit 1
fi

echo >&2
echo "    The build failed, and it was not out of memory -- so this looks like a" >&2
echo "    compile error, which is a problem in this package rather than on the box." >&2
echo >&2
grep -E "error|Error|ERROR|Module not found|SyntaxError" "$LOG" | head -8 | sed 's/^/      /' >&2
echo >&2
tail -8 "$LOG" | sed 's/^/      /' >&2
exit 1
