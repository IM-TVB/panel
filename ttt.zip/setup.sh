#!/usr/bin/env bash
#
# One command. Installs the Aternos theme into a Pterodactyl panel, builds the
# client, and proves it worked.
#
#   ./setup.sh                  # finds the panel itself
#   ./setup.sh /path/to/panel   # or tells it where
#   ./setup.sh --help
#
# This is the entry point. install.sh is the part that copies files and nothing
# else; this adds the three steps that a person would otherwise have to remember
# and get wrong, in this order:
#
#   1. clear the view/config/route caches. A stale compiled Blade from before the
#      install is the difference between a themed panel and a panel that looks
#      stock with no error in sight.
#   2. build the client. The theme's CSS and JS are bundled into public/assets --
#      they are not live-linked -- so a panel with the files in place and no build
#      is a panel that looks completely stock.
#   3. verify. Every one of the theme's files compared against this package, so
#      "done" means checked rather than "the copy loop finished".
#
# The panel directory is found rather than asked for, because the documented
# location is /var/www/pterodactyl and making someone type it is how a
# copy-paste ends up writing the theme into their home directory.

set -euo pipefail

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    sed -n '3,25p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
    exit 0
fi

PANEL_ARG="${1:-${PTERODACTYL_PANEL:-}}"

# Corepack, asked not to ask.
#
# COREPACK_HOME points at an empty directory, so on a machine that has never run
# yarn through corepack, `yarn build:production` stops on
#
#     ! Corepack is about to download https://registry.yarnpkg.com/yarn/-/yarn-1.22.22.tgz
#     ? Do you want to continue? [Y/n]
#
# and waits for a keypress. That never showed up here because this box already had
# a populated corepack cache from earlier work, so the prompt was skipped -- which
# is exactly how a bug like this survives being tested on the machine that built
# it. On a fresh box, run from a script, or over a non-interactive ssh, it hangs.
export COREPACK_ENABLE_DOWNLOAD_PROMPT=0
export COREPACK_ENABLE_TELEMETRY=0
export COREPACK_HOME="${COREPACK_HOME:-/tmp/corepack}"

step() { printf '\n\033[1m==> %s\033[0m\n' "$1"; }
info() { printf '    %s\n' "$1"; }
warn() { printf '    \033[1;33m%s\033[0m\n' "$1"; }
die()  { printf '\n\033[1;31mFAILED: %s\033[0m\n' "$1" >&2; exit 1; }

# ------------------------------------------------------------------- locate ---
#
# In order: what the caller passed, then the environment, then the documented
# location, then the handful of places people actually put it, then the current
# directory if it looks like a panel. A wrong guess is worse than no guess, so
# every candidate is checked for a panel's two fingerprint files before it is
# accepted -- an existing directory that is not a panel is never selected.
is_panel() {
    [[ -f "$1/composer.json" && -f "$1/artisan" && -d "$1/resources/scripts" ]]
}

locate_panel() {
    local c

    if [[ -n "$PANEL_ARG" ]]; then
        is_panel "$PANEL_ARG" || die "'$PANEL_ARG' does not look like a Pterodactyl panel (no composer.json, artisan, or resources/scripts)."
        printf '%s\n' "$PANEL_ARG"
        return
    fi

    for c in /var/www/pterodactyl /opt/pterodactyl/panel /srv/pterodactyl "$PWD"; do
        if is_panel "$c"; then
            printf '%s\n' "$c"
            return
        fi
    done

    # Last resort: one level down under /var/www, which is where most people put
    # it when they did not use the documented path.
    for c in /var/www/*/; do
        if is_panel "${c%/}"; then
            printf '%s\n' "${c%/}"
            return
        fi
    done

    die "could not find a Pterodactyl panel. Looked in /var/www/pterodactyl, /opt/pterodactyl/panel, /srv/pterodactyl, $PWD, and one level under /var/www. Pass the path: $0 /path/to/panel"
}

step "Finding the panel"
PANEL="$(locate_panel)"
info "panel:  $PANEL"
info "theme:  $THEME_DIR  ($(cat "$THEME_DIR/VERSION" 2>/dev/null || echo unversioned))"

SUDO=""
if [[ ! -w "$PANEL" ]]; then
    if sudo -n true 2>/dev/null; then
        SUDO="sudo"
        info "escalating with sudo: the panel is not writable by $(id -un)"
    else
        die "the panel is not writable by $(id -un) and passwordless sudo is unavailable. Re-run as root."
    fi
fi

# The panel's own user, for artisan and for the build. Root-owned compiled assets
# are a panel that 500s on the next deploy.
PANEL_USER=""
for c in www-data pterodactyl nginx apache; do
    if id "$c" >/dev/null 2>&1; then PANEL_USER="$c"; break; fi
done
# The env above is exported, so sudo keeps it; named here for the case where
# someone runs this with sudo -E off.
as_panel() { sudo -u "$PANEL_USER" env HOME=/tmp "$@"; }

# ------------------------------------------------------------ requirements ---
#
# Fail here, before anything is written, with the tool names, rather than halfway
# through the client build with "yarn: command not found". A theme install that
# dies mid-build leaves the panel with new files and an old bundle, which is the
# worst state this script knows how to leave behind.
step "Checking requirements"
missing=""
command -v node >/dev/null 2>&1     || missing="$missing node"
command -v yarn >/dev/null 2>&1     || missing="$missing yarn"
command -v php  >/dev/null 2>&1     || missing="$missing php"
command -v composer >/dev/null 2>&1 || missing="$missing composer"
if [[ -n "$missing" ]]; then
    warn "missing:$missing"
    echo
    echo "  Install them, then re-run this script. On a Debian/Ubuntu box:"
    echo "    curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -"
    echo "    sudo apt install -y nodejs php-cli php-mysql php-mbstring php-xml php-curl php-zip php-gd php-bcmath"
    echo "    sudo corepack enable && sudo corepack prepare yarn@1.22.22 --activate   # provides yarn"
    echo "    curl -sS https://getcomposer.org/installer | php | sudo mv composer.phar /usr/local/bin/composer"
    echo
    die "required tools are not installed:$missing"
fi
info "node $(node -v 2>/dev/null), yarn $(yarn -v 2>/dev/null), php $(php -r 'echo PHP_VERSION;' 2>/dev/null)"

# --------------------------------------------------------------- preflight ---
#
# A hand-extract of this package is caught HERE, before anything is written,
# rather than after. Extracting over a panel puts 18 of the 145 files -- including
# the whole stylesheet -- into five directories a stock panel does not have, and
# nothing errors. Detecting it up front means the person finds out from this
# script instead of from a page that looks unthemed.
step "Checking for a previous bad install"
STRAY=""
for top in assets components plugins routers views; do
    [[ -d "$PANEL/$top" ]] && STRAY="$STRAY $top"
done
if [[ -n "$STRAY" ]]; then
    warn "found package-only directories in $PANEL:$STRAY"
    warn "that is what extracting this tarball over the panel leaves behind."
    echo
    echo "  Run this to clear it, then re-run setup:"
    echo "    $THEME_DIR/install.sh '$PANEL' --clean-stray"
    echo
    exit 3
fi
info "clean"

# ------------------------------------------------------------------ install ---
step "Installing the theme"
# install.sh refuses nothing and backs up what it replaces; --force because a
# half-themed panel from an earlier attempt is the common case and needs the
# overwrite rather than a skip.
# The summary and the backup line, not the last N lines: on a --force run the
# per-file lines push the summary off the end of a tail, and the summary is the
# only part worth reading.
if ! INSTALL_OUT="$("$THEME_DIR/install.sh" "$PANEL" --force 2>&1)"; then
    echo "$INSTALL_OUT" | tail -20 | sed 's/^/    /'
    die "install.sh failed. Nothing after this point was run."
fi
strip_ansi() { sed -e 's/\x1b\[[0-9;]*m//g'; }
# Every grep below is allowed to match nothing -- a re-run writes no files, and a
# clean verify has no ALTERED lines -- so each carries `|| true`. Without it,
# `set -o pipefail` plus `set -e` makes a no-op install, the most common run there
# is, exit 1 with no error message after the backup line.
echo "$INSTALL_OUT" | strip_ansi | grep -E '^(Done:|Backups:)' | sed 's/^/  /' || true
echo "$INSTALL_OUT" | grep -E '^  (write|backup):' | head -6 | sed 's/^/  /' || true

# One source of truth for the count: install.sh's own "Done: N written" line.
# Deriving it by counting "write:" lines doubled it, because install.sh emits one
# of those on the backup line as well -- so it said "and 70 more written" for 32
# more files. Counting lines that also appear in someone else's summary is how the
# two numbers drift apart.
written=$(echo "$INSTALL_OUT" | sed -e 's/\x1b\[[0-9;]*m//g' | grep -oE 'Done: [0-9]+ written' | grep -oE '[0-9]+' || true)
written="${written:-0}"
listed=6
if [[ "$written" -gt "$listed" ]]; then
    echo "  ... and $((written - listed)) more"
fi

# ------------------------------------------------------------------- caches ---
step "Clearing caches"
# Before the build, not after: a compiled Blade view from before the install is
# rendered instead of the new one, and the panel looks stock with no error.
as_panel php "$PANEL/artisan" view:clear   >/dev/null 2>&1 && info "view cache cleared"   || warn "could not clear the view cache"
as_panel php "$PANEL/artisan" config:clear >/dev/null 2>&1 && info "config cache cleared" || warn "could not clear the config cache"
as_panel php "$PANEL/artisan" route:clear  >/dev/null 2>&1 && info "route cache cleared"  || warn "could not clear the route cache"

# -------------------------------------------------------------------- build ---
step "Building the client"
# Not optional and not skippable. The theme's stylesheet is bundled into
# public/assets, so without this the panel serves stock CSS no matter how many
# files landed correctly.
# Delegated, rather than a yarn call inline, because the build is the one step
# that is not portable: V8 picks its own heap limit from total system memory and
# on a 1 GB box that is about 486 MB, which is where the build's peak sits. See
# build-client.sh -- it states the limit, and tells an out-of-memory apart from a
# compile error, which need opposite responses.
"$THEME_DIR/build-client.sh" "$PANEL" \
    || die "the client build failed. The reason is above: either the box needs more
    memory, or this package does not compile against your panel version."

# ----------------------------------------------------------------- ownership ---
step "Fixing ownership"
$SUDO mkdir -p "$PANEL/storage/framework" "$PANEL/bootstrap/cache"
$SUDO chown -R "$PANEL_USER":"$PANEL_USER" "$PANEL/storage" "$PANEL/bootstrap/cache" 2>/dev/null || true
$SUDO chmod -R 775 "$PANEL/storage" "$PANEL/bootstrap/cache" 2>/dev/null || true
info "$PANEL_USER:$PANEL_USER on storage/ and bootstrap/cache"

# ------------------------------------------------------------------- verify ---
step "Verifying"
VERIFY_OUT="$("$THEME_DIR/install.sh" "$PANEL" --check 2>&1)" && VERIFY_OK=1 || VERIFY_OK=0
echo "$VERIFY_OUT" | grep -E "package:|matching|ALTERED|MISSING" | sed 's/^/    /' || true
if [[ "$VERIFY_OK" -ne 1 ]]; then
    echo "$VERIFY_OUT" | tail -14 | sed 's/^/    /'
    die "the theme did not verify. The files are in place but something differs from the package -- see above."
fi

# ------------------------------------------------------------------- summary ---
printf '\n\033[1;32m==> Done.\033[0m\n\n'
info "panel:   $PANEL"
MATCHING=$(echo "$VERIFY_OUT" | grep -oE '[0-9]+ matching' | head -1 || true)
info "theme:   $(cat "$THEME_DIR/VERSION" 2>/dev/null || echo unversioned)${MATCHING:+, $MATCHING}"
echo
echo "  Hard-refresh the browser (Ctrl+Shift+R). The stylesheet is bundled, so a"
echo "  cached copy will show the old page no matter how fresh the server is."
echo
echo "  Worth looking at:"
echo "    - the dashboard, for the sidebar and the server card"
echo "    - the sign-in page, for the split screen"
echo "    - Admin -> Settings, for the logo and the two background images"
echo
echo "  If something looks wrong:"
echo "    $THEME_DIR/install.sh '$PANEL' --check      # what differs, if anything"
echo "    $THEME_DIR/panel-update.sh '$PANEL' backup # a restorable backup"
