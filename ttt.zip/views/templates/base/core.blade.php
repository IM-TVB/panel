{{-- The theme class is applied to <html> by the inline script in
     templates/wrapper.blade.php, so <body> keeps the stock background. In light
     mode the aternos.css remap overrides it to --at-page. --}}
@extends('templates/wrapper', [
    'css' => ['body' => 'bg-neutral-800'],
])

@section('container')
    <div id="modal-portal"></div>
    <div id="app"></div>
@endsection
