<!DOCTYPE html>
<html>
    <head>
        <title>{{ config('app.name', 'Pterodactyl') }}</title>

        @php
            // Icon metadata written by `php tools/set-favicon.php`. A missing or
            // unreadable file just falls back to the built-in defaults, so the
            // panel still renders if it is absent.
            $iconMeta = [];
            $iconJson = public_path('favicons/icon.json');
            if (is_file($iconJson) && is_readable($iconJson)) {
                $iconMeta = json_decode((string) @file_get_contents($iconJson), true) ?: [];
            }
            $iconColor = $iconMeta['maskColor'] ?? '#007bff';
            $themeColor = $iconMeta['themeColor'] ?? '#0e4688';
            // Cache-bust from the primary icon's mtime, so replacing the file is
            // enough — no rebuild and no hard refresh.
            $iconV = @filemtime(public_path('favicons/favicon-32x32.png')) ?: 1;
            $icon = function (string $file) use ($iconV) {
                return is_file(public_path('favicons/' . $file))
                    ? '/favicons/' . $file . '?v=' . $iconV
                    : null;
            };
        @endphp

        @section('meta')
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">
            @if($i = $icon('apple-touch-icon.png'))
                <link rel="apple-touch-icon" sizes="180x180" href="{{ $i }}">
            @endif
            @if($i = $icon('favicon-32x32.png'))
                <link rel="icon" type="image/png" sizes="32x32" href="{{ $i }}">
            @endif
            @if($i = $icon('favicon-16x16.png'))
                <link rel="icon" type="image/png" sizes="16x16" href="{{ $i }}">
            @endif
            @if(is_file(public_path('favicons/manifest.json')))
                <link rel="manifest" href="/favicons/manifest.json">
            @endif
            @if($i = $icon('safari-pinned-tab.svg'))
                <link rel="mask-icon" href="{{ $i }}" color="{{ $iconColor }}">
            @endif
            @if($i = $icon('favicon.ico'))
                <link rel="shortcut icon" href="{{ $i }}">
            @endif
            @if(is_file(public_path('favicons/browserconfig.xml')))
                <meta name="msapplication-config" content="/favicons/browserconfig.xml">
            @endif
            <meta name="theme-color" content="{{ $themeColor }}">
        @show

        {{-- Applies the saved theme to <html> before first paint so the panel never flashes the
             wrong palette. Kept inline and synchronous on purpose: an external or deferred script
             would run too late. Remove this block (and the `aternos-*` classes from base/core and
             auth/core) to go back to the stock dark theme.

             This is the migration point for the light -> blue rename, and the only
             file that still knows the old name. The light theme became blue, so
             both the stored value and the CSS class were renamed with it. A
             returning visitor can arrive with either still spelled the old way,
             and the class matters most: `aternos-theme` no longer matches any
             rule in the stylesheet, so leaving it on <html> would render the
             panel completely unthemed. So the old class is removed and the old
             stored value rewritten here, before first paint, rather than left
             for React to discover after a flash of broken styling. --}}
        {{--
            The admin-chosen accent colour, and the palette derived from it.

            Emitted as a <style> in the head rather than through React, for the
            same reason the background block below is: it has to be in place
            before first paint or the panel flashes the default blue.

            Selector specificity: `html.aternos-blue` / `html.aternos-dark`
            outranks the bare `.aternos-blue` / `.aternos-dark` blocks in the
            bundled stylesheet, so this inline value wins even though the bundle
            loads after it. Left as `:root`, specificity would tie and the
            bundle -- later in document order -- would win, and the admin's
            colour would silently never apply.

            Values come from ThemeColorService::cssVariables(), hex strings
            generated server-side from the stored colour, so nothing here can
            break out of the declaration block.
        --}}
        @if(!empty($siteConfiguration['colors']['custom']) && !empty($siteConfiguration['colors']['css']))
            <style>
                html.aternos-blue,
                html.aternos-dark {
                    @foreach($siteConfiguration['colors']['css']['shared'] as $name => $value)
                        {!! $name !!}: {!! $value !!};
                    @endforeach
                }
                html.aternos-blue {
                    @foreach($siteConfiguration['colors']['css']['blue'] as $name => $value)
                        {!! $name !!}: {!! $value !!};
                    @endforeach
                }
                html.aternos-dark {
                    @foreach($siteConfiguration['colors']['css']['dark'] as $name => $value)
                        {!! $name !!}: {!! $value !!};
                    @endforeach
                }
            </style>
        @endif

        {{--
            The optional background image.

            Emitted as a <style> in the head rather than applied by React, for one
            reason: it has to be in place before first paint. Setting it from the
            bundle would show the plain background for a moment on every page
            load, which is the same flash the theme script above exists to avoid.

            The scrim is a solid page-coloured layer at `dim` opacity over the
            image, so the image shows through without ever competing with the
            text: the page colour is what the text is drawn on either way, which
            keeps body contrast where it was with no image set. `dim` is how much
            of the panel colour is laid over the photo, so a higher value shows
            less of the image. MAX_DIM stops at 0.95 rather than 1 because at 1
            the operator's picture would be entirely hidden, which is not a
            setting worth offering as though it did anything.

            Nothing is emitted when no image is set, so the default panel keeps
            exactly the stylesheet it had.

            The background-image values below are echoed with {!! !!}, not {{ }}.
            Blade escapes an apostrophe to &#039;, and <style> is a raw-text
            element where entities are NOT decoded -- so an escaped url() is a
            broken url() and the image silently never appears. That is safe
            precisely because BackgroundService::url() only ever returns
            asset('backgrounds/') plus a 16-character content hash and an
            extension from a fixed allowlist; it shape-checks the stored name and
            returns null for anything else, so there is no quote or parenthesis
            here to break out of.
        --}}
        @if(!empty($siteConfiguration['background']['url']))
            @php
                $atBg = $siteConfiguration['background'];
                // One scrim per mode, because the page colour differs. A single
                // shared value would be right in one theme and visibly wrong in
                // the other.
                $atBgScrim = round(max(0.0, min(0.95, (float) $atBg['dim'])), 3);
                $atBgRepeat = $atBg['fit'] === 'tile';
                $atBgSize = match ($atBg['fit']) {
                    'cover' => 'cover',
                    'contain' => 'contain',
                    default => 'auto',
                };
                $atBgUrl = $atBg['url'];
                $atBgLayers = fn (string $rgb) => sprintf(
                    "linear-gradient(rgba(%s, %s), rgba(%s, %s)), url('%s')",
                    $rgb, $atBgScrim, $rgb, $atBgScrim, $atBgUrl
                );
            @endphp
            <style>
                .aternos-blue body {
                    background-image: {!! $atBgLayers(($siteConfiguration['colors']['pageRgb']['blue'] ?? config('theme.background_page.blue'))) !!};
                    background-repeat: {{ $atBgRepeat ? 'repeat' : 'no-repeat' }};
                    background-position: {{ $atBgRepeat ? 'left top' : 'center center' }};
                    background-size: {{ $atBgSize }};
                    background-attachment: fixed;
                }

                .aternos-dark body {
                    background-image: {!! $atBgLayers(($siteConfiguration['colors']['pageRgb']['dark'] ?? config('theme.background_page.dark'))) !!};
                    background-repeat: {{ $atBgRepeat ? 'repeat' : 'no-repeat' }};
                    background-position: {{ $atBgRepeat ? 'left top' : 'center center' }};
                    background-size: {{ $atBgSize }};
                    background-attachment: fixed;
                }
            </style>
        @endif

        {{--
            The authentication pages' own background.

            Emitted as custom properties rather than as a background rule on an
            element, and that is the whole design of this. The login screen is
            `.at-auth`, a full-viewport grid that lives inside React's #app, and
            assets/aternos.css paints an opaque `background: var(--at-page)` on it
            plus a hard-coded gradient on its left half. So the body background
            above is completely invisible there, and a rule here targeting body
            would be invisible for exactly the same reason.

            A custom property is the one thing that survives that: it is inherited,
            so setting it on body reaches .at-auth however deep React puts it, and
            the stylesheet decides what to do with it. assets/aternos.css reads
            --at-auth-bg with the page colour as the fallback, so with no image set
            the login screen looks exactly as it did.

            It also settles a specificity contest. This inline block sits in the
            head *before* the bundled stylesheet, so an `.at-auth {}` rule here
            would lose to `.aternos-blue .at-auth {}` from the bundle. Custom
            properties are not declarations that compete — the stylesheet keeps the
            only rule, and this block just supplies a value for it to read.

            --at-auth-aside is the same idea for the left-hand panel: translucent
            over the photo, and the existing opaque gradient when there is no photo.
            Without it the split screen would put a hard blue rectangle over half
            the image, which is the thing being replaced.

            The url is echoed with {!! !!}, for the reason given above: a <style> is
            a raw-text element, so an escaped apostrophe would be a broken url()
            rather than a visible entity. AuthBackgroundService::url() only ever
            returns asset() plus a 16-character content hash and an extension from a
            fixed allowlist, and shape-checks the stored name, so there is nothing
            here that could close the url() or the declaration.
        --}}
        @if(!empty($siteConfiguration['authBackground']['url']))
            @php
                $atAuth = $siteConfiguration['authBackground'];
                // Clamped to the same 0.95 ceiling as the panel background: at 1
                // the operator's picture would be entirely hidden, which is not a
                // setting worth offering as though it did anything.
                $atAuthScrim = round(max(0.0, min(0.95, (float) $atAuth['dim'])), 3);
                $atAuthLayers = fn (string $rgb) => sprintf(
                    "linear-gradient(rgba(%s, %s), rgba(%s, %s)), url('%s')",
                    $rgb, $atAuthScrim, $rgb, $atAuthScrim, $atAuth['url']
                );
                // Alpha rather than the page colour, because the page colour is
                // opaque and mixing it in at these opacities would paint straight
                // over the photo. These are the theme's own aside stops at 86-92%
                // alpha, which keeps the white headline and its 78%-white
                // subheading readable over a photograph without hiding it.
                $atAuthAside = 'linear-gradient(150deg, rgba(11,111,212,0.86) 0%, rgba(0,77,153,0.90) 55%, rgba(0,51,95,0.92) 100%)';
            @endphp
            <style>
                .aternos-blue body {
                    --at-auth-bg: {!! $atAuthLayers(($siteConfiguration['colors']['pageRgb']['blue'] ?? config('theme.background_page.blue'))) !!};
                    --at-auth-aside: {!! $atAuthAside !!};
                }

                .aternos-dark body {
                    --at-auth-bg: {!! $atAuthLayers(($siteConfiguration['colors']['pageRgb']['dark'] ?? config('theme.background_page.dark'))) !!};
                    --at-auth-aside: {!! $atAuthAside !!};
                }
            </style>
        @endif

        <script>
            (function () {
                var root = document.documentElement;
                var BLUE = 'aternos-blue';
                var DARK = 'aternos-dark';
                var LEGACY_CLASS = 'aternos-theme';
                var LEGACY_VALUE = 'light';

                var theme = 'blue';

                /*
                 * Per user, not per browser.
                 *
                 * One value in localStorage meant everyone who used the same
                 * machine shared one palette, so a subuser could not choose
                 * dark without also switching the owner over to it -- or rather,
                 * could only do it by being the last person to press the toggle.
                 * The key now carries the account id.
                 *
                 * Rendered here rather than in the bundle because this script has
                 * to run before first paint, and the bundle is too late. On a
                 * request with no session -- the login page -- it falls back to
                 * the old unscoped key, which is also what seeds a user's first
                 * visit so an existing choice is not lost.
                 *
                 * The account's uuid, not its numeric id, because that is what
                 * useTheme.ts has to hand: the two have to build the same string,
                 * and only one of them can ask the database.
                 */
                var KEY = @json(auth()->check() ? 'pterodactyl:theme:' . auth()->user()->uuid : 'pterodactyl:theme');

                try {
                    var stored = window.localStorage.getItem(KEY);

                    if (stored === null) {
                        /* No per-user value yet: adopt whatever this browser had
                           decided for everyone else, so the choice someone made
                           before this existed survives the upgrade. */
                        stored = window.localStorage.getItem('pterodactyl:theme');
                    }

                    if (stored === 'dark') {
                        theme = 'dark';
                    } else if (stored === LEGACY_VALUE) {
                        /* Pre-rename visitor: they were on light, which is now
                           blue. Rewritten below so the legacy spelling is gone
                           from storage entirely rather than lingering forever. */
                        theme = 'blue';
                    } else {
                        theme = 'blue';
                    }

                    if (stored !== null && stored !== theme) {
                        window.localStorage.setItem(KEY, theme);
                    }
                } catch (e) {
                    /* private mode / storage disabled — fall back to blue */
                }

                root.classList.remove(BLUE, DARK, LEGACY_CLASS);
                root.classList.add(theme === 'dark' ? DARK : BLUE);

                /*
                 * Sidebar collapse, read here rather than in React so the choice
                 * is applied before the first frame. Applied from the bundle it
                 * would render the sidebar at full width and then snap shut a
                 * moment later, on every load, for anyone who chose to collapse
                 * it -- which reads as a glitch rather than as their setting.
                 */
                try {
                    if (window.localStorage.getItem('pterodactyl:nav-collapsed') === '1') {
                        document.documentElement.classList.add('at-nav-collapsed');
                    }
                } catch (e) {
                    /* storage disabled — the sidebar just stays expanded */
                }
            })();
        </script>

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show

        @yield('assets')

        @include('layouts.scripts')
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>
