<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>{{ config('app.name', 'Pterodactyl') }} - @yield('title')</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="{{ csrf_token() }}">

        @php
            // Same icon metadata as templates/wrapper.blade.php, kept in step by
            // `php tools/set-favicon.php`. Falls back to defaults if absent.
            $iconMeta = [];
            $iconJson = public_path('favicons/icon.json');
            if (is_file($iconJson) && is_readable($iconJson)) {
                $iconMeta = json_decode((string) @file_get_contents($iconJson), true) ?: [];
            }
            $iconColor = $iconMeta['maskColor'] ?? '#007bff';
            $themeColor = $iconMeta['themeColor'] ?? '#0e4688';
            $iconV = @filemtime(public_path('favicons/favicon-32x32.png')) ?: 1;
            $icon = function (string $file) use ($iconV) {
                return is_file(public_path('favicons/' . $file))
                    ? '/favicons/' . $file . '?v=' . $iconV
                    : null;
            };
        @endphp

        @if($i = $icon('apple-touch-icon.png'))
            <link rel="apple-touch-icon" sizes="180x180" href="{{ $i }}">
        @endif
        @if($i = $icon('favicon-32x32.png'))
            <link rel="icon" type="image/png" sizes="32x32" href="{{ $i }}">
        @endif
        @if($i = $icon('favicon-16x16.png'))
            <link rel="icon" type="image/png" sizes="16x16" href="{{ $i }}">
        @endif
        @if(is_file(public_path('favicons/manifest.json')))
            <link rel="manifest" href="/favicons/manifest.json">
        @endif
        @if($i = $icon('safari-pinned-tab.svg'))
            <link rel="mask-icon" href="{{ $i }}" color="{{ $iconColor }}">
        @endif
        @if($i = $icon('favicon.ico'))
            <link rel="shortcut icon" href="{{ $i }}">
        @endif
        @if(is_file(public_path('favicons/browserconfig.xml')))
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        @endif
        <meta name="theme-color" content="{{ $themeColor }}">

        {{--
            The admin area uses AdminLTE, not the client bundle, so the theme's
            custom-property override in templates/wrapper.blade.php never reaches
            it. Recolour the AdminLTE "skin-blue" surfaces directly, but ONLY when
            the operator has customised them -- otherwise the admin area keeps its
            stock blue exactly, which is what an untouched theme should produce.
        --}}
        @php
            $atColors = app(\Pterodactyl\Services\Settings\ThemeColorService::class);
            $atCss = $atColors->cssVariables();
            $atSidebar = $atCss['shared']['--at-side-bg'] ?? null;
            $atSidebarText = $atCss['shared']['--at-side-text'] ?? null;
            $atPrimary = $atCss['shared']['--at-primary'] ?? null;
            $atPrimary600 = $atCss['shared']['--at-primary-600'] ?? null;
            $atNav = ($atColors->hasCustom() && in_array('nav', array_keys($atColors->customised()), true)) ? ($atCss['blue']['--at-nav-bg-blur'] ?? null) : null;
        @endphp
        @if($atSidebar || $atPrimary || $atNav)
            <style>
                @if($atNav)
                    .skin-blue .main-header .navbar { background-color: {{ $atNav }}; }
                    .skin-blue .main-header .logo { background-color: {{ $atNav }}; border-bottom-color: rgba(0,0,0,0.1); }
                @elseif($atPrimary)
                    .skin-blue .main-header .navbar { background-color: {{ $atPrimary }}; }
                    .skin-blue .main-header .logo { background-color: {{ $atPrimary600 }}; }
                @endif
                @if($atSidebarText)
                    .skin-blue .sidebar-menu a, .skin-blue .sidebar-menu .header { color: {{ $atSidebarText }} !important; }
                @endif
                @if($atSidebar || $atSidebarText)
                    .skin-blue .main-sidebar,
                    .skin-blue .left-side { background-color: {{ $atSidebar ?? '#1f2933' }}; }
                @endif
                @if($atPrimary)
                    .btn-primary { background-color: {{ $atPrimary }} !important; border-color: {{ $atPrimary600 }} !important; }
                    .btn-primary:hover, .btn-primary:active, .btn-primary:focus { background-color: {{ $atPrimary600 }} !important; border-color: {{ $atPrimary600 }} !important; }
                    .skin-blue .sidebar-menu > li.active > a { border-left-color: {{ $atPrimary }}; }
                    a { color: {{ $atPrimary }}; }
                @endif
            </style>
        @endif

        @include('layouts.scripts')

        @section('scripts')
            {!! Theme::css('vendor/select2/select2.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/admin.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/colors/skin-blue.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/animate/animate.min.css?t={cache-version}') !!}
            {!! Theme::css('css/pterodactyl.css?t={cache-version}') !!}
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        @show
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="{{ route('index') }}" class="logo">
                    <span>{{ config('app.name', 'Pterodactyl') }}</span>
                </a>
                <nav class="navbar navbar-static-top">
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="user-menu">
                                <a href="{{ route('account') }}">
                                    <img src="https://www.gravatar.com/avatar/{{ md5(strtolower(Auth::user()->email)) }}?s=160" class="user-image" alt="User Image">
                                    <span class="hidden-xs">{{ Auth::user()->name_first }} {{ Auth::user()->name_last }}</span>
                                </a>
                            </li>
                            <li>
                                <li><a href="{{ route('index') }}" data-toggle="tooltip" data-placement="bottom" title="Exit Admin Control"><i class="fa fa-server"></i></a></li>
                            </li>
                            <li>
                                <li><a href="{{ route('auth.logout') }}" id="logoutButton" data-toggle="tooltip" data-placement="bottom" title="Logout"><i class="fa fa-sign-out"></i></a></li>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
            <aside class="main-sidebar">
                <section class="sidebar">
                    <ul class="sidebar-menu">
                        <li class="header">BASIC ADMINISTRATION</li>
                        <li class="{{ Route::currentRouteName() !== 'admin.index' ?: 'active' }}">
                            <a href="{{ route('admin.index') }}">
                                <i class="fa fa-home"></i> <span>Overview</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.settings') ?: 'active' }}">
                            <a href="{{ route('admin.settings')}}">
                                <i class="fa fa-wrench"></i> <span>Settings</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.api') ?: 'active' }}">
                            <a href="{{ route('admin.api.index')}}">
                                <i class="fa fa-gamepad"></i> <span>Application API</span>
                            </a>
                        </li>
                        <li class="header">MANAGEMENT</li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.databases') ?: 'active' }}">
                            <a href="{{ route('admin.databases') }}">
                                <i class="fa fa-database"></i> <span>Databases</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.locations') ?: 'active' }}">
                            <a href="{{ route('admin.locations') }}">
                                <i class="fa fa-globe"></i> <span>Locations</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nodes') ?: 'active' }}">
                            <a href="{{ route('admin.nodes') }}">
                                <i class="fa fa-sitemap"></i> <span>Nodes</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.servers') ?: 'active' }}">
                            <a href="{{ route('admin.servers') }}">
                                <i class="fa fa-server"></i> <span>Servers</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.users') ?: 'active' }}">
                            <a href="{{ route('admin.users') }}">
                                <i class="fa fa-users"></i> <span>Users</span>
                            </a>
                        </li>
                        <li class="header">SERVICE MANAGEMENT</li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.mounts') ?: 'active' }}">
                            <a href="{{ route('admin.mounts') }}">
                                <i class="fa fa-magic"></i> <span>Mounts</span>
                            </a>
                        </li>
                        <li class="{{ ! starts_with(Route::currentRouteName(), 'admin.nests') ?: 'active' }}">
                            <a href="{{ route('admin.nests') }}">
                                <i class="fa fa-th-large"></i> <span>Nests</span>
                            </a>
                        </li>
                    </ul>
                </section>
            </aside>
            <div class="content-wrapper">
                <section class="content-header">
                    @yield('content-header')
                </section>
                <section class="content">
                    <div class="row">
                        <div class="col-xs-12">
                            @if (count($errors) > 0)
                                <div class="alert alert-danger">
                                    There was an error validating the data provided.<br><br>
                                    <ul>
                                        @foreach ($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                            @foreach (Alert::getMessages() as $type => $messages)
                                @foreach ($messages as $message)
                                    <div class="alert alert-{{ $type }} alert-dismissable" role="alert">
                                        {{ $message }}
                                    </div>
                                @endforeach
                            @endforeach
                        </div>
                    </div>
                    @yield('content')
                </section>
            </div>
            <footer class="main-footer">
                <div class="pull-right small text-gray" style="margin-right:10px;margin-top:-7px;">
                    <strong><i class="fa fa-fw {{ $appIsGit ? 'fa-git-square' : 'fa-code-fork' }}"></i></strong> {{ $appVersion }}<br />
                    <strong><i class="fa fa-fw fa-clock-o"></i></strong> {{ round(microtime(true) - LARAVEL_START, 3) }}s
                </div>
                @php
                    $atFooter = null;
                    $atFooterJson = public_path('branding/colors.json');
                    if (is_file($atFooterJson) && is_readable($atFooterJson)) {
                        $atFooterMeta = json_decode((string) @file_get_contents($atFooterJson), true);
                        $atFooter = is_array($atFooterMeta) && isset($atFooterMeta['footerText']) && trim((string) $atFooterMeta['footerText']) !== ''
                            ? trim((string) $atFooterMeta['footerText'])
                            : null;
                    }
                @endphp
                @if($atFooter)
                    {{ $atFooter }}
                @else
                    Copyright &copy; 2015 - {{ date('Y') }} <a href="https://pterodactyl.io/">Pterodactyl Software</a>.
                @endif
            </footer>
        </div>
        @section('footer-scripts')
            <script src="/js/keyboard.polyfill.js" type="application/javascript"></script>
            <script>keyboardeventKeyPolyfill.polyfill();</script>

            {!! Theme::js('vendor/jquery/jquery.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/slimscroll/jquery.slimscroll.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/adminlte/app.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/select2/select2.full.min.js?t={cache-version}') !!}
            {!! Theme::js('js/admin/functions.js?t={cache-version}') !!}
            <script src="/js/autocomplete.js" type="application/javascript"></script>

            @if(Auth::user()->root_admin)
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();

                        var that = this;
                        swal({
                            title: 'Do you want to log out?',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d9534f',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Log out'
                        }, function () {
                             $.ajax({
                                type: 'POST',
                                url: '{{ route('auth.logout') }}',
                                data: {
                                    _token: '{{ csrf_token() }}'
                                },complete: function () {
                                    window.location.href = '{{route('auth.login')}}';
                                }
                        });
                    });
                });
                </script>
            @endif

            <script>
                $(function () {
                    $('[data-toggle="tooltip"]').tooltip();
                })
            </script>
        @show
    </body>
</html>
