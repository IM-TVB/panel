#!/usr/bin/env bash
#
# Install the Aternos theme into a Pterodactyl Panel checkout.
#
#   ./install.sh /var/www/pterodactyl            # install, backing up nothing new
#   ./install.sh /var/www/pterodactyl --force    # overwrite, writing .bak copies
#   ./install.sh /var/www/pterodactyl --revert   # restore from the backup dir
#
# The panel files are root-owned in most setups, so this escalates with sudo
# when needed. Nothing is overwritten unless --force is passed, and every
# overwritten file gets a timestamped backup first.

set -euo pipefail

THEME_DIR_HINT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

PANEL_DIR=""
FORCE=0
REVERT=0
CHECK=0
SEAL=0
CLEAN_STRAY=0
VERBOSE=0
SHOW_VERSION=0

for arg in "$@"; do
    case "$arg" in
        --force) FORCE=1 ;;
        --revert) REVERT=1 ;;
        --check) CHECK=1 ;;
        --verbose) VERBOSE=1 ;;
        --clean-stray) CLEAN_STRAY=1 ;;
        --seal) SEAL=1 ;;
        --version) SHOW_VERSION=1 ;;
        -*) echo "Unknown flag: $arg" >&2; exit 1 ;;
        *) PANEL_DIR="$arg" ;;
    esac
done

# --version and --seal do not need a panel: the first reports what this package is,
# the second regenerates its checksums. Demanding a directory for them would make
# them awkward to call from a script or a package build.
if [[ "$SHOW_VERSION" -eq 1 ]]; then
    v='(unversioned)'
    [[ -f "$THEME_DIR_HINT/VERSION" ]] && v="$(cat "$THEME_DIR_HINT/VERSION")"
    echo "aternos-theme $v"
    exit 0
fi

if [[ "$SEAL" -eq 1 ]]; then
    "$THEME_DIR_HINT/seal.sh"
    exit $?
fi

if [[ -z "$PANEL_DIR" ]]; then
    cat >&2 <<'USAGE'
Usage: install.sh <panel-directory> [mode]

  (no mode)        install, skipping files that already match
  --force          install, overwriting and backing up anything that differs
  --check          verify the panel against this package; changes nothing
  --verbose        list every file, including the ones left alone
  --clean-stray    remove package-only directories left by a hand-extract
  --revert         restore the panel from the backup tree
  --seal           regenerate this package's CHECKSUMS
  --version        print the package version

Examples:
  install.sh /var/www/pterodactyl
  install.sh /var/www/pterodactyl --force
  install.sh /var/www/pterodactyl --check
  install.sh /var/www/pterodactyl --clean-stray   # only if --check says so
USAGE
    exit 1
fi

if [[ ! -d "$PANEL_DIR" ]]; then
    echo "Error: '$PANEL_DIR' is not a directory." >&2
    exit 1
fi

# Root of the backup tree.
#
# Outside the panel, so a panel reinstall or rsync cannot clobber it -- and, more
# importantly, outside the web tree. The previous default was
# /var/www/pterodactyl-aternos-backup, one directory above the document root, and
# that was luck rather than design: it 404'd only because this vhost's root is
# /var/www/pterodactyl/public rather than /var/www. Change the vhost, or add a
# second server block with root /var/www, and 634 pristine panel files -- including
# every stock file the theme replaced -- become world-readable over HTTP. Nothing
# in /var/www is served today; the point is not to depend on that.
#
# /var/backups is where panel-update.sh already writes, so every backup for a given
# panel ends up in one predictable place.
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/pterodactyl-theme}"
STAMP="$(date +%Y%m%d-%H%M%S)"

# Refuse a backup root that the web server would serve.
#
# Checked against the panel's own public/ directory, which is the document root on
# a standard Pterodactyl vhost. This cannot catch every possible misconfiguration
# -- the real document root is whatever nginx says it is -- but it catches the
# obvious one, and it catches it at install time rather than after a backup has
# quietly accumulated a few hundred files.
refuse_served_backup_root() {
    local docroot="$PANEL_DIR/public"
    local target="$BACKUP_ROOT"

    # Normalise both, so /var/www/x and /var/www/x/ and /var/www/x/../x all
    # compare equal. The parent is resolved first and its failure checked
    # directly: appending `$(basename ...)` after a failing `cd` inside one
    # substitution means the whole expression reports the status of basename,
    # which succeeds -- so `|| return 0` never fired and a bad backup root was
    # silently normalised into a mangled path.
    local parent
    parent="$(cd "$(dirname "$target")" 2>/dev/null && pwd)" || return 0
    target="$parent/$(basename "$target")"
    docroot="$(cd "$docroot" 2>/dev/null && pwd)" || return 0

    case "$target" in
        "$docroot"|"$docroot"/*)
            cat >&2 <<EOF
Error: BACKUP_ROOT is inside the panel's document root.

    BACKUP_ROOT = $BACKUP_ROOT
    document root = $docroot

Everything written there would be downloadable over HTTP. Pick somewhere else, for
example:

    BACKUP_ROOT=/var/backups/pterodactyl-theme $0 '$PANEL_DIR' --force
EOF
            exit 1
            ;;
    esac
}

# Before any mode runs, and before anything is written. Defined here rather than
# with the other helpers because bash needs it to exist before it is called, and
# the helpers all sit further down -- the first attempt defined it below the call
# and every run died with "command not found".
refuse_served_backup_root

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"


# Pick the escalation prefix only if we actually need it.
SUDO=""
if [[ ! -w "$PANEL_DIR" ]]; then
    if sudo -n true 2>/dev/null; then
        SUDO="sudo"
    else
        echo "Error: '$PANEL_DIR' is not writable and passwordless sudo is unavailable." >&2
        echo "Re-run as root, or copy the files manually (paths listed below)." >&2
        exit 1
    fi
fi

# file -> path inside the theme package
MANIFEST=(
    "tailwind.config.js|tailwind.config.js"
    "resources/scripts/assets/tailwind.css|assets/tailwind.css"
    "resources/scripts/assets/aternos.css|assets/aternos.css"
    "app/Http/Controllers/Admin/Settings/BackgroundController.php|app/Http/Controllers/Admin/Settings/BackgroundController.php"
    "app/Http/Controllers/Admin/Settings/AuthBackgroundController.php|app/Http/Controllers/Admin/Settings/AuthBackgroundController.php"
    "app/Http/Requests/Admin/Settings/UpdateAuthBackgroundRequest.php|app/Http/Requests/Admin/Settings/UpdateAuthBackgroundRequest.php"
    "app/Http/Requests/Admin/Settings/UpdateBackgroundRequest.php|app/Http/Requests/Admin/Settings/UpdateBackgroundRequest.php"
    "app/Services/Settings/BackgroundService.php|app/Services/Settings/BackgroundService.php"
    "app/Services/Settings/StoredBackground.php|app/Services/Settings/StoredBackground.php"
    "app/Services/Settings/AuthBackgroundService.php|app/Services/Settings/AuthBackgroundService.php"
    "app/Services/Settings/LogoService.php|app/Services/Settings/LogoService.php"
    "app/Services/Settings/UserAvatarService.php|app/Services/Settings/UserAvatarService.php"
    "app/Http/Requests/Api/Client/Account/UpdateAvatarRequest.php|app/Http/Requests/Api/Client/Account/UpdateAvatarRequest.php"
    "app/Http/Controllers/Api/Client/Account/AvatarController.php|app/Http/Controllers/Api/Client/Account/AvatarController.php"
    "app/Transformers/Api/Client/UserTransformer.php|app/Transformers/Api/Client/UserTransformer.php"
    "app/Http/Requests/Admin/Settings/UpdateLogoRequest.php|app/Http/Requests/Admin/Settings/UpdateLogoRequest.php"
    "app/Http/Controllers/Admin/Settings/LogoController.php|app/Http/Controllers/Admin/Settings/LogoController.php"
    "app/Services/Settings/ProbesImageUploads.php|app/Services/Settings/ProbesImageUploads.php"
    "app/Services/Settings/EggBannerService.php|app/Services/Settings/EggBannerService.php"
    "app/Transformers/Api/Client/ServerTransformer.php|app/Transformers/Api/Client/ServerTransformer.php"
    "app/Http/Controllers/Admin/Nests/EggController.php|app/Http/Controllers/Admin/Nests/EggController.php"
    "app/Http/ViewComposers/AssetComposer.php|app/Http/ViewComposers/AssetComposer.php"
    "app/Services/Settings/ThemeColorService.php|app/Services/Settings/ThemeColorService.php"
    "app/Http/Controllers/Admin/Settings/ColorsController.php|app/Http/Controllers/Admin/Settings/ColorsController.php"
    "app/Http/Controllers/Admin/Settings/AnnouncementController.php|app/Http/Controllers/Admin/Settings/AnnouncementController.php"
    "app/Services/Settings/AnnouncementService.php|app/Services/Settings/AnnouncementService.php"
    "config/theme.php|config/theme.php"
    "resources/scripts/components/NavigationBar.tsx|components/NavigationBar.tsx"
    "resources/scripts/components/FlashMessageRender.tsx|resources/scripts/components/FlashMessageRender.tsx"
    "resources/scripts/components/server/users/PermissionTitleBox.tsx|resources/scripts/components/server/users/PermissionTitleBox.tsx"
    "resources/scripts/components/server/users/EditSubuserModal.tsx|resources/scripts/components/server/users/EditSubuserModal.tsx"
    "resources/scripts/components/server/users/PermissionRow.tsx|resources/scripts/components/server/users/PermissionRow.tsx"
    "resources/scripts/components/server/users/UserRow.tsx|resources/scripts/components/server/users/UserRow.tsx"
    "resources/scripts/components/server/users/UsersContainer.tsx|resources/scripts/components/server/users/UsersContainer.tsx"
    "resources/scripts/users-permissions.test.ts|resources/scripts/users-permissions.test.ts"
    "resources/scripts/modal-theming.test.ts|resources/scripts/modal-theming.test.ts"
    "resources/scripts/server-url.test.ts|resources/scripts/server-url.test.ts"
    "resources/scripts/activity-avatar.test.ts|resources/scripts/activity-avatar.test.ts"
    "resources/scripts/account-modern.test.ts|resources/scripts/account-modern.test.ts"
    "resources/scripts/main-area-type.test.ts|resources/scripts/main-area-type.test.ts"
    "resources/scripts/components/dashboard/ServerRow.tsx|components/dashboard/ServerRow.tsx"
    "resources/scripts/components/dashboard/DashboardContainer.tsx|components/dashboard/DashboardContainer.tsx"
    "resources/scripts/components/dashboard/AccountOverviewContainer.tsx|components/dashboard/AccountOverviewContainer.tsx"
    "resources/scripts/components/auth/LoginFormContainer.tsx|components/auth/LoginFormContainer.tsx"
    "resources/scripts/plugins/useTheme.ts|plugins/useTheme.ts"
    "resources/scripts/plugins/useCollapsibleNav.ts|plugins/useCollapsibleNav.ts"
    "resources/scripts/plugins/useServerPlatform.ts|plugins/useServerPlatform.ts"
    "resources/scripts/routers/DashboardRouter.tsx|routers/DashboardRouter.tsx"
    "resources/scripts/routers/ServerRouter.tsx|routers/ServerRouter.tsx"
    "resources/scripts/routers/AuthenticationRouter.tsx|routers/AuthenticationRouter.tsx"
    "resources/scripts/routers/routes.ts|resources/scripts/routers/routes.ts"
    "resources/scripts/api/server/plugins/modrinth.ts|resources/scripts/api/server/plugins/modrinth.ts"
    "resources/scripts/api/server/plugins/install.ts|resources/scripts/api/server/plugins/install.ts"
    "resources/scripts/api/server/software.ts|resources/scripts/api/server/software.ts"
    "resources/scripts/api/server/plugins/versions.ts|resources/scripts/api/server/plugins/versions.ts"
    "resources/scripts/components/server/settings/SettingsContainer.tsx|resources/scripts/components/server/settings/SettingsContainer.tsx"
    "resources/scripts/api/server/plugins/spiget.ts|resources/scripts/api/server/plugins/spiget.ts"
    "resources/scripts/api/server/plugins/spigetFilename.ts|resources/scripts/api/server/plugins/spigetFilename.ts"
    "resources/scripts/api/server/plugins/panelFallback.ts|resources/scripts/api/server/plugins/panelFallback.ts"
    "resources/scripts/api/server/plugins/addonKey.ts|resources/scripts/api/server/plugins/addonKey.ts"
    "resources/scripts/api/server/plugins/providers.ts|resources/scripts/api/server/plugins/providers.ts"
    "resources/scripts/api/server/plugins/blob.ts|resources/scripts/api/server/plugins/blob.ts"
    "resources/scripts/api/server/plugins/hangar.ts|resources/scripts/api/server/plugins/hangar.ts"
    "resources/scripts/api/server/plugins/curseforge.ts|resources/scripts/api/server/plugins/curseforge.ts"
    "resources/scripts/api/server/plugins/providerKeys.ts|resources/scripts/api/server/plugins/providerKeys.ts"
    "resources/scripts/plugins/useAddonCounts.ts|resources/scripts/plugins/useAddonCounts.ts"
    "resources/scripts/components/server/plugins/VersionGrid.tsx|resources/scripts/components/server/plugins/VersionGrid.tsx"
    "resources/scripts/components/server/plugins/SoftwarePicker.tsx|resources/scripts/components/server/plugins/SoftwarePicker.tsx"
    # Regression tests only; never bundled (nothing imports them).
    "resources/scripts/jsx-react-import.test.ts|resources/scripts/jsx-react-import.test.ts"
    "resources/scripts/components/server/plugins/SoftwarePicker.structure.test.ts|resources/scripts/components/server/plugins/SoftwarePicker.structure.test.ts"
    "resources/scripts/fetch-headers.test.ts|resources/scripts/fetch-headers.test.ts"
    "resources/scripts/provider-contract.test.ts|resources/scripts/provider-contract.test.ts"
    "resources/scripts/addon-sort.test.ts|resources/scripts/addon-sort.test.ts"
    "resources/scripts/spigot-filename.test.ts|resources/scripts/spigot-filename.test.ts"
    "resources/scripts/panel-fallback.test.ts|resources/scripts/panel-fallback.test.ts"
    "resources/scripts/addon-key.test.ts|resources/scripts/addon-key.test.ts"
    "resources/scripts/loader-filter.test.ts|resources/scripts/loader-filter.test.ts"
    "resources/scripts/light-mode-contrast.test.ts|resources/scripts/light-mode-contrast.test.ts"
    "resources/scripts/sidebar-always-dark.test.ts|resources/scripts/sidebar-always-dark.test.ts"
    "resources/scripts/theme-rename.test.ts|resources/scripts/theme-rename.test.ts"
    "resources/scripts/file-list.test.ts|resources/scripts/file-list.test.ts"
    "resources/scripts/background-image.test.ts|resources/scripts/background-image.test.ts"
    "resources/scripts/auth-background.test.ts|resources/scripts/auth-background.test.ts"
    "resources/scripts/egg-banner.test.ts|resources/scripts/egg-banner.test.ts"
    "resources/scripts/collapsible-nav.test.ts|resources/scripts/collapsible-nav.test.ts"
    "resources/scripts/addon-versions.test.ts|resources/scripts/addon-versions.test.ts"
    "resources/scripts/addon-version-fit.test.ts|resources/scripts/addon-version-fit.test.ts"
    "resources/scripts/addon-version-live.test.ts|resources/scripts/addon-version-live.test.ts"
    "resources/scripts/provider-failures.test.ts|resources/scripts/provider-failures.test.ts"
    "resources/scripts/sort-relevance.test.ts|resources/scripts/sort-relevance.test.ts"
    "resources/scripts/jvm-flags-ui.test.ts|resources/scripts/jvm-flags-ui.test.ts"
    "resources/scripts/logo-ui.test.ts|resources/scripts/logo-ui.test.ts"
    "resources/scripts/avatar-upload.test.ts|resources/scripts/avatar-upload.test.ts"
    "resources/scripts/api/server/getServer.ts|resources/scripts/api/server/getServer.ts"
    "resources/scripts/plugins/loaders.ts|resources/scripts/plugins/loaders.ts"
    "resources/scripts/components/server/console/style.module.css|resources/scripts/components/server/console/style.module.css"
    "resources/scripts/components/server/files/style.module.css|resources/scripts/components/server/files/style.module.css"
    "resources/scripts/components/server/plugins/PluginsContainer.stability.test.ts|resources/scripts/components/server/plugins/PluginsContainer.stability.test.ts"
    "resources/scripts/components/server/plugins/PluginsContainer.tsx|resources/scripts/components/server/plugins/PluginsContainer.tsx"
    "resources/scripts/api/server/jvmFlags.ts|resources/scripts/api/server/jvmFlags.ts"
    "resources/scripts/components/server/startup/JvmFlags.tsx|resources/scripts/components/server/startup/JvmFlags.tsx"
    "resources/scripts/components/server/plugins/AddOnVersions.tsx|resources/scripts/components/server/plugins/AddOnVersions.tsx"
    "resources/scripts/components/server/console/InstalledAddons.tsx|resources/scripts/components/server/console/InstalledAddons.tsx"
    "resources/scripts/components/server/console/ServerConsoleContainer.tsx|resources/scripts/components/server/console/ServerConsoleContainer.tsx"
    "resources/scripts/components/server/console/ServerDetailsBlock.tsx|resources/scripts/components/server/console/ServerDetailsBlock.tsx"
    "resources/scripts/components/server/console/MobileServerSummary.tsx|resources/scripts/components/server/console/MobileServerSummary.tsx"
    "resources/scripts/components/server/startup/StartupContainer.tsx|resources/scripts/components/server/startup/StartupContainer.tsx"
    "resources/scripts/components/server/software/SoftwareContainer.tsx|resources/scripts/components/server/software/SoftwareContainer.tsx"
    "resources/scripts/components/server/SidebarPowerControls.tsx|resources/scripts/components/server/SidebarPowerControls.tsx"
    "app/Models/Permission.php|app/Models/Permission.php"
    "resources/scripts/state/settings.ts|resources/scripts/state/settings.ts"
    "app/Models/User.php|app/Models/User.php"
    "resources/scripts/api/definitions/user/transformers.ts|resources/scripts/api/definitions/user/transformers.ts"
    "resources/scripts/state/user.ts|resources/scripts/state/user.ts"
    "resources/scripts/components/App.tsx|resources/scripts/components/App.tsx"
    "resources/scripts/components/Avatar.tsx|resources/scripts/components/Avatar.tsx"
    "resources/scripts/api/definitions/user/models.d.ts|resources/scripts/api/definitions/user/models.d.ts"
    "resources/scripts/components/dashboard/forms/UpdateAvatarForm.tsx|resources/scripts/components/dashboard/forms/UpdateAvatarForm.tsx"
    "resources/scripts/api/user/avatar.ts|resources/scripts/api/user/avatar.ts"
    "resources/views/templates/base/core.blade.php|views/templates/base/core.blade.php"
    "resources/views/templates/auth/core.blade.php|views/templates/auth/core.blade.php"
    "resources/views/templates/wrapper.blade.php|views/templates/wrapper.blade.php"
    "resources/views/layouts/admin.blade.php|views/layouts/admin.blade.php"
    "resources/scripts/components/elements/PageContentBlock.tsx|components/elements/PageContentBlock.tsx"
    "resources/scripts/components/elements/Modal.tsx|components/elements/Modal.tsx"
    "resources/scripts/components/elements/ContentBox.tsx|components/elements/ContentBox.tsx"
    "resources/scripts/components/elements/ContentContainer.tsx|components/elements/ContentContainer.tsx"
    "resources/scripts/components/elements/activity/ActivityLogEntry.tsx|resources/scripts/components/elements/activity/ActivityLogEntry.tsx"
    "resources/views/admin/settings/branding.blade.php|resources/views/admin/settings/branding.blade.php"
    "resources/views/admin/settings/background.blade.php|resources/views/admin/settings/background.blade.php"
    "resources/views/admin/settings/logo.blade.php|resources/views/admin/settings/logo.blade.php"
    "resources/views/admin/settings/colors.blade.php|resources/views/admin/settings/colors.blade.php"
    "resources/views/admin/settings/announcement.blade.php|resources/views/admin/settings/announcement.blade.php"
    "resources/views/admin/eggs/view.blade.php|resources/views/admin/eggs/view.blade.php"
    "resources/views/partials/admin/settings/nav.blade.php|resources/views/partials/admin/settings/nav.blade.php"
    "routes/admin.php|routes/admin.php"
    "routes/api-client.php|routes/api-client.php"
    "app/Services/Plugins/ProviderKeyService.php|app/Services/Plugins/ProviderKeyService.php"
    "app/Services/Plugins/KeyedProviderProxy.php|app/Services/Plugins/KeyedProviderProxy.php"
    "app/Services/Plugins/PublicProviderProxy.php|app/Services/Plugins/PublicProviderProxy.php"
    "app/Http/Controllers/Admin/Plugins/ProviderController.php|app/Http/Controllers/Admin/Plugins/ProviderController.php"
    "app/Http/Requests/Admin/Plugins/UpdateProviderKeyRequest.php|app/Http/Requests/Admin/Plugins/UpdateProviderKeyRequest.php"
    "app/Http/Controllers/Api/Client/KeyedProviderController.php|app/Http/Controllers/Api/Client/KeyedProviderController.php"
    "app/Http/Controllers/Api/Client/PublicProviderController.php|app/Http/Controllers/Api/Client/PublicProviderController.php"
    "resources/views/admin/plugins/providers.blade.php|resources/views/admin/plugins/providers.blade.php"
    "app/Http/Controllers/Api/Client/ProviderController.php|app/Http/Controllers/Api/Client/ProviderController.php"
    "app/Services/Settings/FaviconService.php|app/Services/Settings/FaviconService.php"
    "app/Http/Controllers/Admin/Settings/BrandingController.php|app/Http/Controllers/Admin/Settings/BrandingController.php"
    "app/Http/Requests/Admin/Settings/UpdateBrandingRequest.php|app/Http/Requests/Admin/Settings/UpdateBrandingRequest.php"
    "app/Events/Auth/FailedCaptcha.php|app/Events/Auth/FailedCaptcha.php"
    "app/Services/Servers/SoftwareService.php|app/Services/Servers/SoftwareService.php"
    "app/Http/Controllers/Api/Client/Servers/SoftwareController.php|app/Http/Controllers/Api/Client/Servers/SoftwareController.php"
    "app/Http/Requests/Api/Client/Servers/ChangeSoftwareRequest.php|app/Http/Requests/Api/Client/Servers/ChangeSoftwareRequest.php"
    "app/Services/Servers/ReinstallServerService.php|app/Services/Servers/ReinstallServerService.php"
    "app/Services/Servers/JvmFlagsService.php|app/Services/Servers/JvmFlagsService.php"
    "app/Http/Controllers/Api/Client/Servers/JvmFlagsController.php|app/Http/Controllers/Api/Client/Servers/JvmFlagsController.php"
    "app/Http/Requests/Api/Client/Servers/UpdateJvmFlagsRequest.php|app/Http/Requests/Api/Client/Servers/UpdateJvmFlagsRequest.php"
    "app/Http/Requests/Api/Client/Servers/Startup/GetJvmFlagsRequest.php|app/Http/Requests/Api/Client/Servers/Startup/GetJvmFlagsRequest.php"
    "app/Repositories/Wings/DaemonServerRepository.php|app/Repositories/Wings/DaemonServerRepository.php"
    "tools/set-favicon.php|tools/set-favicon.php"
    "tools/add-leaf-egg.php|tools/add-leaf-egg.php"
    "tools/set-provider-key.php|tools/set-provider-key.php"
    "tools/check-auth-overflow.sh|tools/check-auth-overflow.sh"
    "tools/test-background.php|tools/test-background.php"
)

# Top-level directories the package uses that a Pterodactyl panel does not have.
#
# Derived from the manifest, not hardcoded: for every entry whose package path
# differs from its destination, the first component of the package path is a
# package-only directory. Deriving it means a future entry with a new shortened
# prefix is covered without editing a list.
#
# This exists because of the most obvious mistake someone can make with this
# package. Extracting the tarball over a panel root -- rather than running
# install.sh -- puts 127 of the 145 files in the right place and the other 18,
# including the entire stylesheet, into directories the panel has never heard of:
# assets/, components/, plugins/, routers/, views/. Nothing errors. The panel
# boots and serves an unthemed page, because the stylesheet went to
# ./assets/ instead of ./resources/scripts/assets/.
package_only_dirs() {
    local rel src top
    while IFS='|' read -r rel src; do
        [[ "$rel" == "$src" ]] && continue
        top="${src%%/*}"
        [[ "$top" == "$src" ]] && continue
        printf '%s\n' "$top"
    done < <(printf '%s\n' "${MANIFEST[@]}")
}

# Report any of them sitting in the panel. Returns the count on stdout.
stray_package_dirs() {
    local top n=0
    while IFS= read -r top; do
        [[ -z "$top" ]] && continue
        if [[ -d "$PANEL_DIR/$top" ]]; then
            echo "$top"
            n=$((n + 1))
        fi
    done < <(package_only_dirs | sort -u)
}


banner() { printf '\n\033[1m%s\033[0m\n' "$1"; }
warn()   { printf '    \033[1;33m%s\033[0m\n' "$1"; }

# ------------------------------------------------------------------ check ----
#
# Verify the panel against this package. Changes nothing; exits non-zero if
# anything is wrong, so it can gate an update.
#
# This is the mode that matters after a Pterodactyl update. An update replaces
# every stock file the theme edited -- AssetComposer, the settings interface, the
# dashboard container -- while leaving the theme's own new files in place, so the
# result is a panel that boots and looks half-themed rather than one that visibly
# failed. The theme's own test suites do not catch that either, because most of
# them assert on the theme's files, which survived.
#
# Two things are verified, in this order:
#
#   1. The PACKAGE. Comparing the panel against a tampered package would report a
#      tampered panel as healthy, so the checksums are verified before anything
#      is compared, and a mismatch stops the check rather than warning.
#   2. The PANEL, file by file against the package: matching, missing, or altered.
if [[ "$CHECK" -eq 1 ]]; then
    banner "Checking $PANEL_DIR against $(cat "$THEME_DIR/VERSION" 2>/dev/null || echo 'an unversioned package')"

    if [[ ! -f "$THEME_DIR/CHECKSUMS" ]]; then
        echo "Error: no CHECKSUMS in the package." >&2
        echo "       Run ./seal.sh to create one, or get a sealed release." >&2
        exit 2
    fi

    # --- 0. did someone extract the tarball over the panel instead of running
    #        this? Checked first, because the file comparison's MISSING list is a
    #        thoroughly confusing way to find out.
    stray="$(stray_package_dirs)"
    if [[ -n "$stray" ]]; then
        printf '\n\033[1;31m  This looks like the tarball was EXTRACTED over the panel.\033[0m\n'
        echo "  Found package-only directories in $PANEL_DIR:"
        printf '%s\n' "$stray" | sed 's/^/    /'
        echo
        echo "  The package is not a drop-in overlay. 18 of its 145 files use shorter"
        echo "  internal paths -- assets/aternos.css is the theme stylesheet and it"
        echo "  belongs at resources/scripts/assets/aternos.css. Extracting puts it in"
        echo "  the wrong place, with no error: the panel boots and looks unthemed."
        echo
        echo "  To fix it, in two steps:"
        echo "    $0 '$PANEL_DIR' --clean-stray    # removes the directories listed above"
        echo "    $0 '$PANEL_DIR' --force         # puts the theme where it belongs"
        echo
        echo "  --clean-stray only removes directories that this manifest proves are"
        echo "  package-only -- a stock panel has none of them. If you have put"
        echo "  something of your own inside one of them, move it out first; the"
        echo "  command will not ask."
        echo
        exit 3
    fi

    # --- 1. the package
    if ! (cd "$THEME_DIR" && sha256sum -c --quiet CHECKSUMS); then
        echo >&2
        echo "Error: the PACKAGE does not match its own checksums." >&2
        echo "       Refusing to compare the panel against it -- a tampered package" >&2
        echo "       would report a tampered panel as healthy." >&2
        exit 2
    fi
    echo "  package: $(wc -l < "$THEME_DIR/CHECKSUMS") files verified"

    # --- 2. the panel
    ok=0
    missing=0
    altered=0

    while IFS='|' read -r rel src; do
        deployed="$PANEL_DIR/$rel"
        want="$THEME_DIR/$src"

        if [[ ! -f "$deployed" ]]; then
            echo "  MISSING  $rel"
            missing=$((missing + 1))
        elif cmp -s "$want" "$deployed"; then
            ok=$((ok + 1))
        else
            echo "  ALTERED  $rel"
            altered=$((altered + 1))
        fi
    done < <(printf '%s\n' "${MANIFEST[@]}")

    # A .bak sitting next to a file that currently matches is not a problem; one
    # next to an altered file is the evidence of what the alteration was, so it is
    # worth pointing at.
    orphans=0
    while IFS='|' read -r rel _; do
        if [[ -f "$PANEL_DIR/$rel.bak" && ! -f "$BACKUP_ROOT/$rel" ]]; then
            orphans=$((orphans + 1))
        fi
    done < <(printf '%s\n' "${MANIFEST[@]}")

    echo
    echo "  $ok matching, $altered altered, $missing missing, of ${#MANIFEST[@]} files"

    if [[ "$orphans" -gt 0 ]]; then
        echo "  $orphans .bak file(s) beside a theme file. Harmless on their own --"
        echo "  they are the pre-theme copies. --revert restores from $BACKUP_ROOT."
    fi

    if [[ "$altered" -gt 0 || "$missing" -gt 0 ]]; then
        echo
        echo "  To put the theme back:"
        echo "    $0 '$PANEL_DIR' --force && cd '$PANEL_DIR' && yarn build:production"
        echo
        echo "  --force rewrites every file above from the package and backs up what it"
        echo "  replaces, so this is safe to run on a panel that is mid-update."
        exit 1
    fi

    echo "  The theme is intact. Nothing to do."
    exit 0
fi

# -------------------------------------------------------------- clean-stray ---
#
# Remove the directories a hand-extract of this package leaves in a panel root.
#
# Deliberately not automatic and deliberately not a printed command. It deletes
# directories, and the one situation where that is wrong is a panel where somebody
# has put their own files into ./assets or ./views -- both plausible names for a
# person's own work, and neither created by a stock panel. So this mode exists, is
# named on the command line, and says what it is about to do.
if [[ "$CLEAN_STRAY" -eq 1 ]]; then
    stray="$(stray_package_dirs)"

    if [[ -z "$stray" ]]; then
        banner "Nothing to clean in $PANEL_DIR"
        exit 0
    fi

    banner "About to remove from $PANEL_DIR"
    printf '%s\n' "$stray" | while IFS= read -r top; do
        printf '    %-14s %s file(s)\n' "$top/" "$(find "$PANEL_DIR/$top" -type f 2>/dev/null | wc -l)"
    done
    echo
    read -r -p "  Remove these directories? [y/N] " reply
    if [[ "$reply" != "y" && "$reply" != "Y" ]]; then
        echo "  left alone"
        exit 0
    fi

    printf '%s\n' "$stray" | while IFS= read -r top; do
        $SUDO rm -rf "${PANEL_DIR:?}/$top"
        echo "    removed $top/"
    done

    echo
    echo "  Now: $0 '$PANEL_DIR' --force"
    exit 0
fi

# ---------------------------------------------------------------- revert ----
if [[ "$REVERT" -eq 1 ]]; then
    if [[ ! -d "$BACKUP_ROOT" ]]; then
        echo "Error: no backup tree at '$BACKUP_ROOT'." >&2
        exit 1
    fi
    banner "Restoring from $BACKUP_ROOT"
    restored=0
    while IFS='|' read -r rel _; do
        src="$BACKUP_ROOT/$rel"
        if [[ -f "$src" ]]; then
            $SUDO cp -a "$src" "$PANEL_DIR/$rel"
            echo "  restored: $rel"
            restored=$((restored + 1))
        else
            echo "  no backup: $rel"
        fi
    done < <(printf '%s\n' "${MANIFEST[@]}")
    echo
    echo "Restored $restored file(s). Rebuild assets to apply:"
    echo "    cd $PANEL_DIR && yarn build:production"
    exit 0
fi

# ---------------------------------------------------------------- verify ----
if [[ ! -f "$PANEL_DIR/composer.json" ]]; then
    echo "Warning: no composer.json in '$PANEL_DIR' — does not look like a panel root." >&2
    read -r -p "Continue anyway? [y/N] " reply
    [[ "$reply" == "y" ]] || exit 1
fi

# ---------------------------------------------------------------- install ---
banner "Installing Aternos theme into $PANEL_DIR"

# Sanity-check that the source files we depend on still look like what we
# targeted, so a future upstream bump fails loudly instead of silently
# producing a broken dashboard.
if [[ -f "$PANEL_DIR/resources/scripts/components/dashboard/ServerRow.tsx" ]]; then
    if ! grep -q "GreyRowBox\|at-server-card" "$PANEL_DIR/resources/scripts/components/dashboard/ServerRow.tsx"; then
        echo "Warning: ServerRow.tsx does not match the expected upstream shape." >&2
        echo "         The replacement DashboardContainer/ServerRow may not compile." >&2
    fi
fi

installed=0
skipped=0

while IFS='|' read -r rel src; do
    src_path="$THEME_DIR/$src"
    dest="$PANEL_DIR/$rel"

    if [[ ! -f "$src_path" ]]; then
        echo "  MISSING SOURCE: $src" >&2
        exit 1
    fi

    $SUDO mkdir -p "$(dirname "$dest")"

    if [[ -f "$dest" ]]; then
        # Skip identical files so re-running is a no-op.
        if cmp -s "$src_path" "$dest"; then
            # "unchanged", not "current" -- and quiet unless asked. One line per
            # skipped file is 133 lines on a full install, which buries the summary
            # for whoever is reading it through a pipe.
            [[ "$VERBOSE" -eq 1 ]] && echo "  unchanged: $rel"
            skipped=$((skipped + 1))
            continue
        fi
        if [[ "$FORCE" -eq 0 ]]; then
            echo "  exists:  $rel  (use --force to overwrite)"
            skipped=$((skipped + 1))
            continue
        fi
        # WRITE-ONCE backup. Re-running --force must never clobber the
        # pristine copy, otherwise --revert would restore the theme instead of
        # stock upstream. A timestamped snapshot of the current state is still
        # taken, but only the first backup is the revert source.
        $SUDO mkdir -p "$BACKUP_ROOT/$(dirname "$rel")"
        if [[ -f "$BACKUP_ROOT/$rel" ]]; then
            $SUDO cp -a "$dest" "$BACKUP_ROOT/$rel.$STAMP"
            echo "  write:   $rel  (pristine backup kept, snapshot -> $rel.$STAMP)"
        else
            $SUDO cp -a "$dest" "$BACKUP_ROOT/$rel"
            echo "  backup:  $rel  (pristine)"
        fi
    fi

    $SUDO cp "$src_path" "$dest"
    echo "  write:   $rel"
    installed=$((installed + 1))
done < <(printf '%s\n' "${MANIFEST[@]}")

banner "Done: $installed written, $skipped left alone"
echo "Backups: $BACKUP_ROOT (revert with: $0 $PANEL_DIR --revert)"

# Conditional, because the previous version of this block was a fixed sentence
# claiming node_modules was not present -- on a host where it is 568 MB. Nobody
# reading it had a way to tell it was not a check.
if [[ ! -d "$PANEL_DIR/node_modules" ]]; then
    warn "node_modules is not present, so the client build will need yarn install first."
    warn "That is what setup.sh does for you; running install.sh on its own means doing it by hand."
else
    echo
    echo "node_modules is present. To apply this to the browser:"
fi

cat <<'EOF'

    cd <panel-dir>
    yarn build:production
    php artisan view:clear

Then hard-refresh (Ctrl+Shift+R) - the stylesheet is bundled, not live-linked, so
a cached copy shows the old page however fresh the server is.

Or just run ./setup.sh, which finds the panel, does all of the above, and verifies
the result.
EOF
