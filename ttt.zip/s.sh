#!/usr/bin/env bash
# Ad-hoc bootstrap for a fresh dev box: node 22, php, composer, yarn.
set -euo pipefail
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs php-cli php-mysql php-mbstring php-xml php-curl php-zip php-gd php-bcmath
sudo corepack enable && sudo corepack prepare yarn@1.22.22 --activate   # provides yarn
curl -sS https://getcomposer.org/installer | php | sudo mv composer.phar /usr/local/bin/composer
