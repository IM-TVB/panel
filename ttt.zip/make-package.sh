#!/usr/bin/env bash
#
# Build the distributable: a sealed, checksummed tarball of the theme package.
#
#   ./make-package.sh              # version from ./VERSION
#   ./make-package.sh 1.1.0        # stamp a version first
#   ./make-package.sh --out /tmp   # somewhere other than ./dist
#
# The result is one file plus one .sha256, which is the shape people expect of an
# official release and the shape that survives being emailed, uploaded, or put on
# a static host. It is a `tar.gz` rather than a zip because every target is a unix
# box and the file modes in it matter -- install.sh and seal.sh are executable in
# the source tree and must stay executable in the archive, or the first thing
# someone does after extracting fails with "permission denied".
#
# It seals before archiving. A package whose CHECKSUMS were generated before the
# last edit verifies fine on the build machine and fails for everyone who
# downloads it, which is the worst possible time to find out.

set -euo pipefail

THEME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$THEME_DIR"

VERSION_ARG=""
OUT_DIR="$THEME_DIR/dist"

while [[ $# -gt 0 ]]; do
    case "$1" in
        --out)
            # ${2:-} and an explicit check: with set -u a bare `--out` at the
            # end of the line aborted with "unbound variable" instead of the
            # usage message the other bad arguments get.
            [[ "${2:-}" != '' && "${2:--}" != -* ]] || { echo "Error: --out needs a directory." >&2; exit 1; }
            OUT_DIR="$2"; shift 2 ;;
        -*) echo "Unknown flag: $1" >&2; exit 1 ;;
        *) VERSION_ARG="$1"; shift ;;
    esac
done

if [[ -n "$VERSION_ARG" ]]; then
    ./seal.sh "$VERSION_ARG"
else
    ./seal.sh
fi

VERSION="$(cat VERSION)"
NAME="pterodactyl-aternos-theme-${VERSION}"
TARBALL="$OUT_DIR/${NAME}.tar.gz"

mkdir -p "$OUT_DIR"

# The archive contains one top-level directory, so extracting it cannot scatter
# the package's files into whatever directory the user happened to be in.
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/$NAME"

# Everything the installer needs, and nothing that is not part of the theme:
# no dist/, no .git, no editor droppings, no stray backups.
#
# node_modules/ goes too: it holds a copy of yarn that no script in here calls
# (they use the panel's own node_modules, or whatever corepack provides), so it
# is dead weight in every download. It stays in the source tree, where it is
# only a convenience.
tar -cf - \
    --exclude='./dist' \
    --exclude='./node_modules' \
    --exclude='./.git' \
    --exclude='./.gitignore' \
    --exclude='*.swp' \
    --exclude='*~' \
    --exclude='.DS_Store' \
    . | tar -xf - -C "$STAGE/$NAME"

# The checksum file must describe the ARCHIVE's contents, and the archive's
# contents are the staged copy, so it is regenerated there rather than copied.
( cd "$STAGE/$NAME" && ./seal.sh "$VERSION" >/dev/null )

# Prove the staged copy is self-consistent before it is packed. A package that
# cannot verify itself should not ship.
( cd "$STAGE/$NAME" && sha256sum -c --quiet CHECKSUMS ) \
    || { echo "Error: the staged package fails its own checksums." >&2; exit 1; }

tar -czf "$TARBALL" -C "$STAGE" "$NAME"

# And prove the archive is whole, by unpacking it somewhere else entirely and
# checking it there. This is the only test that covers the tar layer.
VERIFY="$(mktemp -d)"
trap 'rm -rf "$STAGE" "$VERIFY"' EXIT
tar -xzf "$TARBALL" -C "$VERIFY"
( cd "$VERIFY/$NAME" && sha256sum -c --quiet CHECKSUMS ) \
    || { echo "Error: the archive does not verify after extraction." >&2; exit 1; }

# Executable bits, which is the thing a tarball gets wrong and which is
# discovered only after extraction.
for f in install.sh seal.sh panel-update.sh; do
    [[ -x "$VERIFY/$NAME/$f" ]] || { echo "Error: $f is not executable in the archive." >&2; exit 1; }
done

( cd "$OUT_DIR" && sha256sum "$(basename "$TARBALL")" > "$(basename "$TARBALL").sha256" )

printf '\n\033[1mBuilt %s\033[0m\n' "$TARBALL"
printf '  %s files, %s unpacked\n' \
    "$(wc -l < "$STAGE/$NAME/CHECKSUMS")" \
    "$(du -sh "$TARBALL" | cut -f1)"
printf '  checksum: %s\n' "$(cat "$TARBALL.sha256" | cut -c1-16)..."
printf '\n  to use it:\n'
printf '    sha256sum -c %s.sha256\n' "$(basename "$TARBALL")"
printf '    tar -xzf %s && cd %s\n' "$(basename "$TARBALL")" "$NAME"
printf '    ./setup.sh\n'
