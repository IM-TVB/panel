<?php

namespace Pterodactyl\Repositories\Wings;

use Webmozart\Assert\Assert;
use Pterodactyl\Models\Server;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Exception\TransferException;
use Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException;

/**
 * @method \Pterodactyl\Repositories\Wings\DaemonServerRepository setNode(\Pterodactyl\Models\Node $node)
 * @method \Pterodactyl\Repositories\Wings\DaemonServerRepository setServer(\Pterodactyl\Models\Server $server)
 */
class DaemonServerRepository extends DaemonRepository
{
    /**
     * Returns details about a server from the Daemon instance.
     *
     * @throws DaemonConnectionException
     */
    public function getDetails(): array
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $response = $this->getHttpClient()->get(
                sprintf('/api/servers/%s', $this->server->uuid)
            );
        } catch (TransferException $exception) {
            throw new DaemonConnectionException($exception, false);
        }

        return json_decode($response->getBody()->__toString(), true);
    }

    /**
     * Creates a new server on the Wings daemon.
     *
     * @throws DaemonConnectionException
     */
    public function create(bool $startOnCompletion = true): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $this->getHttpClient()->post('/api/servers', [
                'json' => [
                    'uuid' => $this->server->uuid,
                    'start_on_completion' => $startOnCompletion,
                ],
            ]);
        } catch (GuzzleException $exception) {
            throw new DaemonConnectionException($exception);
        }
    }

    /**
     * Triggers a server sync on Wings.
     *
     * @throws DaemonConnectionException
     */
    public function sync(): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $this->getHttpClient()->post("/api/servers/{$this->server->uuid}/sync");
        } catch (GuzzleException $exception) {
            throw new DaemonConnectionException($exception);
        }
    }

    /**
     * Delete a server from the daemon, forcibly if passed.
     *
     * @throws DaemonConnectionException
     */
    public function delete(): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $this->getHttpClient()->delete('/api/servers/' . $this->server->uuid);
        } catch (TransferException $exception) {
            throw new DaemonConnectionException($exception);
        }
    }

    /**
     * Reinstall a server on the daemon.
     *
     * $deleteFiles is the operator's choice about what happens to the files that
     * are already there, and -- this is the part that is easy to get wrong --
     * **the daemon does not act on it here.**
     *
     * Wings' reinstall handler binds no request body at all:
     *
     *   func postServerReinstall(c *gin.Context) { ... go s.Reinstall() ... }
     *
     * and `(*Server).Reinstall` is documented in the daemon's own source as
     * "does not touch any existing files for the server, other than what the
     * script modifies". `truncate_directory` exists only on the *backup restore*
     * endpoint, where it is honoured via `Filesystem.TruncateRootDirectory()`.
     * The log line this method used to claim proves the confusion: the message
     * `received "truncate_directory" flag in request: deleting server files`
     * lives in router_server_backup.go and cannot appear on this path, which is
     * why it never once showed up in the daemon log despite many reinstalls.
     *
     * So the deletion is done by the caller through deleteServerFiles() before
     * asking for the reinstall. The flag is only a forward compatibility hint,
     * in case a daemon restores the old behaviour, and deletion must not depend
     * on it.
     *
     * @throws DaemonConnectionException
     */
    public function reinstall(bool $deleteFiles = true): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $this->getHttpClient()->post(sprintf(
                '/api/servers/%s/reinstall',
                $this->server->uuid
            ), [
                'json' => ['truncate_directory' => $deleteFiles],
            ]);
        } catch (TransferException $exception) {
            throw new DaemonConnectionException($exception);
        }
    }

    /**
     * The entries directly inside a directory of the server, as the daemon sees
     * them. An empty string is the server's root.
     *
     * @return array<int, array<string, mixed>>
     *
     * @throws DaemonConnectionException
     */
    public function listServerDirectory(string $directory = ''): array
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $response = $this->getHttpClient()->get(sprintf(
                '/api/servers/%s/files/list-directory',
                $this->server->uuid
            ), [
                'query' => ['directory' => $directory],
            ]);
        } catch (TransferException $exception) {
            throw new DaemonConnectionException($exception);
        }

        return json_decode($response->getBody()->__toString(), true) ?? [];
    }

    /**
     * Delete files and directories by name, relative to the server's root.
     *
     * Directories are removed recursively -- the daemon's Filesystem.Delete is
     * os.RemoveAll -- so naming a top-level directory deletes its whole subtree.
     * It goes through the daemon rather than the panel's own filesystem on
     * purpose: the daemon tracks disk usage in a quota wrapper around the root,
     * and only deletions it performs are subtracted from a server's reported
     * size. A panel-side `rm` would leave the accounting permanently inflated.
     *
     * @param  array<int, string>  $files
     *
     * @throws DaemonConnectionException
     */
    public function deleteServerFiles(array $files): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        // The daemon answers 422 with "No files were specified for deletion." for
        // an empty list, so an empty wipe is a no-op here rather than an error.
        if ($files === []) {
            return;
        }

        try {
            $this->getHttpClient()->post(sprintf(
                '/api/servers/%s/files/delete',
                $this->server->uuid
            ), [
                'json' => [
                    'root' => '',
                    'files' => array_values($files),
                ],
            ]);
        } catch (TransferException $exception) {
            throw new DaemonConnectionException($exception);
        }
    }

    /**
     * Empty the server's root directory, which is what "delete the existing
     * files" means for a reinstall.
     *
     * The names are taken from the daemon's own listing rather than guessed, so
     * nothing is deleted by assumption -- including the entries Wings needs to
     * keep working. It recreates nothing: the daemon's own truncate (used when
     * restoring a backup) removes the root and re-mkdirs it, and a reinstall
     * starts from an equivalent empty state anyway.
     *
     * @throws DaemonConnectionException
     */
    public function truncateServerFiles(): void
    {
        $names = [];

        foreach ($this->listServerDirectory() as $entry) {
            // A `name` is a single path segment by construction, and the daemon
            // joins it onto the root itself. Anything else is not something this
            // method should be deleting.
            if (isset($entry['name']) && $this->isPlainName((string) $entry['name'])) {
                $names[] = (string) $entry['name'];
            }
        }

        $this->deleteServerFiles($names);
    }

    /**
     * A single, plain path segment -- no separators, no traversal, nothing that
     * could name anything outside the server's root.
     */
    private function isPlainName(string $name): bool
    {
        return $name !== ''
            && $name !== '.'
            && $name !== '..'
            && !str_contains($name, '/')
            && !str_contains($name, "\0");
    }

    /**
     * Requests the daemon to create a full archive of the server. Once the daemon is finished
     * they will send a POST request to "/api/remote/servers/{uuid}/archive" with a boolean.
     *
     * @throws DaemonConnectionException
     */
    public function requestArchive(): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $this->getHttpClient()->post(sprintf(
                '/api/servers/%s/archive',
                $this->server->uuid
            ));
        } catch (TransferException $exception) {
            throw new DaemonConnectionException($exception);
        }
    }

    /**
     * Revokes a single user's JTI by using their ID. This is simply a helper function to
     * make it easier to revoke tokens on the fly. This ensures that the JTI key is formatted
     * correctly and avoids any costly mistakes in the codebase.
     *
     * @deprecated
     * @see \Pterodactyl\Repositories\Wings\DaemonRevocationRepository::deauthorize()
     *
     * @throws DaemonConnectionException
     */
    public function revokeUserJTI(int $id): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        $this->revokeJTIs([md5($id . $this->server->uuid)]);
    }

    /**
     * Revokes an array of JWT JTI's by marking any token generated before the current time on
     * the Wings instance as being invalid.
     *
     * @throws DaemonConnectionException
     */
    protected function revokeJTIs(array $jtis): void
    {
        Assert::isInstanceOf($this->server, Server::class);

        try {
            $this->getHttpClient()
                ->post(sprintf('/api/servers/%s/ws/deny', $this->server->uuid), [
                    'json' => ['jtis' => $jtis],
                ]);
        } catch (TransferException $exception) {
            throw new DaemonConnectionException($exception);
        }
    }
}
