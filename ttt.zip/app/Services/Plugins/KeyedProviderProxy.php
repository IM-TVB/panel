<?php

namespace Pterodactyl\Services\Plugins;

use Illuminate\Http\Client\Factory as HttpFactory;
use Illuminate\Http\Client\PendingRequest;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * Server-side proxy for the plugin sources that need an API key.
 *
 * The key never leaves the panel. A keyed source is called from here with the
 * credential attached, and the browser only ever sees the normalised results.
 * That is not just tidiness:
 *
 *  - the browser cannot call this API at all. api.curseforge.com sends no CORS
 *    headers, so a cross-origin request from the panel's own page is refused by
 *    the browser before it is even sent.
 *  - the key is issued to a person. Publishing it to every logged-in visitor
 *    would make a leak their problem rather than the panel's.
 *
 * Sources that need no credential (Modrinth, Spigot, Hangar) are deliberately
 * NOT proxied: their APIs are CORS-open, so proxying them would add latency and
 * put panel load in front of work the browser can do itself.
 *
 * The jar bytes come through here too, not just the search. CurseForge announced
 * that CDN downloads would require a key from 16 July 2026, and a browser fetch
 * cannot carry a key the panel is keeping secret -- so a client-side download
 * would 401 even with a perfectly good key saved.
 */
class KeyedProviderProxy
{
    /**
     * CurseForge's content classes this panel installs. Bukkit Plugins is 5, and
     * it is the one that matters here: Modrinth already covers Forge and Fabric
     * mods better than CurseForge does, and mixing classes in one search would
     * put rows in the grid that cannot be installed on the server in front of
     * the user.
     */
    public const CURSEFORGE_GAME_ID = 65621;

    public const CURSEFORGE_BUKKIT_CLASS_ID = 5;

    /**
     * Upstream base URL and the header the key travels in.
     */
    private const SOURCES = [
        'curseforge' => [
            'base' => 'https://api.curseforge.com/v1',
            // Classic organisation keys travel in x-api-key.
            'header' => 'x-api-key',
        ],
    ];

    /**
     * The prefix CurseForge uses for its newer profile/organisation keys.
     *
     * These are a different credential from the classic organisation key and they
     * travel differently: as `Authorization: Key <token>` rather than in
     * x-api-key. Both forms are accepted by the CDN, so the header is chosen from
     * the key's own shape rather than asked about.
     */
    private const PROFILE_KEY_PREFIX = 'cfc_pat_';

    /**
     * The classic form: a bcrypt-shaped `$2a$10$...` string.
     *
     * Recognised only to keep the comment honest about what "not a profile key"
     * means. No branch turns on it -- a key of an unrecognised shape is sent
     * under both headers, which is the safe default.
     */
    private const CLASSIC_KEY_PATTERN = '/^\$2[aby]\$\d{2}\$/';

    public function __construct(
        private ProviderKeyService $keys,
        private HttpFactory $http,
    ) {
    }

    public function isConfigured(string $provider): bool
    {
        return isset(self::SOURCES[$provider]) && $this->keys->key($provider) !== null;
    }

    /**
     * @throws HttpException 404 when the provider is unknown
     */
    private function assertKnown(string $provider): void
    {
        if (!isset(self::SOURCES[$provider])) {
            // 404, not a 500. A provider that was removed (or never existed) is
            // a missing resource, and a client asking for one is not a fault in
            // the panel.
            throw new HttpException(404, "There is no keyed plugin source called '{$provider}'.");
        }
    }

    /**
     * Search a keyed source, or report that it has no key.
     */
    public function search(string $provider, array $query): array
    {
        $this->assertKnown($provider);

        return $this->call($provider, 'GET', '/mods/search', $this->withDefaults($provider, $query));
    }

    /**
     * Fetch one resource's detail (used for a download URL and description).
     */
    public function detail(string $provider, string $path, array $query = []): array
    {
        $this->assertKnown($provider);

        return $this->call($provider, 'GET', $path, $query);
    }

    /**
     * Fetch a file's bytes, verify them against CurseForge's published hashes,
     * and hand them back for streaming to the browser.
     *
     * The hash check happens here rather than in the client because the bytes and
     * the expected digests both live on this side of the key. Letting the client
     * verify would mean streaming a possibly-corrupt jar to every visitor first
     * and only then discovering it was wrong.
     *
     * @return array{body: string, filename: string, sha1: ?string, md5: ?string, size: int}
     */
    public function download(string $provider, string $path): array
    {
        $this->assertKnown($provider);

        $key = $this->keys->key($provider);

        if ($key === null) {
            throw new HttpException(503, "The '{$provider}' source has no API key configured.");
        }

        $meta = $this->call($provider, 'GET', $path, []);
        $file = $meta['body']['data'] ?? [];

        $url = $file['downloadUrl'] ?? null;

        if (!is_string($url) || $url === '') {
            throw new HttpException(404, 'That file has no download URL.');
        }

        // A longer timeout than the metadata calls: this is the one request that
        // moves the whole jar, and a 100 MB modpack over a slow link will outrun
        // the search timeout.
        $response = $this->request($provider, $key)->timeout(300)->get($url);

        if ($response->status() !== 200) {
            throw new HttpException(
                $response->status() ?: 502,
                sprintf("CurseForge refused the download of '%s' (HTTP %d).", $file['fileName'] ?? 'the file', $response->status())
            );
        }

        $body = $response->body();

        // Checked before the digests, because an empty response also fails every
        // checksum and "did not match its published checksum" would blame the
        // upstream for what is really a truncated or intercepted transfer.
        if (strlen($body) === 0) {
            throw new HttpException(502, 'CurseForge returned an empty download.');
        }

        // CurseForge indexes hashes by algorithm: 1 is sha1, 2 is md5. It
        // publishes no sha256 for CDN files, so sha1 is the strongest digest
        // available here.
        $hashes = $file['hashes'] ?? [];
        $sha1 = $hashes[1] ?? null;
        $md5 = $hashes[2] ?? null;

        if (is_string($sha1) && $sha1 !== '' && !hash_equals(strtolower($sha1), sha1($body))) {
            throw new HttpException(502, sprintf("The download of '%s' did not match its published checksum.", $file['fileName'] ?? 'the file'));
        }

        if (is_string($md5) && $md5 !== '' && !hash_equals(strtolower($md5), md5($body))) {
            throw new HttpException(502, sprintf("The download of '%s' did not match its published checksum.", $file['fileName'] ?? 'the file'));
        }

        return [
            'body' => $body,
            'filename' => (string) ($file['fileName'] ?? 'plugin.jar'),
            'sha1' => is_string($sha1) ? strtolower($sha1) : null,
            'md5' => is_string($md5) ? strtolower($md5) : null,
            'size' => strlen($body),
        ];
    }

    /**
     * @return array{status: int, body: array}
     */
    private function call(string $provider, string $method, string $path, array $params): array
    {
        $key = $this->keys->key($provider);

        if ($key === null) {
            // 503: the panel is fine, a prerequisite is missing, and the fix is
            // in Admin -> Settings rather than in the user's request.
            throw new HttpException(503, "The '{$provider}' source has no API key configured.");
        }

        $response = $this->request($provider, $key)->{$method}($path, $params);

        $status = $response->status();
        $decoded = $response->json();

        // A rejected key is worth saying plainly: it is the one failure an
        // operator can actually fix from the settings page.
        if ($status === 401 || $status === 403) {
            throw new HttpException($status, $this->rejectionMessage($provider));
        }

        // Anything else non-2xx is still a failure, even though the operator may
        // not be able to fix it. Letting it through would show an empty plugin
        // list as though the source simply had no matches.
        if ($status < 200 || $status >= 300) {
            throw new HttpException($status ?: 502, $this->failureMessage($provider, $status, $decoded));
        }

        if (!is_array($decoded)) {
            throw new HttpException(502, "The '{$provider}' source returned a response that could not be read as JSON.");
        }

        return ['status' => $status, 'body' => $decoded];
    }

    /**
     * Translate the panel's neutral search parameters into the names CurseForge
     * expects, and pin the ones that must not vary.
     *
     * This lives here rather than in the controller because the proxy has more
     * than one caller: the admin settings page calls search() directly to test
     * a freshly pasted key, and a perfectly good key would have been reported as
     * rejected had that caller had to remember to rename the parameters itself.
     */
    private function withDefaults(string $provider, array $query): array
    {
        $query['searchFilter'] = (string) ($query['query'] ?? $query['searchFilter'] ?? '');
        $query['pageSize'] = (int) ($query['size'] ?? 20);
        $query['index'] = (int) ($query['index'] ?? 0);
        // sortField 6 is download count, which is the order Aternos shows.
        $query['sortField'] = 6;

        if (($query['gameVersion'] ?? '') !== '') {
            $query['gameVersion'] = (string) $query['gameVersion'];
        } else {
            unset($query['gameVersion']);
        }

        unset($query['query'], $query['size'], $query['classId'], $query['gameId']);

        // gameId 65621 is Minecraft in the v1 API. (The legacy addons-ecs API
        // used 432; that value does not work against api.curseforge.com/v1.)
        // classId 5 is Bukkit Plugins -- 6 is Modpacks and 4471 is mods, neither
        // of which this panel installs.
        $query += [
            'gameId' => self::CURSEFORGE_GAME_ID,
            'classId' => self::CURSEFORGE_BUKKIT_CLASS_ID,
        ];

        return $query;
    }

    /**
     * What to say when a key is refused.
     *
     * A bare "the key was rejected" is the least useful message the panel can
     * give, because every upstream answers identically for a missing key, a
     * revoked key, a key from the wrong product, and a key that is not a key at
     * all. Naming the expected shape turns the most common cause into something
     * the operator can check against what they pasted.
     */
    /**
     * What to say when the upstream refuses the stored key.
     *
     * Rewritten because the old wording asserted more than the response supports.
     * It told the operator that "a token from any other CurseForge API will be
     * refused", which reads as *you pasted the wrong kind of token* -- and CurseForge
     * answers a valid-but-unentitled key with the identical
     * "Forbidden: API Key missing or invalid". So that sentence sent someone with
     * a perfectly good profile key off to fetch a different one, twice.
     *
     * What is actually known is much narrower: the request was refused, and the
     * refusal does not say why. This says that, names the two real possibilities
     * without pretending to have distinguished them, and points at the page a key
     * comes from. A message that under-claims is better than one that sends
     * people to the wrong place with confidence.
     */
    private function rejectionMessage(string $provider): string
    {
        $meta = ProviderKeyService::PROVIDERS[$provider] ?? [];
        $name = $meta['name'] ?? ucfirst($provider);
        $url = $meta['url'] ?? null;

        if ($url === null) {
            return sprintf(
                'The %s API refused the stored key. The upstream did not say why; it returns the same refusal for a key it does not recognise and for one it will not accept for this request.',
                $name
            );
        }

        return sprintf(
            'The %s API refused the stored key, and its refusal does not say why -- CurseForge answers the same way for a key it does not recognise and for one that is not permitted to read the catalogue. Check the key is still valid at %s, and that the account it belongs to has API access to the catalogue. The key is unchanged and can be replaced below.',
            $name,
            $url
        );
    }

    /**
     * The upstream's own words where it gives any, since they are far more
     * useful than "HTTP 400".
     */
    private function failureMessage(string $provider, int $status, mixed $decoded): string
    {
        $detail = is_array($decoded) ? ($decoded['errorMessage'] ?? $decoded['message'] ?? $decoded['error'] ?? null) : null;

        if (is_string($detail) && $detail !== '') {
            return sprintf("The '%s' source refused the request (HTTP %d): %s", $provider, $status, $detail);
        }

        return sprintf("The '%s' source refused the request (HTTP %d).", $provider, $status);
    }

    private function request(string $provider, string $key): PendingRequest
    {
        $source = self::SOURCES[$provider];

        return $this->http
            ->baseUrl($source['base'])
            ->timeout(60)
            ->withHeaders($this->authHeaders($source, $key));
    }

    /**
     * How to present the key to the upstream.
     *
     * A `cfc_pat_` profile key is sent as `Authorization: Key <token>`, which is
     * how CurseForge documents that credential. Anything else goes in x-api-key.
     *
     * An unrecognised shape is sent under *both*, deliberately. Guessing wrong
     * here is not a cosmetic error: a key sent the wrong way is refused with the
     * same 403 as a bad key, and the operator is told their key is invalid when
     * it is not. Since the panel cannot verify a key without spending a request
     * per attempt, sending both removes the guess entirely for the cost of one
     * redundant header. Note this does not rescue a key the upstream simply does
     * not accept -- it only stops the panel from being the reason it is refused.
     */
    private function authHeaders(array $source, string $key): array
    {
        $headers = ['Accept' => 'application/json'];

        if (stripos($key, self::PROFILE_KEY_PREFIX) === 0) {
            return $headers + ['Authorization' => 'Key ' . $key];
        }

        if (preg_match(self::CLASSIC_KEY_PATTERN, $key) === 1) {
            return $headers + [$source['header'] => $key];
        }

        return $headers + [$source['header'] => $key, 'Authorization' => 'Key ' . $key];
    }
}
