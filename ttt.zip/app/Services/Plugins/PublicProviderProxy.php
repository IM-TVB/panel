<?php

namespace Pterodactyl\Services\Plugins;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * Fetches an add-on jar for the keyless sources, on the browser's behalf.
 *
 * The browser normally downloads these three directly from the provider's CDN,
 * which is faster and keeps the panel out of the loop. That path is not
 * guaranteed to work, though: a corporate proxy, a strict privacy extension or a
 * browser that refuses a third-party request all break a download the panel
 * could have made perfectly well. When that happens the user should still get
 * their jar, so this is the second attempt -- the panel makes the same request
 * server-side, where no browser policy applies, and hands the bytes over.
 *
 * The security property that makes this safe to expose is that the browser never
 * supplies a URL. It supplies *identifiers* -- a Modrinth version id, a Hangar
 * project slug and version, a Spigot resource id -- and every request URL is
 * built here from a hardcoded host and a path this class fills in. The upstream
 * metadata is fetched here too, so even the final CDN URL comes from Modrinth or
 * Hangar rather than from the caller. There is no parameter through which a
 * client can name a host, which is what separates this from an open request
 * proxy pointed at the panel's own network.
 *
 * The host allowlist is enforced a second time on the resolved URL and on every
 * redirect hop, so a compromised or spoofed metadata response cannot redirect the
 * fetch at something internal. Redirects are additionally restricted to https,
 * so a hop cannot be used to downgrade the connection.
 *
 * Where the provider publishes a digest it is checked before a single byte is
 * returned, exactly as the keyed path already does for CurseForge. Spiget
 * publishes none, so that one rests on the response being a real jar, which the
 * client verifies independently.
 */
class PublicProviderProxy
{
    /**
     * Every host this class will ever contact, and nothing else.
     *
     * Each source lists its metadata host and its CDN host separately because
     * they are genuinely different machines: Modrinth answers metadata on
     * api.modrinth.com and serves bytes from cdn.modrinth.com, Hangar likewise
     * splits hangar.papermc.io from hangarcdn.papermc.io.
     */
    private const SOURCES = [
        'modrinth' => [
            'label' => 'Modrinth',
            'hosts' => ['api.modrinth.com', 'cdn.modrinth.com'],
        ],
        'hangar' => [
            'label' => 'Hangar',
            'hosts' => ['hangar.papermc.io', 'hangarcdn.papermc.io'],
        ],
        'spigot' => [
            'label' => 'Spigot',
            'hosts' => ['cdn.spiget.org'],
        ],
    ];

    /**
     * A generous ceiling for one jar. Minecraft modpacks and resource packs are
     * the large end of this and sit well below it; anything larger is a sign the
     * upstream is not serving what was asked for, and buffering it would be a
     * denial of service against the panel rather than a download.
     */
    private const MAX_BYTES = 536870912; // 512 MB

    private const TIMEOUT = 300;

    /**
     * Modrinth's terms require a descriptive User-Agent, and reject the default
     * one, so this is not decoration.
     */
    private const USER_AGENT = 'PterodactylPanel/1.0 (+plugin-browser)';

    /**
     * Download one jar.
     *
     * @param  array<string, mixed>  $identifiers
     * @return array{body: string, filename: string, sha1: string|null, sha256: string|null, size: int}
     *
     * @throws HttpException
     */
    public function download(string $provider, array $identifiers): array
    {
        $source = $this->assertKnown($provider);

        $resolved = match ($provider) {
            'modrinth' => $this->resolveModrinth($identifiers),
            'hangar' => $this->resolveHangar($identifiers),
            'spigot' => $this->resolveSpigot($identifiers),
        };

        $this->assertAllowedHost($source['hosts'], $resolved['url'], $provider);

        return $this->fetch($source, $provider, $resolved);
    }

    /**
     * @param  array{hosts: array<int, string>, label: string}  $source
     * @param  array{url: string, filename: string, sha1: string|null, sha256: string|null}  $resolved
     * @return array{body: string, filename: string, sha1: string|null, sha256: string|null, size: int}
     */
    private function fetch(array $source, string $provider, array $resolved): array
    {
        $response = $this->client($source)
            ->timeout(self::TIMEOUT)
            ->withOptions([
                'allow_redirects' => [
                    'max' => 3,
                    // Refuse any hop that is not https. Without this a provider
                    // could bounce the fetch onto plaintext, and the digest
                    // check below would be the only thing left protecting it.
                    'protocols' => ['https'],
                    'strict' => false,
                    'referer' => false,
                    'track_redirects' => false,
                    'on_redirect' => function ($request, $response, $uri) use ($source, $provider): void {
                        $this->assertAllowedHost($source['hosts'], (string) $uri, $provider);
                    },
                ],
            ])
            ->get($resolved['url']);

        if ($response->status() !== 200) {
            throw new HttpException(
                $response->status() ?: 502,
                sprintf('%s refused the download (HTTP %d).', $source['label'], $response->status())
            );
        }

        // Checked from the Content-Length header BEFORE the body is read into
        // memory. Reading the body first and then measuring it, as this
        // originally did, does not prevent the memory exhaustion it claimed to
        // prevent -- by the time strlen() runs the bytes are already resident.
        // A chunked response with no length header falls through to the strlen
        // check below, which is the backstop rather than the gate.
        $declared = $response->header('Content-Length');

        if ($declared !== '' && (int) $declared > self::MAX_BYTES) {
            throw new HttpException(502, sprintf('That file is larger than this panel will proxy (%d MB).', intdiv(self::MAX_BYTES, 1048576)));
        }

        $body = $response->body();

        // Checked before the digests for the same reason as the keyed path: an
        // empty body also fails every checksum, and reporting that as "did not
        // match the published checksum" would blame the provider for what is
        // really a truncated transfer.
        if ($body === '') {
            throw new HttpException(502, sprintf('%s returned an empty download.', $source['label']));
        }

        if (strlen($body) > self::MAX_BYTES) {
            throw new HttpException(502, sprintf('That file is larger than this panel will proxy (%d MB).', intdiv(self::MAX_BYTES, 1048576)));
        }

        foreach (['sha1', 'sha256'] as $algorithm) {
            $expected = $resolved[$algorithm];

            if (!is_string($expected) || $expected === '') {
                continue;
            }

            if (!hash_equals(strtolower($expected), hash($algorithm, $body))) {
                throw new HttpException(502, sprintf(
                    'The download of "%s" did not match its published %s.',
                    $resolved['filename'],
                    $algorithm
                ));
            }
        }

        return [
            'body' => $body,
            'filename' => $resolved['filename'],
            'sha1' => $resolved['sha1'],
            'sha256' => $resolved['sha256'],
            'size' => strlen($body),
        ];
    }

    /**
     * Modrinth: a version id names exactly one version, so the panel fetches that
     * version's record and takes the primary file from it.
     *
     * The client sends the version id it already chose rather than a project slug.
     * That matters: a slug's newest version may be a NeoForge or Fabric build,
     * and re-resolving "latest" here would hand the user a jar for the wrong
     * platform while appearing to succeed.
     *
     * @param  array<string, mixed>  $identifiers
     * @return array{url: string, filename: string, sha1: string|null, sha256: string|null}
     */
    private function resolveModrinth(array $identifiers): array
    {
        $versionId = $this->identifier($identifiers['versionId'] ?? null, 'Modrinth version id');

        $meta = $this->client(self::SOURCES['modrinth'])
            ->timeout(30)
            ->get(sprintf('https://api.modrinth.com/v2/version/%s', rawurlencode($versionId)));

        if ($meta->status() !== 200) {
            throw new HttpException($meta->status() ?: 502, 'Modrinth did not return that version.');
        }

        $files = $meta->json('files');
        $files = is_array($files) ? $files : [];

        // Modrinth can attach several files to one version (sources, signatures).
        // The primary is the one a player is meant to run.
        $primary = null;
        foreach ($files as $file) {
            if (is_array($file) && ($file['primary'] ?? false) === true) {
                $primary = $file;

                break;
            }
        }

        $primary ??= $files[0] ?? null;

        if (!is_array($primary) || !is_string($primary['url'] ?? null)) {
            throw new HttpException(404, 'That Modrinth version has no downloadable file.');
        }

        $hashes = is_array($primary['hashes'] ?? null) ? $primary['hashes'] : [];

        return [
            'url' => $primary['url'],
            'filename' => is_string($primary['filename'] ?? null) ? $primary['filename'] : 'modrinth-addon.jar',
            'sha1' => $this->digest($hashes, 'sha1'),
            // Modrinth also publishes sha512, but sha1 is what the client-side
            // verifier already understands, so only this is carried back.
            'sha256' => null,
        ];
    }

    /**
     * Hangar: a project slug plus a version name.
     *
     * Both are messy in ways worth being explicit about.
     *
     * The project slug is namespaced -- Hangar identifies a project as
     * `owner/slug`, and its own API takes that as two path segments. So a slash
     * here is legitimate and required, which is why this is not handled by the
     * plain path-segment rule below. It is split, each half validated
     * separately, and rejoined: that way a slug can contain the one separator it
     * needs without also being able to contain an arbitrary number of them.
     *
     * The version name is not constrained to a charset -- real ones look like
     * "5.12.1-SNAPSHOT+635" -- so it is URL-encoded into a single segment and then
     * checked for the shapes that would change which resource is requested.
     *
     * @param  array<string, mixed>  $identifiers
     * @return array{url: string, filename: string, sha1: string|null, sha256: string|null}
     */
    private function resolveHangar(array $identifiers): array
    {
        $slug = $this->namespacedSlug($identifiers['slug'] ?? null);
        $version = $this->pathSegment($identifiers['version'] ?? null, 'Hangar version');

        $meta = $this->client(self::SOURCES['hangar'])
            ->timeout(30)
            ->get(sprintf(
                'https://hangar.papermc.io/api/v1/projects/%s/versions/%s',
                // Each validated part is encoded on its own and then rejoined, so
                // the namespace separator survives while nothing inside a part can
                // introduce a segment of its own.
                implode('/', array_map('rawurlencode', explode('/', $slug))),
                rawurlencode($version)
            ));

        if ($meta->status() === 404) {
            throw new HttpException(404, 'Hangar has no such project version.');
        }

        if ($meta->status() !== 200) {
            throw new HttpException($meta->status() ?: 502, 'Hangar did not return that version.');
        }

        // A Paper plugin is what a Bukkit server can load; the other platforms
        // (Velocity, Waterfall) ship jars this server would not accept.
        $paper = $meta->json('downloads.PAPER');

        if (!is_array($paper) || !is_string($paper['downloadUrl'] ?? null) || $paper['downloadUrl'] === '') {
            throw new HttpException(404, 'That Hangar version has no Paper download.');
        }

        $info = is_array($paper['fileInfo'] ?? null) ? $paper['fileInfo'] : [];

        return [
            'url' => $paper['downloadUrl'],
            'filename' => is_string($info['name'] ?? null) && $info['name'] !== ''
                ? $info['name']
                : $slug . '.jar',
            'sha1' => null,
            'sha256' => $this->digest($info, 'sha256Hash'),
        ];
    }

    /**
     * Spigot: the CDN path is a pure template, so no metadata call is needed.
     *
     * Spiget publishes no checksum for the file it serves, so there is nothing to
     * verify here. The filename returned is deliberately generic -- the real one
     * is built by the client, which is the only place that knows the project's
     * name and newest version. See spigetFilename.ts.
     *
     * @param  array<string, mixed>  $identifiers
     * @return array{url: string, filename: string, sha1: string|null, sha256: string|null}
     */
    private function resolveSpigot(array $identifiers): array
    {
        $id = $this->positiveInt($identifiers['id'] ?? null, 'Spigot resource id');

        return [
            'url' => sprintf('https://cdn.spiget.org/file/spiget-resources/%d.jar', $id),
            'filename' => sprintf('spigot-%d.jar', $id),
            'sha1' => null,
            'sha256' => null,
        ];
    }

    /**
     * @param  array<string, mixed>  $hashes
     */
    private function digest(array $hashes, string $key): ?string
    {
        $value = $hashes[$key] ?? null;

        if (!is_string($value)) {
            return null;
        }

        $value = strtolower(trim($value));

        return preg_match('/^[a-f0-9]{32,128}$/', $value) === 1 ? $value : null;
    }

    /**
     * @return array{hosts: array<int, string>, label: string}
     */
    private function assertKnown(string $provider): array
    {
        $source = self::SOURCES[$provider] ?? null;

        if ($source === null) {
            // A 404 rather than a 403: an unknown source is not a thing that
            // exists, and this endpoint takes no credential that could be probed.
            throw new HttpException(404, 'That is not a source this panel can download from.');
        }

        return $source;
    }

    /**
     * The check that makes the whole design safe.
     *
     * @param  array<int, string>  $hosts
     */
    private function assertAllowedHost(array $hosts, string $url, string $provider): void
    {
        $host = parse_url($url, PHP_URL_HOST);

        if (!is_string($host) || !in_array(strtolower($host), $hosts, true)) {
            throw new HttpException(502, sprintf(
                'Refusing to fetch "%s" for the %s source: its host is not one this panel contacts.',
                $url,
                $provider
            ));
        }

        // Belt and braces: the allowlist is all https hosts, so anything reaching
        // here over another scheme is a bug or a spoof, not a legitimate request.
        if (strtolower((string) parse_url($url, PHP_URL_SCHEME)) !== 'https') {
            throw new HttpException(502, 'Refusing a non-https download URL.');
        }
    }

    /**
     * @param  array{hosts: array<int, string>, label: string}  $source
     */
    private function client(array $source): PendingRequest
    {
        return Http::withHeaders(['User-Agent' => self::USER_AGENT])
            ->acceptJson()
            ->timeout(self::TIMEOUT);
    }

    private function positiveInt(mixed $value, string $what): int
    {
        // Accepted as a string because that is how a query parameter arrives.
        // Rejecting anything non-numeric outright matters more than the range
        // check: this value is interpolated into a URL below.
        if (!is_int($value) && !(is_string($value) && preg_match('/^\d{1,12}$/', $value) === 1)) {
            throw new HttpException(422, sprintf('A %s is required.', $what));
        }

        $int = (int) $value;

        if ($int < 1) {
            throw new HttpException(422, sprintf('A %s is required.', $what));
        }

        return $int;
    }

    /**
     * Modrinth identifiers, which are base62 strings such as "AANobbMI" rather
     * than integers.
     *
     * The charset restriction is the point: it admits Modrinth's real ids while
     * leaving no character that means anything in a URL, so no escaping is
     * required and nothing can be smuggled into the path.
     */
    private function identifier(mixed $value, string $what): string
    {
        if (!is_string($value) || preg_match('/^[A-Za-z0-9]{1,64}$/', $value) !== 1) {
            throw new HttpException(422, sprintf('A %s is required.', $what));
        }

        return $value;
    }

    /**
     * Hangar's `owner/slug`, or a bare slug from a source that does not namespace.
     *
     * Split on the separator, validate each half as an ordinary path segment, then
     * rejoin. Doing it in that order is what keeps this safe: a value can contain
     * the single separator Hangar needs and still not contain a second one, a dot
     * segment, or an empty half.
     */
    private function namespacedSlug(mixed $value): string
    {
        if (!is_string($value)) {
            throw new HttpException(422, 'A Hangar project is required.');
        }

        $parts = explode('/', trim($value));

        if (count($parts) > 2) {
            throw new HttpException(422, 'That Hangar project is not valid.');
        }

        $checked = [];
        foreach ($parts as $part) {
            // Reuses the plain-segment rule, which already refuses the empty
            // string, a dot segment and a backslash.
            $checked[] = $this->pathSegment($part, 'Hangar project');
        }

        return implode('/', $checked);
    }

    /**
     * A value that will be used as a single URL path segment.
     *
     * The two rejected shapes are the ones that would reach a different resource
     * than the one named: a slash would add a path segment, and a dot segment
     * would walk up the tree. Both are refused outright rather than encoded,
     * because no real project slug or version name contains them.
     */
    private function pathSegment(mixed $value, string $what): string
    {
        if (!is_string($value)) {
            throw new HttpException(422, sprintf('A %s is required.', $what));
        }

        $value = trim($value);

        if ($value === '' || strlen($value) > 200) {
            throw new HttpException(422, sprintf('A %s is required.', $what));
        }

        if (str_contains($value, '/') || str_contains($value, '\\') || str_contains($value, '..')) {
            throw new HttpException(422, sprintf('That %s is not valid.', $what));
        }

        if (preg_match('/[\x00-\x1f\x7f]/', $value) === 1) {
            throw new HttpException(422, sprintf('That %s is not valid.', $what));
        }

        return $value;
    }
}
