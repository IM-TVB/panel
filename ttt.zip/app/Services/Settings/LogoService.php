<?php

namespace Pterodactyl\Services\Settings;

/**
 * The panel's sidebar logo.
 *
 * Modelled on BackgroundService rather than FaviconService, and deliberately so.
 * A favicon has to be a real file at a path the browser requests without a
 * controller, and it is a set of 26 generated sizes. A logo is one image that one
 * <span> references, so it wants the same treatment as the background: a hashed
 * file in public/ plus a small JSON sidecar, which gives cache-busting for free
 * because a new upload gets a new name.
 *
 * Null url means "no logo set", and the caller falls back to the initial-letter
 * tile the theme has always drawn. That fallback is the reason this is a separate
 * service rather than a column on the settings table: the tile is the default
 * state, and it has to survive the file being deleted over SSH.
 */
class LogoService
{
    use ProbesImageUploads;

    /**
     * Bounded, and tighter than the background's 8 MB.
     *
     * This is a 34px square in a sidebar, shown on every page of every request
     * for every signed-in user. A logo that is 2 MB is a misconfiguration, and
     * refusing it is kinder than serving it on every navigation.
     */
    public const MAX_BYTES = 1048576; // 1 MB

    /**
     * Smallest side we will accept.
     *
     * A 16px logo scaled up to 34 is a blur, and the operator will not notice
     * until they look at the sidebar. 32 is low enough to allow a plain mark and
     * high enough that it is not obviously broken.
     */
    public const MIN_DIMENSION = 32;

    public function directory(): string
    {
        return public_path('branding');
    }

    public function metadataPath(): string
    {
        return $this->directory() . '/logo.json';
    }

    /**
     * @return array{file?:string,updatedAt?:string}
     */
    public function metadata(): array
    {
        if (!is_file($this->metadataPath())) {
            return [];
        }

        $decoded = json_decode((string) @file_get_contents($this->metadataPath()), true);

        return is_array($decoded) ? $decoded : [];
    }

    /**
     * The URL the browser should fetch, or null when there is no usable image.
     *
     * The existence check is repeated rather than trusted from the sidecar: an
     * operator can delete the file over SSH, and a sidebar pointed at a 404 shows
     * a broken-image icon where the logo should be.
     */
    public function url(): ?string
    {
        $file = $this->metadata()['file'] ?? null;

        if (!$this->isSafeImageName($file) || !is_file($this->absolutePath((string) $file))) {
            return null;
        }

        return asset('branding/' . $file);
    }

    public function hasImage(): bool
    {
        return $this->url() !== null;
    }

    public function absolutePath(string $file): string
    {
        return $this->directory() . '/' . basename($file);
    }

    /**
     * @return array{url:?string}
     */
    public function forTheme(): array
    {
        return ['url' => $this->url()];
    }

    /**
     * Move an already-validated upload into public/ and record it.
     *
     * @return array{file:string,url:string,w:int,h:int,bytes:int}
     */
    public function set(string $sourcePath): array
    {
        $probe = $this->probeImage($sourcePath, self::MAX_BYTES, 'logo');

        // Not a square-warning-and-carry-on: a logo is drawn into a 34px rounded
        // square, so a 900x200 wordmark is stretched to fit and looks broken.
        // Said out loud rather than silently letterboxed.
        if ($probe['w'] < self::MIN_DIMENSION || $probe['h'] < self::MIN_DIMENSION) {
            throw new \RuntimeException(sprintf(
                'The logo is %dx%d. It needs to be at least %dx%d, or it is blurred when drawn in the sidebar.',
                $probe['w'],
                $probe['h'],
                self::MIN_DIMENSION,
                self::MIN_DIMENSION
            ));
        }

        $this->ensureDirectory();

        $previous = $this->metadata()['file'] ?? null;

        // Content-addressed, so re-uploading the same bytes keeps the same URL
        // while any change produces a new one.
        $name = $this->imageName($sourcePath, $probe['ext']);
        $target = $this->directory() . '/' . $name;

        if (!@copy($sourcePath, $target)) {
            throw new \RuntimeException('The logo could not be written to ' . $this->directory() . '.');
        }

        @chmod($target, 0644);

        if (is_string($previous) && $previous !== $name) {
            @unlink($this->absolutePath($previous));
        }

        $this->write([
            'file' => $name,
            'updatedAt' => now()->toIso8601String(),
        ]);

        return [
            'file' => $name,
            'url' => $this->url(),
            'w' => $probe['w'],
            'h' => $probe['h'],
            'bytes' => (int) @filesize($target),
        ];
    }

    /**
     * Remove the image and the sidecar, so the sidebar goes back to its
     * initial-letter tile. Idempotent.
     */
    public function reset(): bool
    {
        $had = false;

        // Only the logo's own two files. public/branding/ is shared: it also
        // holds colors.json (ThemeColorService) and announcement.json
        // (AnnouncementService), and a glob-and-delete of everything else here
        // silently destroyed both every time the logo was reset.
        $file = $this->metadata()['file'] ?? null;

        if (is_string($file) && $file !== '' && @unlink($this->absolutePath($file))) {
            $had = true;
        }

        if (is_file($this->metadataPath())) {
            @unlink($this->metadataPath());
            $had = true;
        }

        return $had;
    }

    private function write(array $data): void
    {
        $this->ensureDirectory();

        file_put_contents(
            $this->metadataPath(),
            json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n",
        );
    }

    private function ensureDirectory(): void
    {
        $dir = $this->directory();

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '. Check that public/ is writable.');
        }
    }
}
