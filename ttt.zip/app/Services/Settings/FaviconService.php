<?php

namespace Pterodactyl\Services\Settings;

use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * Generates the panel's icon set from a single source image.
 *
 * Shared by the admin "Branding" screen and `tools/set-favicon.php`, so there is
 * exactly one implementation of the resize/crop logic.
 */
class FaviconService
{
    /**
     * Every PNG the Blade templates, manifest.json and browserconfig.xml refer
     * to, mapped to the square size it must be generated at.
     */
    public const TARGETS = [
        'favicon-16x16.png' => 16,
        'favicon-32x32.png' => 32,
        'favicon-48x48.png' => 48,
        'favicon-96x96.png' => 96,
        'apple-touch-icon.png' => 180,
        'android-chrome-192x192.png' => 192,
        'android-chrome-512x512.png' => 512,
        'mstile-150x150.png' => 150,
        'ms-icon-70x70.png' => 70,
        'ms-icon-144x144.png' => 144,
        'ms-icon-150x150.png' => 150,
        'ms-icon-310x310.png' => 310,
        'android-icon-36x36.png' => 36,
        'android-icon-48x48.png' => 48,
        'android-icon-72x72.png' => 72,
        'android-icon-96x96.png' => 96,
        'android-icon-144x144.png' => 144,
        'android-icon-192x192.png' => 192,
        'apple-icon-57x57.png' => 57,
        'apple-icon-60x60.png' => 60,
        'apple-icon-72x72.png' => 72,
        'apple-icon-76x76.png' => 76,
        'apple-icon-114x114.png' => 114,
        'apple-icon-120x120.png' => 120,
        'apple-icon-144x144.png' => 144,
        'apple-icon-152x152.png' => 152,
        'apple-icon-180x180.png' => 180,
    ];

    /** Sizes packed into favicon.ico. */
    private const ICO_SIZES = [16, 32, 48];

    private const DEFAULT_COLOR = '#007bff';

    public function __construct()
    {
    }

    public function iconDirectory(): string
    {
        return public_path('favicons');
    }

    public function iconPath(string $file): string
    {
        return $this->iconDirectory() . '/' . $file;
    }

    /** Absolute path to the metadata file the Blade templates read. */
    public function metadataPath(): string
    {
        return $this->iconPath('icon.json');
    }

    /** Where the pristine icons are stashed so they can be restored. */
    private function stockDirectory(): string
    {
        return storage_path('app/favicon-stock');
    }

    public function metadata(): array
    {
        if (!is_file($this->metadataPath())) {
            return [];
        }

        return json_decode((string) @file_get_contents($this->metadataPath()), true) ?: [];
    }

    public function color(): string
    {
        return $this->metadata()['maskColor'] ?? self::DEFAULT_COLOR;
    }

    /**
     * Validate an uploaded file before we spend GD time on it.
     *
     * The mime check alone is not enough — a .svg renamed to .png passes Laravel's
     * extension check but cannot be decoded — so getimagesize() is the real gate.
     *
     * @return array{w:int,h:int,type:int}
     */
    public function probe(string $path): array
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new RuntimeException("The image could not be found at {$path}.");
        }

        $info = @getimagesize($path);
        if ($info === false) {
            throw new RuntimeException('That file could not be read as an image. PNG, JPEG and GIF are supported (SVG is not).');
        }

        $supported = [IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF];
        if (!in_array($info[2], $supported, true)) {
            throw new RuntimeException('Unsupported image type. Please use a PNG, JPEG or GIF.');
        }

        return $info;
    }

    /**
     * Rebuild the whole icon set from $sourcePath.
     *
     * @return array{files:int,bytes:int,color:string}
     */
    public function regenerate(string $sourcePath, ?string $color = null, ?string $name = null, bool $crop = true): array
    {
        if (!extension_loaded('gd')) {
            throw new RuntimeException('ext-gd is required to generate icons, but it is not loaded.');
        }

        $color = $this->normalizeColor($color ?? $this->color());
        $this->ensureDirectory();
        // Keep the originals before the first overwrite, so "reset" can restore.
        $this->ensureStockSnapshot();

        $info = $this->probe($sourcePath);

        $image = match ($info[2]) {
            IMAGETYPE_PNG => @imagecreatefrompng($sourcePath),
            IMAGETYPE_JPEG => @imagecreatefromjpeg($sourcePath),
            IMAGETYPE_GIF => @imagecreatefromgif($sourcePath),
        };

        if ($image === false) {
            throw new RuntimeException('The image could not be decoded.');
        }

        imagealphablending($image, false);
        imagesavealpha($image, true);

        $srcW = imagesx($image);
        $srcH = imagesy($image);

        $bytes = 0;
        foreach (self::TARGETS as $file => $size) {
            $icon = $this->makeSquare($image, $srcW, $srcH, $size, $crop);
            imagepng($icon, $this->iconPath($file), 9);
            imagedestroy($icon);
            $bytes += (int) @filesize($this->iconPath($file));
        }

        imagedestroy($image);

        $bytes += $this->writeIco($sourcePath, $srcW, $srcH, $crop, $info[2]);

        $this->writePinnedTab($sourcePath, $srcW, $srcH, $crop, $info[2]);
        $this->writeManifest($name);
        $this->writeBrowserConfig($color);
        $this->writeMetadata($color, $name);

        return ['files' => count(self::TARGETS) + 3, 'bytes' => $bytes, 'color' => $color];
    }

    /** Rewrite only icon.json + browserconfig.xml, e.g. when just the colour changed. */
    public function setColor(string $color): string
    {
        $color = $this->normalizeColor($color);
        $this->ensureDirectory();
        $this->writeBrowserConfig($color);
        $this->writeMetadata($color);

        return $color;
    }

    /**
     * Put the stock icons back and drop the metadata, so the Blade templates
     * fall back to their built-in defaults.
     */
    public function reset(): bool
    {
        $stock = $this->stockDirectory();
        if (!is_dir($stock)) {
            return false;
        }

        $this->ensureDirectory();
        foreach ((array) glob($this->iconDirectory() . '/*') as $file) {
            if (is_file($file) && !str_ends_with(basename($file), 'icon.json')) {
                @unlink($file);
            }
        }

        foreach ((array) glob($stock . '/*') as $file) {
            if (is_file($file)) {
                @copy($file, $this->iconPath(basename($file)));
            }
        }

        @unlink($this->metadataPath());

        return true;
    }

    public function hasStockSnapshot(): bool
    {
        return is_dir($this->stockDirectory()) && count((array) glob($this->stockDirectory() . '/*.png')) > 0;
    }

    /* ------------------------------------------------------------ internals */

    private function normalizeColor(string $color): string
    {
        $color = ltrim(trim($color), '#');

        if (preg_match('/^[0-9a-fA-F]{3}$/', $color)) {
            // Expand #abc -> #aabbcc
            $color = $color[0] . $color[0] . $color[1] . $color[1] . $color[2] . $color[2];
        }

        if (!preg_match('/^[0-9a-fA-F]{6}$/', $color)) {
            throw new RuntimeException("\"{$color}\" is not a valid hex colour. Use something like #007bff.");
        }

        return '#' . strtolower($color);
    }

    private function ensureDirectory(): void
    {
        $dir = $this->iconDirectory();
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException("Could not create the icon directory: {$dir}. Check its permissions.");
        }
    }

    /**
     * Stash the icons the panel shipped with, so "reset" has something to put
     * back. Native mkdir is used deliberately: the Filesystem contract is bound
     * to a Flysystem adapter whose paths are disk-relative, which silently does
     * nothing when handed an absolute public_path()/storage_path().
     */
    private function ensureStockSnapshot(): void
    {
        if ($this->hasStockSnapshot()) {
            return;
        }

        $stock = $this->stockDirectory();
        if (!is_dir($stock) && !@mkdir($stock, 0755, true) && !is_dir($stock)) {
            // Not fatal: regeneration still works, only "reset" is unavailable.
            Log::warning('[favicon] could not create the stock snapshot directory', ['path' => $stock]);

            return;
        }

        foreach ((array) glob($this->iconDirectory() . '/*') as $file) {
            if (is_file($file)) {
                @copy($file, $stock . '/' . basename($file));
            }
        }
    }

    /**
     * Render a $size x $size icon.
     *
     * crop:  centre-crop to a square first, so the logo fills the tile.
     * else:  scale to fit inside the tile, centred on a transparent field.
     *
     * Downscaling is done in halving steps because a single imagecopyresampled()
     * over a large reduction produces badly aliased small icons. The crop is
     * applied once up front so the offsets are never applied twice.
     */
    private function makeSquare(\GdImage $image, int $srcW, int $srcH, int $size, bool $crop): \GdImage
    {
        if ($crop) {
            $side = min($srcW, $srcH);
            $sx = intdiv($srcW - $side, 2);
            $sy = intdiv($srcH - $side, 2);
            $sw = $side;
            $sh = $side;
        } else {
            $sx = $sy = 0;
            $sw = $srcW;
            $sh = $srcH;
        }

        $work = imagecreatetruecolor($sw, $sh);
        imagealphablending($work, false);
        imagesavealpha($work, true);
        imagecopy($work, $image, 0, 0, $sx, $sy, $sw, $sh);

        $curW = $sw;
        $curH = $sh;
        while ($curW > $size * 2 && $curH > $size * 2) {
            $nextW = max($size, intdiv($curW, 2));
            $nextH = max($size, intdiv($curH, 2));
            $tmp = imagecreatetruecolor($nextW, $nextH);
            imagealphablending($tmp, false);
            imagesavealpha($tmp, true);
            imagecopyresampled($tmp, $work, 0, 0, 0, 0, $nextW, $nextH, $curW, $curH);
            imagedestroy($work);
            $work = $tmp;
            $curW = $nextW;
            $curH = $nextH;
        }

        $canvas = imagecreatetruecolor($size, $size);
        imagealphablending($canvas, false);
        imagesavealpha($canvas, true);
        imagefill($canvas, 0, 0, imagecolorallocatealpha($canvas, 0, 0, 0, 127));

        if ($crop) {
            imagecopyresampled($canvas, $work, 0, 0, 0, 0, $size, $size, $curW, $curH);
        } else {
            $ratio = min($size / $curW, $size / $curH);
            $dw = max(1, (int) round($curW * $ratio));
            $dh = max(1, (int) round($curH * $ratio));

            $scaled = imagecreatetruecolor($dw, $dh);
            imagealphablending($scaled, false);
            imagesavealpha($scaled, true);
            imagecopyresampled($scaled, $work, 0, 0, 0, 0, $dw, $dh, $curW, $curH);
            imagecopy($canvas, $scaled, intdiv($size - $dw, 2), intdiv($size - $dh, 2), 0, 0, $dw, $dh);
            imagedestroy($scaled);
        }

        imagedestroy($work);

        return $canvas;
    }

    /**
     * Build a real .ico containing several PNG-encoded images. GD cannot write
     * ICO, but the container format allows an embedded PNG per entry (Vista
     * onwards), which every currently supported browser reads.
     */
    private function writeIco(string $sourcePath, int $srcW, int $srcH, bool $crop, int $type): int
    {
        $image = $this->load($sourcePath, $type);
        $entries = [];

        foreach (self::ICO_SIZES as $size) {
            $icon = $this->makeSquare($image, $srcW, $srcH, $size, $crop);
            ob_start();
            imagepng($icon, null, 9);
            $entries[$size] = ob_get_clean();
            imagedestroy($icon);
        }
        imagedestroy($image);

        $count = count($entries);
        $directory = '';
        $offset = 6 + (16 * $count);
        $data = '';

        foreach ($entries as $size => $png) {
            $directory .= pack('CCCCvvVV', $size, $size, 0, 0, 1, 32, strlen($png), $offset);
            $data .= $png;
            $offset += strlen($png);
        }

        $path = $this->iconPath('favicon.ico');
        file_put_contents($path, pack('vvv', 0, 1, $count) . $directory . $data);

        return (int) filesize($path);
    }

    /**
     * A mask icon is rendered as a silhouette, so rather than trying to trace
     * vector art the 512px PNG is embedded in a minimal SVG.
     */
    private function writePinnedTab(string $sourcePath, int $srcW, int $srcH, bool $crop, int $type): void
    {
        $image = $this->load($sourcePath, $type);
        $icon = $this->makeSquare($image, $srcW, $srcH, 512, $crop);
        ob_start();
        imagepng($icon, null, 9);
        $b64 = base64_encode(ob_get_clean());
        imagedestroy($icon);
        imagedestroy($image);

        file_put_contents(
            $this->iconPath('safari-pinned-tab.svg'),
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">'
            . '<image width="512" height="512" href="data:image/png;base64,' . $b64 . '"/>'
            . '</svg>'
        );
    }

    private function load(string $path, int $type): \GdImage
    {
        $image = match ($type) {
            IMAGETYPE_PNG => @imagecreatefrompng($path),
            IMAGETYPE_JPEG => @imagecreatefromjpeg($path),
            IMAGETYPE_GIF => @imagecreatefromgif($path),
        };

        if ($image === false) {
            throw new RuntimeException('The image could not be decoded.');
        }

        imagealphablending($image, false);
        imagesavealpha($image, true);

        return $image;
    }

    private function writeManifest(?string $name): void
    {
        $icons = [];
        foreach ([[36, '0.75'], [48, '1.0'], [72, '1.5'], [96, '2.0'], [144, '3.0'], [192, '4.0']] as [$size, $density]) {
            $icons[] = [
                'src' => "/android-icon-{$size}x{$size}.png",
                'sizes' => "{$size}x{$size}",
                'type' => 'image/png',
                'density' => $density,
            ];
        }

        file_put_contents(
            $this->iconPath('manifest.json'),
            json_encode(['name' => $name ?: 'App', 'icons' => $icons], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n"
        );
    }

    private function writeBrowserConfig(string $color): void
    {
        file_put_contents(
            $this->iconPath('browserconfig.xml'),
            '<?xml version="1.0" encoding="utf-8"?>' . "\n"
            . '<browserconfig><msapplication><tile>'
            . '<square70x70logo src="/ms-icon-70x70.png"/>'
            . '<square150x150logo src="/ms-icon-150x150.png"/>'
            . '<square310x310logo src="/ms-icon-310x310.png"/>'
            . '<TileColor>' . htmlspecialchars($color, ENT_XML1) . '</TileColor>'
            . '</tile></msapplication></browserconfig>' . "\n"
        );
    }

    private function writeMetadata(string $color, ?string $name = null): void
    {
        $existing = $this->metadata();
        $name ??= Arr::get($existing, 'name');

        file_put_contents(
            $this->metadataPath(),
            json_encode(
                array_filter([
                    'maskColor' => $color,
                    'themeColor' => $color,
                    'name' => $name,
                    'updatedAt' => date('c'),
                ], fn ($v) => $v !== null),
                JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
            ) . "\n"
        );
    }
}
