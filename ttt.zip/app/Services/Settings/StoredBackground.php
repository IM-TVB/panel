<?php

namespace Pterodactyl\Services\Settings;

/**
 * An optional background image, stored as a real file under public/ plus a small
 * JSON sidecar.
 *
 * Files rather than a database row, because the image has to be reachable by the
 * browser without a controller in the path, and a hashed filename in public/ is
 * the cheapest way to get that plus cache-busting for free — a new upload
 * produces a new name, so no stale image is ever served from a CDN or a browser
 * cache.
 *
 * The scrim is applied by the theme, not here. See assets/aternos.css.
 *
 * This exists because there are now two of these -- the panel background and the
 * one on the authentication pages -- and they differ only in where they are
 * stored. Everything else, including the probes, the clamping and the shape check
 * on the stored name, has to behave identically in both: a divergence here would
 * be a background that uploads on one page and is silently refused on the other,
 * with nothing in the code to point at the reason.
 *
 * A subclass supplies a directory and a metadata filename. Nothing else.
 */
abstract class StoredBackground
{
    use ProbesImageUploads;

    public const FITS = ['cover', 'contain', 'tile'];

    /**
     * Scrim opacity when the operator has not chosen one. High enough that text
     * keeps its contrast against a photograph — this is a text interface, and an
     * undimmed image behind it is unreadable rather than decorative.
     */
    public const DEFAULT_DIM = 0.55;

    public const MIN_DIM = 0.0;

    /*
     * Stops at 0.95 rather than 1. At 1 the operator's picture would be entirely
     * hidden, which is not a setting worth offering as though it did anything.
     */
    public const MAX_DIM = 0.95;

    /**
     * Where the images and the sidecar live.
     */
    abstract public function directory(): string;

    /**
     * The sidecar's filename inside directory(). Kept separate from the directory
     * because reset() has to be able to delete every image while leaving the
     * metadata alone.
     */
    abstract protected function metadataFilename(): string;

    public function metadataPath(): string
    {
        return $this->directory() . '/' . $this->metadataFilename();
    }

    /**
     * @return array{file?:string,dim?:float,fit?:string,updatedAt?:string}
     */
    public function metadata(): array
    {
        if (!is_file($this->metadataPath())) {
            return [];
        }

        $decoded = json_decode((string) @file_get_contents($this->metadataPath()), true);

        return is_array($decoded) ? $decoded : [];
    }

    public function hasImage(): bool
    {
        // Goes through the same shape check as url(). They used to disagree --
        // url() was guarded and this was not -- so a tampered name would report
        // "yes, there is a background" in the admin UI while the theme was
        // handed no url at all.
        return $this->url() !== null;
    }

    /**
     * The URL the browser should fetch, or null when there is no usable image.
     *
     * The existence check is repeated here rather than trusted from the metadata:
     * an operator can delete the file over SSH, and a stylesheet pointing at a 404
     * is worse than no rule at all.
     */
    public function url(): ?string
    {
        $file = $this->metadata()['file'] ?? null;

        if (!$this->isSafeImageName($file) || !is_file($this->absolutePath($file))) {
            return null;
        }

        return asset($this->publicPathPrefix() . $file);
    }

    /**
     * The path under public/ that this image is served from, with its trailing
     * slash. Split out so a subclass stored in a different directory does not
     * have to also remember to change the url() above -- the two drifting apart
     * produces a url that 404s, which on this panel is a 200 with the error page
     * in it, so it looks like the image is set and simply is not drawn.
     */
    protected function publicPathPrefix(): string
    {
        return 'backgrounds/';
    }

    public function dim(): float
    {
        $dim = $this->metadata()['dim'] ?? null;

        if (!is_numeric($dim)) {
            return static::DEFAULT_DIM;
        }

        return max(static::MIN_DIM, min(static::MAX_DIM, (float) $dim));
    }

    public function fit(): string
    {
        $fit = $this->metadata()['fit'] ?? null;

        return is_string($fit) && in_array($fit, static::FITS, true) ? $fit : 'cover';
    }

    /**
     * Everything the theme needs, in one shape, with a `url` of null meaning
     * "no background" so the caller can skip the rule entirely.
     *
     * @return array{url:?string,dim:float,fit:string}
     */
    public function forTheme(): array
    {
        return [
            'url' => $this->url(),
            'dim' => $this->dim(),
            'fit' => $this->fit(),
        ];
    }

    public function absolutePath(string $file): string
    {
        return $this->directory() . '/' . basename($file);
    }

    /**
     * Move an already-validated upload into public/ and record it.
     *
     * @return array{file:string,dim:float,fit:string,w:int,h:int,bytes:int}
     */
    public function set(string $sourcePath, ?float $dim = null, ?string $fit = null): array
    {
        $probe = $this->probeImage($sourcePath, static::MAX_BYTES, $this->label());
        $this->ensureDirectory();

        $previous = $this->metadata()['file'] ?? null;

        // Content-addressed, so re-uploading the same bytes keeps the same URL
        // (no needless cache miss) while any change produces a new one.
        $name = $this->imageName($sourcePath, $probe['ext']);
        $target = $this->directory() . '/' . $name;

        if (!@copy($sourcePath, $target)) {
            throw new \RuntimeException('The image could not be written to ' . $this->directory() . '.');
        }
        @chmod($target, 0644);

        if (is_string($previous) && $previous !== $name) {
            @unlink($this->absolutePath($previous));
        }

        $this->write([
            'file' => $name,
            'dim' => $this->clampDim($dim ?? $this->dim()),
            'fit' => $this->clampFit($fit),
            'updatedAt' => now()->toIso8601String(),
        ]);

        return [
            'file' => $name,
            'dim' => $this->dim(),
            'fit' => $this->fit(),
            'w' => $probe['w'],
            'h' => $probe['h'],
            'bytes' => (int) @filesize($target),
        ];
    }

    /**
     * Record the dim/fit without replacing the image, so the operator can tune
     * the scrim without re-uploading.
     *
     * @return array{dim:float,fit:string}
     */
    public function tune(?float $dim = null, ?string $fit = null): array
    {
        $meta = $this->metadata();

        if ($meta === []) {
            return ['dim' => static::DEFAULT_DIM, 'fit' => 'cover'];
        }

        $this->write(array_merge($meta, [
            'dim' => $this->clampDim($dim ?? $this->dim()),
            'fit' => $this->clampFit($fit),
            'updatedAt' => now()->toIso8601String(),
        ]));

        return ['dim' => $this->dim(), 'fit' => $this->fit()];
    }

    /**
     * Remove the image and the metadata, so the caller falls back to its plain
     * background. Idempotent: resetting with nothing set is a no-op, not an error.
     */
    public function reset(): bool
    {
        $had = false;

        foreach ((array) glob($this->directory() . '/*') as $file) {
            if (is_file($file) && basename($file) !== $this->metadataFilename()) {
                @unlink($file);
                $had = true;
            }
        }

        if (is_file($this->metadataPath())) {
            @unlink($this->metadataPath());
            $had = true;
        }

        return $had;
    }

    /**
     * What to call this image in an error message. Overridden so the two
     * backgrounds do not both report themselves as "background image", which
     * would make an admin page's error useless for telling them apart.
     */
    protected function label(): string
    {
        return 'background image';
    }

    private function clampDim(?float $dim): float
    {
        if ($dim === null) {
            return $this->dim();
        }

        return max(static::MIN_DIM, min(static::MAX_DIM, $dim));
    }

    private function clampFit(?string $fit): string
    {
        if ($fit === null) {
            return $this->fit();
        }

        return in_array($fit, static::FITS, true) ? $fit : $this->fit();
    }

    protected function write(array $data): void
    {
        $this->ensureDirectory();
        file_put_contents(
            $this->metadataPath(),
            json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n",
        );
    }

    protected function ensureDirectory(): void
    {
        $dir = $this->directory();

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '. Check that public/ is writable.');
        }
    }
}
