<?php

namespace Pterodactyl\Services\Settings;

/**
 * A site-wide announcement banner, set from the admin area.
 *
 * Same storage pattern as the colour sidecar: a JSON file under public/branding,
 * so reading it needs neither the database nor config caching, and turning it
 * off is a one-key change rather than a deploy.
 *
 * The banner is emitted by templates/wrapper.blade.php BEFORE the client bundle
 * runs, so it shows on the login page and on every themed page, and it cannot
 * flash in after React mounts.
 */
class AnnouncementService
{
    public const TYPES = ['info', 'success', 'warning', 'danger'];

    public function path(): string
    {
        return public_path('branding/announcement.json');
    }

    public function metadata(): array
    {
        $path = $this->path();

        if (!is_file($path) || !is_readable($path)) {
            return [];
        }

        $decoded = json_decode((string) @file_get_contents($path), true);

        return is_array($decoded) ? $decoded : [];
    }

    public function message(): ?string
    {
        $message = $this->metadata()['message'] ?? null;

        return (is_string($message) && trim($message) !== '') ? trim($message) : null;
    }

    public function enabled(): bool
    {
        return (bool) ($this->metadata()['enabled'] ?? false);
    }

    public function type(): string
    {
        $type = $this->metadata()['type'] ?? 'info';

        return in_array($type, self::TYPES, true) ? $type : 'info';
    }

    /**
     * The banner's background colour, or null to use the style's built-in
     * palette. Hex in the same format as the theme colours.
     */
    public function color(): ?string
    {
        $color = $this->metadata()['color'] ?? null;

        return (is_string($color) && preg_match('/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $color))
            ? strtolower($color)
            : null;
    }

    public function forTheme(): array
    {
        return [
            'enabled' => $this->enabled() && $this->message() !== null,
            'message' => $this->message(),
            'type' => $this->type(),
            'color' => $this->color(),
            'updatedAt' => $this->metadata()['updatedAt'] ?? null,
        ];
    }

    public function set(string $message, string $type, bool $enabled, ?string $color = null): array
    {
        $message = trim($message);

        if (mb_strlen($message) > 500) {
            throw new \InvalidArgumentException('The announcement must be 500 characters or fewer.');
        }

        if (!in_array($type, self::TYPES, true)) {
            throw new \InvalidArgumentException('The type must be one of: ' . implode(', ', self::TYPES));
        }

        if ($color !== null && trim($color) !== '' && !preg_match('/^#?(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', trim($color))) {
            throw new \InvalidArgumentException('The colour must be a hex value like #f59e0b or #f00.');
        }

        $color = ($color !== null && trim($color) !== '')
            ? strtolower(ltrim(trim($color), '#'))
            : null;
        if ($color !== null && strlen($color) === 3) {
            $color = '#' . $color[0] . $color[0] . $color[1] . $color[1] . $color[2] . $color[2];
        } elseif ($color !== null) {
            $color = '#' . $color;
        }

        $dir = dirname($this->path());

        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('Could not create ' . $dir . '.');
        }

        $payload = [
            'message' => $message,
            'type' => $type,
            'enabled' => $enabled,
            'color' => $color,
            'updatedAt' => now()->toIso8601String(),
        ];

        file_put_contents(
            $this->path(),
            json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n",
        );

        return $payload;
    }

    public function clear(): bool
    {
        if (!is_file($this->path())) {
            return false;
        }

        return @unlink($this->path());
    }
}
