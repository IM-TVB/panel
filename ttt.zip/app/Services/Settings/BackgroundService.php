<?php

namespace Pterodactyl\Services\Settings;

/**
 * The panel's optional background image — the one behind every signed-in page.
 *
 * The behaviour lives in StoredBackground, shared with the authentication
 * background. This class is only the panel's half: where the files live and what
 * the thing is called in an error message.
 *
 * The scrim is applied by the theme, not here. See assets/aternos.css.
 */
class BackgroundService extends StoredBackground
{
    /**
     * Hard ceiling on the upload. Larger than the favicon's 4 MB because a
     * background legitimately is a big image, but still bounded: this file is
     * written into public/ and served to every visitor on every page view.
     */
    public const MAX_BYTES = 8388608; // 8 MB

    public function directory(): string
    {
        return public_path('backgrounds');
    }

    protected function metadataFilename(): string
    {
        return 'background.json';
    }
}
