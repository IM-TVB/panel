<?php

namespace Pterodactyl\Services\Settings;

/**
 * Validating an uploaded image, and naming the file it becomes.
 *
 * Shared by the panel background and the per-egg server card banner, because
 * both take the same thing from a browser and both put the result somewhere the
 * browser can fetch it. Two copies of this would drift, and the drift would be a
 * security difference rather than a cosmetic one -- the reason SVG is refused
 * lives here.
 */
trait ProbesImageUploads
{
    /**
     * Raster only. SVG is deliberately excluded: it is a document that can carry
     * script, and dropping an operator-supplied one somewhere every visitor's
     * browser fetches it is not a risk worth taking for decoration.
     */
    private const IMAGE_TYPES = [
        IMAGETYPE_PNG => 'png',
        IMAGETYPE_JPEG => 'jpg',
        IMAGETYPE_GIF => 'gif',
        IMAGETYPE_WEBP => 'webp',
    ];

    /**
     * The extensions the probe can produce, lower-cased. Used by the shape check
     * below, which has to agree with ALLOWED_TYPES or a file the probe accepted
     * could be rejected on the way back out.
     */
    private const IMAGE_EXTENSIONS = ['png', 'jpg', 'gif', 'webp'];

    /**
     * Validate an upload before it is written somewhere web-reachable.
     *
     * The mime check alone is not enough -- a .svg renamed to .png passes
     * Laravel's extension rule but getimagesize() will not decode it -- so
     * getimagesize() is the real gate.
     *
     * @return array{ext:string,w:int,h:int,type:int,bytes:int}
     */
    protected function probeImage(string $path, int $maxBytes, string $label): array
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new \RuntimeException("The {$label} could not be read.");
        }

        $size = @filesize($path);
        if ($size !== false && $size > $maxBytes) {
            throw new \RuntimeException(sprintf(
                'The %s is %.1f MB. The limit is %d MB.',
                $label,
                $size / 1048576,
                (int) ($maxBytes / 1048576),
            ));
        }

        $info = @getimagesize($path);
        if ($info === false || !isset(self::IMAGE_TYPES[$info[2]])) {
            throw new \RuntimeException(sprintf(
                'That file could not be read as an image. PNG, JPEG, GIF and WebP are supported — SVG is not.',
            ));
        }

        return [
            'ext' => self::IMAGE_TYPES[$info[2]],
            'w' => (int) $info[0],
            'h' => (int) $info[1],
            'type' => (int) $info[2],
            'bytes' => (int) $size,
        ];
    }

    /**
     * The stored filename for a validated upload: a prefix identifying what it
     * belongs to, then a content hash.
     *
     * Content-addressed so replacing an image busts caches, and so re-uploading
     * identical bytes keeps the same URL instead of causing a needless miss.
     */
    protected function imageName(string $sourcePath, string $ext, string $prefix = ''): string
    {
        $hash = substr(hash_file('sha256', $sourcePath), 0, 16);

        return $prefix === '' ? $hash . '.' . $ext : $prefix . '-' . $hash . '.' . $ext;
    }

    /**
     * Whether a stored name is one this class could have written.
     *
     * Both consumers echo their url into a <style> or a style attribute
     * *unescaped*, because escaping turns the apostrophes into entities that a
     * raw-text context does not decode -- which silently breaks the url. So the
     * name is shape-checked at the one place it enters the system, and the
     * emitter gets a value it can trust.
     *
     * $prefix must itself be shape-safe; callers pass an integer id.
     */
    protected function isSafeImageName(mixed $file, string $prefixPattern = ''): bool
    {
        if (!is_string($file) || $file === '') {
            return false;
        }

        $exts = implode('|', self::IMAGE_EXTENSIONS);
        $prefix = $prefixPattern === '' ? '' : $prefixPattern . '-';

        return preg_match('/^' . $prefix . '[0-9a-f]{16}\.(?:' . $exts . ')$/', $file) === 1;
    }
}
