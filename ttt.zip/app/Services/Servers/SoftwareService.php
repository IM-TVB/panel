<?php

namespace Pterodactyl\Services\Servers;

use Illuminate\Support\Facades\DB;
use Pterodactyl\Models\Egg;
use Pterodactyl\Models\EggVariable;
use Pterodactyl\Models\Permission;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\ServerVariable;
use Pterodactyl\Models\User;

/**
 * Describes the server software a server can actually run.
 *
 * In Pterodactyl the "software" is the egg, not a setting: the egg supplies the
 * docker image, the startup command and the install script that downloads the
 * jar. So the set of installable software is whatever eggs exist in the server's
 * own nest -- nothing more. Deriving the list from the database (rather than a
 * hardcoded catalogue) is deliberate: a hardcoded list would happily offer
 * software this panel has no install script for, and clicking it would silently
 * do nothing.
 */
class SoftwareService
{
    /**
     * Which add-ons an egg's software supports, and therefore where add-ons go.
     *
     * Anything not listed falls back to "plugins", which is correct for the
     * overwhelming majority of eggs (Paper, Spigot, Sponge, BungeeCord...).
     */
    private const ADDON_TYPES = [
        'forge' => 'mods',
        'neoforge' => 'mods',
        'fabric' => 'mods',
        'quilt' => 'mods',
    ];

    /**
     * Every egg in the server's nest, shaped for the software picker.
     */
    public function options(Server $server): array
    {
        return Egg::query()
            ->where('nest_id', $server->nest_id)
            ->with('variables')
            ->orderBy('id')
            ->get()
            ->map(fn (Egg $egg) => $this->describe($egg, $server))
            ->values()
            ->all();
    }

    /**
     * The single entry describing what this server is running right now.
     */
    public function current(Server $server, User $user): array
    {
        $egg = $server->relationLoaded('egg') ? $server->egg : Egg::query()->findOrFail($server->egg_id);

        return $this->describe($egg, $server) + [
            'is_current' => true,
            'can_switch' => $this->canSwitch($user, $server),
        ];
    }

    /**
     * Everything the confirmation dialog needs to explain itself.
     *
     * backup_limit is included because a limit of 0 is a dead end that is not
     * obvious from the client side: InitiateBackupService throws
     * TooManyBackupsException whenever the limit is 0, and unlike a full server
     * it cannot be overridden. So "create a backup first" is not advice the user
     * can act on, and the dialog has to say who has to change what.
     */
    public function backupState(Server $server): array
    {
        $backups = $server->backups()->get();
        $restorable = $backups
            ->filter(fn ($b) => $b->is_successful && !is_null($b->completed_at))
            ->values();

        return [
            'backup_limit' => (int) $server->backup_limit,
            // A limit of 0 disables backups outright, so the guard that protects
            // a software change can never be satisfied.
            'can_create_backup' => (int) $server->backup_limit > 0,
            'backup_count' => $restorable->count(),
        ];
    }

    public function canSwitch(User $user, ?Server $server = null): bool
    {
        if ($user->root_admin) {
            return true;
        }

        // Changing the egg is an administrative action in stock Pterodactyl --
        // no client route accepts an egg id. We keep that boundary rather than
        // quietly granting every server owner panel-admin powers.
        //
        // Which is exactly why this is not `$user->can('software.update', $server)`:
        // ServerPolicy::before() answers true for the server's owner, so that
        // call would hand every owner the permission they were deliberately
        // denied. Reading the subuser row is what makes "granted it explicitly"
        // mean explicitly.
        if (!$server instanceof Server) {
            return false;
        }

        $subuser = $server->subusers->where('user_id', $user->id)->first();

        return $subuser !== null
            && in_array(Permission::ACTION_SOFTWARE_UPDATE, $subuser->permissions, true);
    }

    /**
     * Move a server onto a different egg and stage its version for install.
     *
     * The stale-variable cleanup is not optional. Upstream leaves the old egg's
     * variables attached to the server when the egg changes
     * (pterodactyl/panel#3397), so a fresh install can be handed the *previous*
     * egg's values and silently reinstall the wrong build. Clearing them and
     * re-seeding from the new egg's defaults is the whole reason this is
     * explicit rather than a plain `forceFill(['egg_id' => ...])`.
     */
    public function swapEgg(Server $server, Egg $egg, ?string $version = null): Server
    {
        $oldEggId = $server->egg_id;
        $versionVariable = $this->versionVariable($egg)?->env_variable;

        DB::transaction(function () use ($server, $egg, $oldEggId, $version, $versionVariable) {
            // Delete the server's *values* for the old egg. This must go through
            // ServerVariable directly: Server::variables() is a hasMany onto
            // EggVariable (the egg's variable definitions), so writing or
            // deleting through it would destroy the egg's definitions rather
            // than this server's settings.
            ServerVariable::query()
                ->where('server_id', $server->id)
                ->whereIn('variable_id', EggVariable::query()->where('egg_id', $oldEggId)->select('id'))
                ->delete();

            $server->forceFill([
                'egg_id' => $egg->id,
                'nest_id' => $egg->nest_id,
            ])->save();

            // Seed every variable of the new egg, then apply the requested version.
            foreach ($egg->variables as $variable) {
                $value = $version !== null && $variable->env_variable === $versionVariable
                    ? $version
                    : $variable->default_value;

                ServerVariable::query()->updateOrCreate(
                    [
                        'server_id' => $server->id,
                        'variable_id' => $variable->id,
                    ],
                    ['variable_value' => $value ?? '']
                );
            }
        });

        return $server->refresh();
    }

    /**
     * Reduce an egg to the handful of facts the picker needs.
     */
    private function describe(Egg $egg, Server $server): array
    {
        $version = $this->versionVariable($egg);
        $addonType = $this->addonType($egg);
        $current = $egg->id === $server->egg_id;

        return [
            'egg_id' => $egg->id,
            'name' => $egg->name,
            'description' => $egg->description,
            'image' => $current ? $server->image : collect($egg->docker_images)->first(),
            'supports' => $addonType,
            'install_dir' => $addonType === 'mods' ? 'mods' : 'plugins',
            'badge' => $addonType === 'mods' ? 'For mods' : 'For plugins',
            'version_variable' => $version?->env_variable,
            // Read the server's own value for this variable, not the egg's
            // default: $egg->variables is the definition, ServerVariable is the
            // per-server value. $egg->variables has no server_value at all.
            'version' => $version ? $this->serverValue($server, $version) : null,
            'version_default' => $version?->default_value,
            'version_editable' => (bool) $version?->user_editable,
            'version_rules' => $version?->rules,
            'is_current' => $current,
        ];
    }

    /**
     * The value this server has stored for a given egg variable.
     */
    private function serverValue(Server $server, EggVariable $variable): ?string
    {
        return ServerVariable::query()
            ->where('server_id', $server->id)
            ->where('variable_id', $variable->id)
            ->value('variable_value');
    }

    /**
     * Pick the egg variable that actually selects the software build.
     *
     * Criteria, in order: it must be a version selector, it must not be the jar
     * filename, and the install script should reference it. The last check is
     * what distinguishes e.g. Forge's MC_VERSION (referenced by the script) from
     * an unrelated *_VERSION variable that happens to exist.
     */
    private function versionVariable(Egg $egg): ?EggVariable
    {
        $candidates = $egg->variables->filter(
            fn (EggVariable $v) => str_ends_with($v->env_variable, '_VERSION')
                && !str_contains($v->env_variable, 'JARFILE')
                && $v->user_viewable
        );

        if ($candidates->isEmpty()) {
            return null;
        }

        $script = (string) $egg->script_install;
        $referenced = $candidates->first(
            fn (EggVariable $v) => $script !== '' && str_contains($script, '${' . $v->env_variable . '}')
                || str_contains($script, '$' . $v->env_variable)
        );

        return $referenced ?? $candidates->first();
    }

    private function addonType(Egg $egg): string
    {
        $name = strtolower($egg->name);

        foreach (self::ADDON_TYPES as $needle => $type) {
            if (str_contains($name, $needle)) {
                return $type;
            }
        }

        return 'plugins';
    }
}
