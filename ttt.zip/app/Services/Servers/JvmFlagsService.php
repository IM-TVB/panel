<?php

namespace Pterodactyl\Services\Servers;

use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Server;
use Illuminate\Support\Facades\DB;

/**
 * Lets a server owner pick the JVM flags its startup command runs with.
 *
 * The flags live inline in `servers.startup`, which is what Wings uses as the
 * process invocation. So there is nothing to push to the daemon: Wings re-reads
 * the configuration from the panel in onBeforeStart() before every start, and a
 * startup that is already stored is picked up on the next boot with no API call.
 * That is what makes this safe to change while the server is running.
 *
 * The choice is also recorded in a settings row, keyed by server uuid, so the
 * picker can say which preset is active. The startup remains the source of truth
 * for what actually runs: if the two ever disagree -- an admin edited the command
 * by hand, or the egg changed -- current() reports the mismatch rather than
 * trusting the stored key, because a control that claims a preset is selected
 * when the command says otherwise is worse than no control.
 */
class JvmFlagsService
{
    /**
     * What Aikar's flags are, and what a modern JVM makes of them.
     *
     * These are aikar's published sets, verbatim, with one addition:
     * -XX:+IgnoreUnrecognizedVMOptions at the front. Without it neither set
     * starts on a current JDK, because the flags they rely on are gone:
     *
     *   UsePerfDataSubStacks        removed
     *   UseConcMarkSweepGC          removed in 14
     *   UseCMSInitiatingOccupancyOnly, CMSIncrementalMode   removed in 14
     *   AggressiveOpts, UseFastestGC                        removed in 12
     *
     * Verified by running them, not by reading them: on OpenJDK 21 both sets
     * refuse to create a JVM without it, and both start with it. The alternative
     * -- deleting the dead flags -- would keep the console quiet but would leave
     * "ParallelGC" with none of ParallelGC in it on any Java this panel can run,
     * which is a worse lie than a startup log line saying the flags are ignored.
     *
     * The sets are keyed by heap size because aikar published two: the G1GC set
     * below tunes for 12 GB and up, and there is a variant for smaller heaps
     * that omits the region-size and code-cache tuning.
     */
    private const PRESETS = [
        'aikar_g1gc' => [
            'label' => 'Aikar flags (G1GC)',
            'blurb' => 'G1GC with Aikar\'s tuning. Aimed at servers with 12 GB or more.',
            'flags' => '-XX:+IgnoreUnrecognizedVMOptions -XX:+UseG1GC -XX:+ParallelRefProcEnabled'
                .' -XX:MaxGCPauseMillis=200 -XX:+UnlockExperimentalVMOptions -XX:+DisableExplicitGC'
                .' -XX:+AlwaysPreTouch -XX:G1NewSizePercent=30 -XX:G1MaxNewSizePercent=40'
                .' -XX:G1HeapRegionSize=8M -XX:G1ReservePercent=20 -Dsun.rpc.skipNonStub=yes'
                .' -XX:+UsePerfDataSubStacks -XX:ReservedCodeCacheSize=256M -XX:+PerfDisableSharedMem',
            'target_heap_mb' => 12288,
            // Flags a current JVM drops from this set, named so the description
            // can say so rather than leaving the user to wonder.
            'dropped_on_modern_jvm' => ['UsePerfDataSubStacks'],
        ],
        'aikar_parallel_gc' => [
            'label' => 'Aikar flags (ParallelGC)',
            'blurb' => 'Aikar\'s CMS-era set. Java 14 removed CMS, so on a current Java the collector flags are ignored and G1 is used.',
            'flags' => '-XX:+IgnoreUnrecognizedVMOptions -XX:ParallelGCThreads=2 -XX:+UseConcMarkSweepGC'
                .' -XX:+UseCMSInitiatingOccupancyOnly -XX:+CMSIncrementalMode -XX:+UseAdaptiveSizePolicy'
                .' -XX:SurvivorRatio=32 -XX:+UseCompressedOops -XX:+UseFastestGC -XX:+AggressiveOpts',
            'target_heap_mb' => 12288,
            'dropped_on_modern_jvm' => [
                'UseConcMarkSweepGC',
                'UseCMSInitiatingOccupancyOnly',
                'CMSIncrementalMode',
                'UseFastestGC',
                'AggressiveOpts',
            ],
        ],
    ];

    /**
     * Flags that decide how big the heap is, and so belong to the node rather
     * than to the preset.
     *
     * Carried over from the egg when a preset is applied. Aikar sets no -Xms or
     * -Xmx, and the eggs here rely on -XX:MaxRAMPercentage against the
     * container limit, so replacing the whole segment would drop that and hand
     * the JVM its own default instead -- on a 516 MB server that is a heap of
     * roughly 129 MB, and an out-of-memory crash on a world load.
     */
    private const MEMORY_FLAGS = [
        '-Xms',
        '-Xmx',
        '-XX:MaxRAMPercentage=',
        '-XX:InitialRAMPercentage=',
        '-XX:MinRAMPercentage=',
    ];

    /** The egg's own flags, which is what "Pterodactyl default" means. */
    public const DEFAULT = 'pterodactyl';

    /**
     * Every key apply() accepts.
     *
     * A method rather than a second constant to keep in step: the request's
     * validation is closed over this list, so if the two ever drifted the
     * endpoint would accept a preset the service then refused.
     *
     * @return array<int, string>
     */
    public static function presetKeys(): array
    {
        return array_merge([self::DEFAULT], array_keys(self::PRESETS));
    }

    /**
     * Everything the picker needs, and nothing it has to fetch separately.
     */
    public function options(Server $server): array
    {
        $startup = (string) $server->startup;
        $segment = $this->flagSegment($startup);
        $presets = [];

        foreach (self::PRESETS as $key => $preset) {
            $presets[] = [
                'key' => $key,
                'label' => $preset['label'],
                'blurb' => $preset['blurb'],
                'flags' => $preset['flags'],
                'dropped_on_modern_jvm' => $preset['dropped_on_modern_jvm'],
                'target_heap_mb' => $preset['target_heap_mb'],
                'suited_to_this_server' => (int) $server->memory >= $preset['target_heap_mb'],
            ];
        }

        return [
            // A non-Java startup has no flag segment to rewrite. Said plainly
            // rather than offered as a control that silently does nothing.
            'supported' => $segment !== null,
            'reason' => $segment === null
                ? 'This server does not start with a java command, so it has no JVM flags to change.'
                : null,
            'presets' => $presets,
            'current' => $this->current($server),
            'heap_mb' => (int) $server->memory,
        ];
    }

    /**
     * Which preset produced the command that is stored, if any.
     *
     * Compared on the non-memory flags only, because the memory flags are the
     * egg's whatever preset is chosen -- comparing whole segments would never
     * match and would report every server as custom.
     */
    public function current(Server $server): array
    {
        $segment = $this->flagSegment((string) $server->startup);

        if ($segment === null) {
            return ['preset' => null, 'flags' => null, 'is_default' => false];
        }

        $tuning = $this->withoutMemoryFlags($segment);

        foreach (self::PRESETS as $key => $preset) {
            if ($this->normalise($this->withoutMemoryFlags($preset['flags'])) === $this->normalise($tuning)) {
                return ['preset' => $key, 'flags' => $segment, 'is_default' => false];
            }
        }

        // The egg's own flags, verbatim, are "Pterodactyl default" even though
        // they are not one of the named presets.
        $eggFlags = $this->flagSegment((string) ($server->egg->startup ?? ''));

        if ($eggFlags !== null && $this->normalise($eggFlags) === $this->normalise($segment)) {
            return ['preset' => self::DEFAULT, 'flags' => $segment, 'is_default' => true];
        }

        return ['preset' => null, 'flags' => $segment, 'is_default' => false];
    }

    /**
     * Rewrite the startup to run with a named preset's flags.
     *
     * $key is checked against the allowlist and nothing from the request is ever
     * placed in the command. These flags become part of a shell invocation, so
     * anything that reached them from user input would be a command injection;
     * the allowlist is the whole of the defence.
     *
     * @throws \InvalidArgumentException when the key is not one of the presets
     */
    public function apply(Server $server, string $key): Server
    {
        $segment = $this->flagSegment((string) $server->startup);

        if ($segment === null) {
            throw new \InvalidArgumentException('This server does not start with a java command.');
        }

        if ($key === self::DEFAULT) {
            $flags = $this->flagSegment((string) ($server->egg->startup ?? ''));

            if ($flags === null) {
                throw new \InvalidArgumentException('This server\'s software does not define a java command.');
            }
        } elseif (isset(self::PRESETS[$key])) {
            $flags = $this->mergeWithMemory($server, self::PRESETS[$key]['flags']);
        } else {
            throw new \InvalidArgumentException('Unknown JVM flag preset.');
        }

        $server->forceFill([
            'startup' => $this->replaceFlagSegment((string) $server->startup, $flags),
        ])->save();

        DB::table('settings')->updateOrInsert(
            ['key' => $this->settingKey($server)],
            ['value' => $key]
        );

        return $server->refresh();
    }

    private function settingKey(Server $server): string
    {
        return 'jvm_flags::' . $server->uuid;
    }

    /**
     * A preset's flags, with the heap-sizing flags the egg already sets.
     *
     * Order is not preserved between the two groups: the egg's memory flags come
     * first, because the JVM wants -Xms before anything that can raise the heap,
     * and the preset's tuning after them.
     */
    private function mergeWithMemory(Server $server, string $presetFlags): string
    {
        $memory = $this->memoryFlags($this->flagSegment((string) ($server->egg->startup ?? '')) ?? '');

        return trim(($memory !== '' ? $memory . ' ' : '') . $presetFlags);
    }

    /**
     * The run of tokens directly after the java binary that all look like flags.
     *
     * The run stops before -jar, which looks like a flag and is not one: it is
     * what begins the jar and everything after it. Treating it as a flag ate it
     * on the first write, and the startup became `java <flags> {{SERVER_JARFILE}}`
     * -- a server that cannot boot, written on a change that was supposed to be
     * safe while it ran.
     *
     * Null when the command is not a java invocation, or when the run itself
     * cannot be taken apart safely.
     */
    public function flagSegment(?string $startup): ?string
    {
        $span = $this->flagSpan($startup);

        return $span === null ? null : $span[2];
    }

    /**
     * Where the flag run sits in the command: [offset, length, text].
     *
     * Null when there is no java invocation, no flags, or the run cannot be
     * safely isolated.
     */
    private function flagSpan(?string $startup): ?array
    {
        if ($startup === null || trim($startup) === '') {
            return null;
        }

        $trimmed = trim($startup);

        // The binary: the first token, which for an absolute path is its basename.
        if (preg_match('/\S+/', $trimmed, $m, PREG_OFFSET_CAPTURE) !== 1) {
            return null;
        }

        $binary = basename($m[0][0]);

        if ($binary !== 'java' && $binary !== 'javaw') {
            return null;
        }

        // Searching for the flag run starts just after the binary token.
        $end = $m[0][1] + strlen($m[0][0]);

        // The run is recorded from the first flag token rather than from the
        // whitespace before it, so the span is the flags alone and a caller that
        // re-joins them does not end up with a stray leading space.
        $start = null;

        // Walk tokens while they look like JVM flags. Recorded as offsets rather
        // than collected and rejoined, because rejoining re-serialises the whole
        // command: Forge's startup contains `[[  ! -f unix_args.txt ]]` with a
        // double space, and splitting and rejoining it would rewrite text this
        // has no business touching.
        while (preg_match('/\s+(\S+)/', $trimmed, $m, PREG_OFFSET_CAPTURE, $end) === 1) {
            $token = $m[1][0];
            $tokenAt = $m[1][1];

            if ($token === '-jar' || $token[0] !== '-') {
                break;
            }

            $start ??= $tokenAt;
            $end = $tokenAt + strlen($token);
        }

        if ($start === null) {
            return null;
        }

        $text = substr($trimmed, $start, $end - $start);

        // A quoted token inside the run cannot be a plain flag, and splitting it
        // on whitespace would change what the shell sees. Refusing beats
        // rewriting an invocation. Quoted text *outside* the run is left alone.
        if (preg_match('/["\'`]/', $text) === 1) {
            return null;
        }

        return [$start, $end - $start, $text];
    }

    /**
     * Put a new flag run in place of the old one, touching nothing else.
     *
     * A substring splice over the run's own offsets, so the java binary, the -jar
     * and everything after it, and any quoting or unusual spacing in between, are
     * all preserved exactly.
     */
    private function replaceFlagSegment(string $startup, ?string $flags): string
    {
        $span = $this->flagSpan($startup);

        if ($span === null) {
            throw new \InvalidArgumentException('This server does not start with a java command.');
        }

        [$offset, $length] = $span;
        $trimmed = trim($startup);

        // No separator is added: the span begins at the first flag token, so the
        // whitespace between the binary and the flags is the original text ahead
        // of it and is already in the prefix. Prefixing a space here produced
        // `java  -Xms128M`.
        return substr($trimmed, 0, $offset)
            . ($flags === null ? '' : trim($flags))
            . substr($trimmed, $offset + $length);
    }

    private function memoryFlags(string $flags): string
    {
        $kept = [];

        foreach (preg_split('/\s+/', trim($flags)) ?: [] as $flag) {
            foreach (self::MEMORY_FLAGS as $prefix) {
                if (str_starts_with($flag, $prefix)) {
                    $kept[] = $flag;
                    break;
                }
            }
        }

        return implode(' ', $kept);
    }

    private function withoutMemoryFlags(string $flags): string
    {
        $kept = [];

        foreach (preg_split('/\s+/', trim($flags)) ?: [] as $flag) {
            $isMemory = false;

            foreach (self::MEMORY_FLAGS as $prefix) {
                if (str_starts_with($flag, $prefix)) {
                    $isMemory = true;
                    break;
                }
            }

            if (!$isMemory) {
                $kept[] = $flag;
            }
        }

        return implode(' ', $kept);
    }

    /**
     * Order-insensitive comparison.
     *
     * The same set of flags in a different order is the same preset, and a
     * comparison that cared about order would report a server as custom after
     * any tool had helpfully re-serialised the startup.
     */
    private function normalise(string $flags): string
    {
        $parts = preg_split('/\s+/', trim($flags)) ?: [];
        sort($parts);

        // Callback form, not bare array_filter: the no-callback form drops every
        // falsy token, which includes a legitimate flag value of "0".
        return implode(' ', array_filter($parts, fn ($part) => $part !== ''));
    }
}
