<?php

namespace Pterodactyl\Services\Servers;

use Pterodactyl\Models\Server;
use Illuminate\Database\ConnectionInterface;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Repositories\Wings\DaemonServerRepository;

class ReinstallServerService
{
    /**
     * ReinstallService constructor.
     */
    public function __construct(
        private ConnectionInterface $connection,
        private DaemonServerRepository $daemonServerRepository,
    ) {
    }

    /**
     * Reinstall a server on the remote daemon.
     *
     * $deleteFiles defaults to true: a plain reinstall has always wiped the
     * directory, so callers with no opinion must keep getting that.
     *
     * @throws \Throwable
     * @throws DisplayException
     */
    public function handle(Server $server, bool $deleteFiles = true): Server
    {
        if (!$server->canBeReinstalled()) {
            throw new DisplayException(trans('admin/server.exceptions.skipping_install_script'));
        }

        return $this->connection->transaction(function () use ($server, $deleteFiles) {
            $server->fill(['status' => Server::STATUS_INSTALLING])->save();

            $repository = $this->daemonServerRepository->setServer($server);

            // The status is set to installing first, so the wipe happens while the
            // panel already treats the server as busy. Otherwise the user can
            // start the server between the two daemon calls and end up with a
            // running process whose files are being deleted underneath it.
            if ($deleteFiles) {
                $this->assertServerIsStopped($repository);
                $repository->truncateServerFiles();
            }

            $repository->reinstall($deleteFiles);

            return $server->refresh();
        });
    }

    /**
     * Refuse to delete a running server's files.
     *
     * The daemon is asked to stop and reinstall, and it will wait for the process
     * to go offline on its own before running the install script. That wait is
     * *after* this wipe, so nothing upstream stops a live process first: a
     * Velocity proxy still holding velocity.jar open, a server writing its world
     * to disk, and then its files removed. The process keeps running off deleted
     * inodes and the next write fails in a way that looks like disk corruption.
     *
     * The panel's own `status` cannot stand in for this. It records installs,
     * backups and transfers, and is null for a server that is simply running.
     */
    private function assertServerIsStopped(DaemonServerRepository $repository): void
    {
        $state = $repository->getDetails()['state'] ?? null;

        if ($state !== 'offline') {
            throw new DisplayException(sprintf(
                'Cannot delete the files of a server that is %s. Stop the server first, then try again.',
                is_string($state) && $state !== '' ? $state : 'not stopped'
            ));
        }
    }
}
