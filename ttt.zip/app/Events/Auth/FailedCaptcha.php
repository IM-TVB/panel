<?php

namespace Pterodactyl\Events\Auth;

use Pterodactyl\Events\Event;
use Illuminate\Queue\SerializesModels;

class FailedCaptcha extends Event
{
    use SerializesModels;

    /**
     * Create a new event instance.
     *
     * $domain is nullable because the hostname a failed captcha reports is not
     * guaranteed to exist -- the verification endpoint omits it on a malformed
     * response, and callers pass `$result->hostname ?? null`. Declaring it as a
     * plain string turned every such failure into a TypeError and therefore a
     * 500, which broke password reset outright for anyone whose captcha did not
     * verify.
     */
    public function __construct(public string $ip, public ?string $domain)
    {
    }
}
