<?php

namespace Pterodactyl\Http\ViewComposers;

use Illuminate\View\View;
use Pterodactyl\Services\Helpers\AssetHashService;
use Pterodactyl\Services\Settings\AuthBackgroundService;
use Pterodactyl\Services\Settings\BackgroundService;
use Pterodactyl\Services\Settings\LogoService;
use Pterodactyl\Services\Settings\ThemeColorService;
use Pterodactyl\Services\Settings\AnnouncementService;

class AssetComposer
{
    /**
     * AssetComposer constructor.
     */
    public function __construct(
        private AssetHashService $assetHashService,
        private BackgroundService $background,
        private AuthBackgroundService $authBackground,
        private LogoService $logo,
        private ThemeColorService $colors,
        private AnnouncementService $announcement,
    ) {
    }

    /**
     * Provide access to the asset service in the views.
     */
    public function compose(View $view): void
    {
        $view->with('asset', $this->assetHashService);
        $view->with('siteConfiguration', [
            'name' => config('app.name') ?? 'Pterodactyl',
            'locale' => config('app.locale') ?? 'en',
            'recaptcha' => [
                'enabled' => config('recaptcha.enabled', false),
                'siteKey' => config('recaptcha.website_key') ?? '',
            ],
            // url is null when no background is set, which is what tells the
            // theme to emit no rule at all rather than a broken one.
            'background' => $this->background->forTheme(),
            /*
             * The login screen's own image, with the same null-means-default
             * contract. Carried on siteConfiguration rather than as a separate
             * view variable because it reaches the browser through the inline
             * <style> in templates/wrapper.blade.php, which only has one thing to
             * read from -- and the auth layout extends the same wrapper, so
             * anything else would have to be threaded through a second channel to
             * reach the one page that needs it.
             */
            'authBackground' => $this->authBackground->forTheme(),
                        // Null url means no logo, and the sidebar draws its initial-letter
            // tile instead. The same null-means-default contract as the
            // background, so a logo deleted over SSH degrades to the tile rather
            // than to a broken image.
            'logo' => $this->logo->forTheme(),
            /*
             * The admin-chosen accent colour and its whole derived palette. The
             * stylesheet reads these as var(--at-primary-*, <default>) and the
             * inline <style> in templates/wrapper.blade.php overrides them
             * before first paint, so a custom colour needs no rebuild.
             */
            'colors' => $this->colors->forTheme(),
            // Site-wide banner shown by templates/wrapper.blade.php.
            'announcement' => $this->announcement->forTheme(),
        ]);
    }
}
