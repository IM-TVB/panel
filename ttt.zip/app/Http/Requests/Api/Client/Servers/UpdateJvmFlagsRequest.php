<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers;

use Pterodactyl\Models\Permission;
use Pterodactyl\Services\Servers\JvmFlagsService;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;
use Illuminate\Validation\Rule;

/**
 * Validates a change of JVM flags.
 *
 * The preset is an allowlist lookup and nothing else. These flags end up inside a
 * shell invocation that Wings runs, so a value that reached the command from the
 * request would be a command injection -- which is why the service takes a key
 * and never a flag string, and why the rules are closed over the same list rather
 * than "any string".
 *
 * The permission is startup.read, matching the page the control now lives on. It
 * was "any signed-in user", which was right when the picker sat on the console and
 * wrong here: the Startup page is gated on startup.read, so leaving the endpoint
 * open would have been a side door to a page the same user cannot open. In
 * practice startup.read is an administrator subuser permission, so moving the
 * control there also moved who can use it.
 *
 * @see \Pterodactyl\Http\Requests\Api\Client\Servers\Startup\GetJvmFlagsRequest for the read.
 */
class UpdateJvmFlagsRequest extends ClientApiRequest
{
    public function permission(): string
    {
        return Permission::ACTION_STARTUP_READ;
    }

    public function rules(): array
    {
        return [
            'preset' => ['required', 'string', Rule::in(JvmFlagsService::presetKeys())],
        ];
    }

    public function messages(): array
    {
        return [
            'preset.in' => 'That is not a JVM flag set this panel offers.',
        ];
    }

    public function attributes(): array
    {
        return [
            'preset' => 'JVM flags',
        ];
    }
}
