<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Egg;
use Pterodactyl\Models\Server;
use Pterodactyl\Services\Servers\ReinstallServerService;
use Pterodactyl\Services\Servers\SoftwareService;
use Pterodactyl\Http\Requests\Api\Client\Servers\ChangeSoftwareRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Pterodactyl\Facades\Activity;

/**
 * Reads and changes the software a server runs.
 *
 * This exists because "change the server software" is two different things in
 * Pterodactyl, and only one of them is safe to expose casually:
 *
 *  - the *version* is an egg variable the server owner already may edit;
 *  - the *software* is the egg itself, which upstream restricts to admins and
 *    which, when changed, requires a reinstall that deletes the server's files.
 *
 * The version half is a filter update. The software half is destructive, so it
 * is refused outright (see ChangeSoftwareRequest::authorize) unless the caller
 * is a root admin, and even then requires a restorable backup to be named.
 */
class SoftwareController
{
    public function __construct(
        private SoftwareService $software,
        private ReinstallServerService $reinstall,
    ) {
    }

    /**
     * Everything the software picker needs: what is running, what else exists,
     * and whether this user is allowed to change it.
     */
    public function index(Request $request, Server $server): JsonResponse
    {
        return new JsonResponse([
            'current' => $this->software->current($server, $request->user()),
            'options' => $this->software->options($server),
            'can_switch' => $this->software->canSwitch($request->user(), $server),
            'backups' => $this->software->backupState($server),
        ]);
    }

    /**
     * Change the software and reinstall.
     *
     * Ordered deliberately: the backup is validated by the request, the egg and
     * its variables are swapped inside the transaction, and the reinstall is
     * requested last. If the daemon call fails the database is already correct,
     * so the server is left on the new egg rather than half-migrated.
     */
    public function change(ChangeSoftwareRequest $request, Server $server): JsonResponse
    {
        // Absent means delete, which is what a reinstall has always done here.
        // boolean() rather than input() so a JSON `false` is a real false and not
        // a falsy string, and so the default only applies when it is truly unset.
        $deleteFiles = $request->boolean('delete_files', true);

        $egg = Egg::query()->with('variables')->findOrFail($request->input('egg_id'));

        // Only eggs in this server's own nest are offered, so a crafted request
        // cannot move the server onto an unrelated nest (Source, Rust, ...).
        if ($egg->nest_id !== $server->nest_id) {
            return new JsonResponse([
                'errors' => [['code' => 'BadRequestHttpException', 'detail' => 'That software is not available for this server.']],
            ], JsonResponse::HTTP_BAD_REQUEST);
        }

        $version = $request->input('version');
        $described = collect($this->software->options($server))->firstWhere('egg_id', $egg->id);

        if ($version !== null && $version !== '' && !empty($described['version_variable'])) {
            // Validate the version against the *target* egg's own rules, so
            // "1.21.4" is checked against Paper's limits and not whatever the
            // server happened to be running before.
            $validator = validator(
                ['version' => $version],
                ['version' => $described['version_rules'] ?: 'required|string']
            );

            if ($validator->fails()) {
                return new JsonResponse([
                    'errors' => array_map(
                        fn (array $messages, string $field) => [
                            'code' => 'ValidationException',
                            'field' => $field,
                            'detail' => is_array($messages) ? reset($messages) : $messages,
                        ],
                        $validator->errors()->toArray(),
                        array_keys($validator->errors()->toArray())
                    ),
                ], JsonResponse::HTTP_UNPROCESSABLE_ENTITY);
            }
        }

        // swapEgg runs its own transaction; the reinstall is requested after it
        // commits so a daemon failure cannot leave a half-migrated server.
        $from = optional($server->relationLoaded('egg') ? $server->egg : Egg::query()->find($server->egg_id))->name;

        $server = $this->software->swapEgg($server, $egg, $version);

        // A software change is administrative and destructive, so it belongs in
        // the activity log. Nothing else records it: the reinstall event that
        // ReinstallServerService logs says nothing about which egg was chosen.
        // delete_files is logged because it is the difference between a reinstall
        // and a wipe. Without it the record cannot answer the only question anyone
        // asks afterwards: where did the world go?
        Activity::event('server:software.changed')
            ->subject($server)
            ->property([
                'from' => $from,
                'to' => $egg->name,
                'version' => $version,
                'delete_files' => $deleteFiles,
            ])
            ->log();

        $this->reinstall->handle($server, $deleteFiles);

        $server->refresh();

        // The full shape the GET returns, so the client can replace its cached
        // payload wholesale. Returning only current+options would leave
        // `backups` undefined after a change, because mutate() replaces the
        // cached object rather than merging into it.
        return new JsonResponse([
            'current' => $this->software->current($server, $request->user()),
            'options' => $this->software->options($server),
            'can_switch' => $this->software->canSwitch($request->user(), $server),
            'backups' => $this->software->backupState($server),
        ], JsonResponse::HTTP_ACCEPTED);
    }
}
