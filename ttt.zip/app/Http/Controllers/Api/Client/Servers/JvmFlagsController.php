<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Pterodactyl\Services\Servers\JvmFlagsService;
use Pterodactyl\Http\Requests\Api\Client\Servers\UpdateJvmFlagsRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Startup\GetJvmFlagsRequest;
use Illuminate\Http\JsonResponse;

/**
 * Reads and changes the JVM flags a server's startup runs with.
 *
 * No daemon call is made on change, and that is deliberate rather than an
 * oversight. Wings re-reads the server configuration from the panel in
 * onBeforeStart(), before every start, so a startup already stored in the
 * database takes effect on the next boot. Pushing it here would only add a
 * failure mode -- a daemon that is briefly unreachable would refuse a change that
 * would have worked anyway -- and would make the change depend on Wings being up.
 *
 * The change therefore takes effect on the next start, and the response says so.
 */
class JvmFlagsController
{
    public function __construct(
        private JvmFlagsService $flags,
    ) {
    }

    /**
     * GetJvmFlagsRequest, not UpdateJvmFlagsRequest: the update form requires a
     * preset and a GET has none to send, so the read would fail its own
     * validation. Both carry the same permission, so the page and the endpoint
     * cannot disagree about who may see this.
     */
    public function index(GetJvmFlagsRequest $request, Server $server): JsonResponse
    {
        return new JsonResponse($this->flags->options($server));
    }

    public function update(UpdateJvmFlagsRequest $request, Server $server): JsonResponse
    {
        $preset = (string) $request->input('preset');

        try {
            $server = $this->flags->apply($server, $preset);
        } catch (\InvalidArgumentException $exception) {
            return new JsonResponse([
                'errors' => [
                    [
                        'code' => 'ValidationException',
                        'field' => 'preset',
                        'detail' => $exception->getMessage(),
                    ],
                ],
            ], JsonResponse::HTTP_UNPROCESSABLE_ENTITY);
        }

        return new JsonResponse($this->flags->options($server) + [
            'message' => 'JVM flags updated. They are used the next time this server starts.',
        ], JsonResponse::HTTP_ACCEPTED);
    }
}
