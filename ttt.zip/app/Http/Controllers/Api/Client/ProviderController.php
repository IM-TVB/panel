<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Services\Plugins\ProviderKeyService;

/**
 * Reports which external plugin sources this panel can actually use.
 *
 * The client asks before offering a chip. A provider that cannot work is better
 * hidden than shown-and-empty: registering a source whose API rejects every
 * request looks identical, to the user, to a broken feature.
 */
class ProviderController extends ClientApiController
{
    public function __construct(private ProviderKeyService $keys)
    {
    }

    public function index(Request $request): JsonResponse
    {
        return new JsonResponse($this->keys->availability());
    }
}
