<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Account;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Pterodactyl\Services\Settings\UserAvatarService;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Account\UpdateAvatarRequest;
use Illuminate\Support\Facades\Storage;
use Throwable;

/**
 * A user's own profile picture.
 *
 * Readable by anyone, because a sidebar shows other people's avatars too, and
 * because the file is served straight out of public/ regardless. Writable only
 * by the owner, which the account-scoped route and ClientApiRequest enforce
 * together -- the route has no {user} parameter for anyone to swap.
 */
class AvatarController extends ClientApiController
{
    public function __construct(
        private UserAvatarService $avatars,
    ) {
        parent::__construct();
    }

    /*
     * The caller comes off the request, as the rest of this panel does. There is
     * no $this->user() on ClientApiController -- reaching for one throws, so an
     * earlier version of this controller returned a 500 on every call.
     */

    public function show(Request $request): JsonResponse
    {
        $user = $request->user();

        return new JsonResponse([
            'url' => $this->avatars->url($user),
            'has_image' => $this->avatars->has($user),
        ]);
    }

    public function update(UpdateAvatarRequest $request): JsonResponse
    {
        $user = $request->user();
        $file = $request->file('image');

        // Staged outside public/ and only promoted once it has been probed, so a
        // rejected file never sits in a web-reachable directory.
        $file->store('avatar-staging', 'local');
        $staged = Storage::disk('local')->path('avatar-staging/' . $file->hashName());

        try {
            $result = $this->avatars->set($user, $staged);
        } catch (Throwable $e) {
            report($e);

            return new JsonResponse([
                'errors' => [
                    [
                        'code' => 'ValidationException',
                        'field' => 'image',
                        'detail' => $e->getMessage(),
                    ],
                ],
            ], JsonResponse::HTTP_UNPROCESSABLE_ENTITY);
        } finally {
            @unlink($staged);
        }

        return new JsonResponse([
            'url' => $result['url'],
            'has_image' => true,
            'w' => $result['w'],
            'h' => $result['h'],
            'bytes' => $result['bytes'],
            'message' => 'Profile picture updated.',
        ], JsonResponse::HTTP_ACCEPTED);
    }

    public function reset(Request $request): JsonResponse
    {
        $removed = $this->avatars->clear($request->user());

        return new JsonResponse([
            'url' => null,
            'has_image' => false,
            'message' => $removed
                ? 'Profile picture removed. The default is back.'
                : 'You did not have a profile picture set, so nothing was changed.',
        ]);
    }
}
