<?php

namespace Pterodactyl\Http\Controllers\Admin\Plugins;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Prologue\Alerts\AlertsMessageBag;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Plugins\UpdateProviderKeyRequest;
use Pterodactyl\Services\Plugins\KeyedProviderProxy;
use Pterodactyl\Services\Plugins\ProviderKeyService;

/**
 * Admin → Settings → Plugin Sources.
 *
 * Lists every source the plugin browser can use, says plainly which need a
 * credential, and accepts the ones that do. bukkit.org is included in that list
 * even though it is not reachable: an operator looking for a "Bukkit" key field
 * should be able to see here that the key belongs to dev.bukkit.org, rather than
 * leaving it to be discovered by a source that quietly returns nothing.
 *
 * A stored key is never sent back to the browser. The form shows only whether
 * one is set and how long it is, so a key cannot be read out of the page source
 * or a stray screenshot.
 */
class ProviderController extends Controller
{
    public function __construct(
        private ProviderKeyService $keys,
        private KeyedProviderProxy $proxy,
        private AlertsMessageBag $alert,
    ) {
    }

    public function index(): View
    {
        $rows = [];

        foreach ($this->keys->availability() as $entry) {
            $meta = ProviderKeyService::PROVIDERS[$entry['id']];

            $rows[] = $entry + [
                'needs_key' => $meta['needs_key'],
                // What a key from this source looks like, so the operator can
                // tell a real one from a password hash before saving it.
                'shape' => $meta['shape'] ?? null,
                // Rendered as a real link, so the operator goes straight to the
                // page the key actually comes from.
                'url' => $meta['url'] ?? null,
                // Length only. Enough to notice a truncated paste, useless to
                // anyone reading it over your shoulder or in a screenshot.
                //
                // Based on whether a key is *stored*, not on whether the source
                // is usable. A refused key is still saved, and showing "no key"
                // beside a filled-in field would be a different lie: the
                // operator would go looking for a key they already pasted.
                'key_length' => $this->keys->key($entry['id']) === null
                    ? 0
                    : strlen((string) $this->keys->key($entry['id'])),
                'refused_at' => $this->keys->refusedAt($entry['id']),
            ];
        }

        return view('admin.plugins.providers', ['providers' => $rows]);
    }

    public function update(UpdateProviderKeyRequest $request): RedirectResponse
    {
        $provider = (string) $request->input('provider');
        $clear = $request->boolean('clear');

        if ($clear) {
            $this->keys->forget($provider);
            $this->alert->success(sprintf('The API key for %s has been removed.', $provider))->flash();

            return redirect()->route('admin.plugins.providers');
        }

        $key = trim((string) $request->input('key', ''));

        if ($key === '') {
            $this->alert->danger('No key was entered, so nothing was changed.')->flash();

            return redirect()->route('admin.plugins.providers');
        }

        $this->keys->set($provider, $key);

        // Save first, then try it. A key that is stored but rejected is still
        // visible and correctable, and the operator learns it does not work
        // immediately instead of the source failing silently later.
        try {
            $this->proxy->search($provider, ['query' => '', 'size' => 1]);
            $this->keys->markAccepted($provider);
            $this->alert->success(sprintf('The API key for %s was accepted.', $provider))->flash();
        } catch (\Throwable $e) {
            $status = $e instanceof HttpExceptionInterface ? $e->getStatusCode() : null;

            // Only an authentication verdict counts as "this key is bad". A
            // timeout, a 500 or a rate limit says nothing about the key, and
            // hiding the source on those would be wrong -- an operator would lose
            // a working source to a bad afternoon at the provider's end.
            $isAuthFailure = $status === 401 || $status === 403;

            if ($isAuthFailure) {
                $this->keys->markRefused($provider);
            }

            $this->alert
                ->danger(sprintf(
                    'The key was saved but the %s API refused it: %s%s',
                    $provider,
                    $e->getMessage(),
                    $isAuthFailure
                        ? ' The source is now hidden from the plugin browser until a working key is saved.'
                        : ' The source stays switched on, because this does not look like a problem with the key.'
                ))
                ->flash();
        }

        return redirect()->route('admin.plugins.providers');
    }
}
