<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Services\Settings\AnnouncementService;
use Throwable;

class AnnouncementController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private AnnouncementService $announcement,
    ) {
    }

    public function index(): View
    {
        return view('admin.settings.announcement', [
            'message' => $this->announcement->message() ?? '',
            'type' => $this->announcement->type(),
            'enabled' => $this->announcement->enabled(),
            'color' => $this->announcement->color() ?? '',
            'types' => AnnouncementService::TYPES,
            'updatedAt' => $this->announcement->metadata()['updatedAt'] ?? null,
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $request->validate([
            'message' => ['nullable', 'string', 'max:500'],
            'type' => ['required', 'string', 'in:info,success,warning,danger'],
            'color' => ['nullable', 'regex:/^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/'],
        ], [
            'color.regex' => 'The colour must be a hex value like #f59e0b or #f00.',
        ]);

        try {
            $this->announcement->set(
                (string) $request->input('message', ''),
                (string) $request->input('type'),
                $request->boolean('enabled'),
                $request->input('color') !== null && $request->input('color') !== '' ? (string) $request->input('color') : null,
            );

            $this->alert->success(
                $request->boolean('enabled') && trim((string) $request->input('message', '')) !== ''
                    ? 'Announcement published.'
                    : 'Announcement saved but not visible (disabled or empty).'
            )->flash();
        } catch (Throwable $e) {
            report($e);
            $this->alert->danger('Could not save the announcement: ' . $e->getMessage())->flash();
        }

        return redirect()->route('admin.settings.announcement');
    }

    public function reset(Request $request): RedirectResponse
    {
        $request->validate(['confirm' => 'required|accepted'], [
            'confirm.accepted' => 'You must confirm before clearing the announcement.',
        ]);

        if ($this->announcement->clear()) {
            $this->alert->success('The announcement has been cleared.')->flash();
        } else {
            $this->alert->danger('No announcement was set, so nothing was changed.')->flash();
        }

        return redirect()->route('admin.settings.announcement');
    }
}
