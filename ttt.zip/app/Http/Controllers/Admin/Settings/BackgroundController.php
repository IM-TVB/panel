<?php

namespace Pterodactyl\Http\Controllers\Admin\Settings;

use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Http\Requests\Admin\Settings\UpdateBackgroundRequest;
use Pterodactyl\Services\Settings\AuthBackgroundService;
use Pterodactyl\Services\Settings\BackgroundService;
use Throwable;

class BackgroundController extends Controller
{
    public function __construct(
        private AlertsMessageBag $alert,
        private BackgroundService $background,
        private AuthBackgroundService $authBackground,
    ) {
    }

    /**
     * Both backgrounds are set from this one screen, so both are read here.
     *
     * The write paths are separate controllers -- BackgroundController for the
     * panel, AuthBackgroundController for the login page -- because each has its
     * own upload, tune and reset and merging them makes every flash message
     * ambiguous about which image it refers to. Reading them together is safe
     * precisely because nothing writes them together.
     *
     * The auth values are suffixed rather than passed as a second set of `dim` /
     * `fit` / `url` keys, so the two forms on the page cannot read each other's
     * state -- which would show the login form's slider at the panel background's
     * value and silently overwrite it on save.
     */
    public function index(): View
    {
        return view('admin.settings.background', [
            'meta' => $this->background->metadata(),
            'url' => $this->background->url(),
            'hasImage' => $this->background->hasImage(),
            'dim' => $this->background->dim(),
            'fit' => $this->background->fit(),
            'fits' => BackgroundService::FITS,
            'minDim' => BackgroundService::MIN_DIM,
            'maxDim' => BackgroundService::MAX_DIM,
            'maxBytes' => BackgroundService::MAX_BYTES,
            'authMeta' => $this->authBackground->metadata(),
            'authUrl' => $this->authBackground->url(),
            'authHasImage' => $this->authBackground->hasImage(),
            'authDim' => $this->authBackground->dim(),
            'authFit' => $this->authBackground->fit(),
            // Passed rather than referenced from the view as a class constant.
            // A Blade file has no namespace, so `AuthBackgroundService::MAX_BYTES`
            // there resolves in the global namespace and the page 500s -- which is
            // how the first version of this ended up.
            'authMaxBytes' => AuthBackgroundService::MAX_BYTES,
        ]);
    }

    public function update(UpdateBackgroundRequest $request): RedirectResponse
    {
        $file = $request->file('image');

        // The upload is staged outside public/ and only promoted once it has been
        // probed, so a rejected file never sits in a web-reachable directory.
        if ($file !== null) {
            $file->store('background-staging', 'local');
            $staged = \Illuminate\Support\Facades\Storage::disk('local')
                ->path('background-staging/' . $file->hashName());

            try {
                $result = $this->background->set(
                    $staged,
                    $request->filled('dim') ? (float) $request->input('dim') : null,
                    $request->filled('fit') ? (string) $request->input('fit') : null,
                );

                $this->alert->success(sprintf(
                    'Background updated — %dx%d, %s, %.1f KB.',
                    $result['w'],
                    $result['h'],
                    strtoupper(pathinfo($result['file'], PATHINFO_EXTENSION)),
                    $result['bytes'] / 1024,
                ))->flash();
            } catch (Throwable $e) {
                report($e);
                $this->alert->danger('Could not set the background: ' . $e->getMessage())->flash();
            } finally {
                @unlink($staged);
            }
        } elseif ($this->background->hasImage()) {
            // No new file, but dim/fit may have been changed. Tuning without an
            // upload is a separate path so it cannot silently no-op.
            try {
                $this->background->tune(
                    $request->filled('dim') ? (float) $request->input('dim') : null,
                    $request->filled('fit') ? (string) $request->input('fit') : null,
                );

                $this->alert->success('Background appearance updated.')->flash();
            } catch (Throwable $e) {
                report($e);
                $this->alert->danger('Could not update the background: ' . $e->getMessage())->flash();
            }
        } else {
            $this->alert->warning('No image was uploaded, and there is no background set to adjust.')->flash();
        }

        return redirect()->route('admin.settings.background');
    }

    public function reset(): RedirectResponse
    {
        if ($this->background->reset()) {
            $this->alert->success('The default background has been restored.')->flash();
        } else {
            $this->alert->danger('No stored background was found, so nothing was changed.')->flash();
        }

        return redirect()->route('admin.settings.background');
    }
}
