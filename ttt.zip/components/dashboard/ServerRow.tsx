import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEthernet, faPowerOff } from '@fortawesome/free-solid-svg-icons';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import tw from 'twin.macro';
import Spinner from '@/components/elements/Spinner';
import styled from 'styled-components/macro';
import clsx from 'classnames';

// Determines if the current value is in an alarm threshold so we can show it in
// red rather than the more faded default style.
const isAlarmState = (current: number, limit: number): boolean => limit > 0 && current / (limit * 1024 * 1024) >= 0.9;

const Card = styled(Link)`
    ${tw`no-underline`};
`;

type Timer = ReturnType<typeof setInterval>;

type StatusMeta = { label: string; modifier: string };

const statusMeta = (
    stats: ServerStats | null,
    server: Server,
    isSuspended: boolean
): StatusMeta => {
    if (isSuspended) {
        return { label: 'Suspended', modifier: 'at-server-card__status--error' };
    }
    if (server.isNodeUnderMaintenance) {
        return { label: 'Under Maintenance', modifier: 'at-server-card__status--warning' };
    }
    if (server.isTransferring) {
        return { label: 'Transferring', modifier: 'at-server-card__status--warning' };
    }
    if (server.status === 'installing') {
        return { label: 'Installing', modifier: 'at-server-card__status--warning' };
    }
    if (server.status === 'restoring_backup') {
        return { label: 'Restoring', modifier: 'at-server-card__status--warning' };
    }
    if (server.status === 'install_failed' || server.status === 'reinstall_failed') {
        return { label: 'Install Failed', modifier: 'at-server-card__status--error' };
    }

    switch (stats?.status) {
        case 'running':
            return { label: 'Online', modifier: 'at-server-card__status--online' };
        case 'offline':
            return { label: 'Offline', modifier: 'at-server-card__status--offline' };
        default:
            return { label: 'Unavailable', modifier: 'at-server-card__status--offline' };
    }
};

const defaultAllocation = (server: Server): string => {
    const allocation = server.allocations.find((a) => a.isDefault) ?? server.allocations[0];
    if (!allocation) return 'No allocation';
    return `${allocation.alias || ip(allocation.ip)}:${allocation.port}`;
};

export default ({ server, className }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        // Don't waste a HTTP request if there is nothing important to show to the user because
        // the server is suspended.
        if (isSuspended || server.isNodeUnderMaintenance) return;

        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });

        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended, server.isNodeUnderMaintenance]);

    const alarms = { cpu: false, memory: false, disk: false };
    if (stats) {
        alarms.cpu = server.limits.cpu === 0 ? false : stats.cpuUsagePercent >= server.limits.cpu * 0.9;
        alarms.memory = isAlarmState(stats.memoryUsageInBytes, server.limits.memory);
        alarms.disk = server.limits.disk === 0 ? false : isAlarmState(stats.diskUsageInBytes, server.limits.disk);
    }

    const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : 'Unlimited';
    const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : 'Unlimited';
    const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + ' %' : 'Unlimited';

    const { label, modifier } = statusMeta(stats, server, isSuspended);
    const showStats = !!stats && !isSuspended && !server.isNodeUnderMaintenance;

    // Deterministic banner hue per server so each card feels distinct. This is
    // the fallback, not the banner: an egg can have a real image configured, and
    // the gradient stays underneath it either way.
    const seed = server.identifier
        .split('')
        .reduce((acc, ch) => acc + ch.charCodeAt(0), 0);
    const hue = seed % 360;
    const gradient = `linear-gradient(135deg, hsl(${hue} 85% 58%) 0%, hsl(${(hue + 28) % 360} 88% 44%) 100%)`;

    /*
     * The banner is layered ON TOP OF the gradient rather than replacing it, and
     * set as backgroundImage rather than through a `background` shorthand.
     *
     * Both details are load-bearing. A `background` shorthand resets every
     * background longhand it does not mention, so writing the image that way
     * blanks the gradient out from under itself -- the same trap that hid the
     * panel background image. And layering rather than replacing means a banner
     * that 404s, or has not finished loading, leaves the gradient visible instead
     * of an empty bar.
     */
    const banner = server.eggBanner;
    const bannerStyle: React.CSSProperties = banner
        ? {
              backgroundImage: `url("${banner}"), ${gradient}`,
              backgroundSize: 'cover, cover',
              backgroundPosition: 'center, center',
          }
        : { background: gradient };

    /*
     * The link uses `server.id`, not `server.identifier`.
     *
     * They are two different values. `identifier` is the server's new-style
     * realtime identifier -- `serv_` followed by the base32 of its uuid -- and
     * it is long: `serv_oza3h4rr2jak7lthp2fdsngsnq`. `id` is the eight
     * character short uuid, `7641b3f2`, which the API sends in the `identifier`
     * field while the `new_server_identifiers` feature is off.
     *
     * The panel resolves all three forms -- the `serv_` one, the short one and
     * the full uuid -- in SubstituteClientBindings, so any of them works. The
     * short one is what a person reads out loud, pastes into a chat, or reads
     * over a call, and it is what the panel's own search modal already links
     * with. If the feature flag is ever turned on, `id` becomes the `serv_`
     * form and the link stays correct either way.
     */
    return (
        <Card to={`/server/${server.id}`} className={clsx('at-server-card', className)}>
            <div
                className="at-server-card__banner"
                css={tw`bg-at-primary-500`}
                style={bannerStyle}
            >
                <span className={clsx('at-server-card__status', modifier)}>
                    <span className="at-server-card__led" />
                    {label}
                </span>

                <span
                    className="at-server-card__power"
                    role="presentation"
                    title={stats?.status === 'running' ? 'Server is running' : 'Server is stopped'}
                >
                    <FontAwesomeIcon icon={faPowerOff} css={tw`text-xs`} />
                </span>
            </div>

            <div className="at-server-card__body">
                <div className="at-server-card__name" title={server.name}>
                    {server.name}
                </div>
                <div className="at-server-card__meta">
                    <FontAwesomeIcon icon={faEthernet} css={tw`text-[10px]`} />
                    <span className="truncate">{defaultAllocation(server)}</span>
                </div>

                {showStats && (
                    <div css={tw`mt-4 space-y-2.5`}>
                        <div>
                            <div className="at-meter-row">
                                <span className="at-meter-row__label">CPU</span>
                                <span className="at-meter-row__value">{stats.cpuUsagePercent.toFixed(0)}% of {cpuLimit}</span>
                            </div>
                            <div className="at-meter">
                                <div
                                    className={clsx('at-meter__fill', {
                                        'at-meter__fill--medium': alarms.cpu,
                                    })}
                                    css={tw`bg-at-success`}
                                    style={{ width: `${Math.min(stats.cpuUsagePercent, 100)}%` }}
                                />
                            </div>
                        </div>

                        <div>
                            <div className="at-meter-row">
                                <span className="at-meter-row__label">Memory</span>
                                <span className="at-meter-row__value">
                                    {bytesToString(stats.memoryUsageInBytes)} of {memoryLimit}
                                </span>
                            </div>
                            <div className="at-meter">
                                <div
                                    className={clsx('at-meter__fill', {
                                        'at-meter__fill--medium': alarms.memory,
                                    })}
                                    style={{
                                        width: `${Math.min(
                                            server.limits.memory === 0
                                                ? 0
                                                : (stats.memoryUsageInBytes / mbToBytes(server.limits.memory)) * 100,
                                            100
                                        )}%`,
                                    }}
                                />
                            </div>
                        </div>

                        <div>
                            <div className="at-meter-row">
                                <span className="at-meter-row__label">Disk</span>
                                <span className="at-meter-row__value">
                                    {bytesToString(stats.diskUsageInBytes)} of {diskLimit}
                                </span>
                            </div>
                            <div className="at-meter">
                                <div
                                    className={clsx('at-meter__fill', {
                                        'at-meter__fill--medium': alarms.disk,
                                    })}
                                    style={{
                                        width: `${Math.min(
                                            server.limits.disk === 0
                                                ? 0
                                                : (stats.diskUsageInBytes / mbToBytes(server.limits.disk)) * 100,
                                            100
                                        )}%`,
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                )}

                {!showStats && !isSuspended && !server.isNodeUnderMaintenance && (
                    <div css={tw`mt-4 flex justify-center py-1`}>
                        <Spinner size={'small'} />
                    </div>
                )}
            </div>

            <div className="at-server-card__actions">
                <span className="at-btn at-btn--primary at-btn--sm">Manage</span>
                <span className="at-btn at-btn--secondary at-btn--sm">Console</span>
            </div>
        </Card>
    );
};
