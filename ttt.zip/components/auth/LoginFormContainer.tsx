import React, { forwardRef } from 'react';
import { Form } from 'formik';
import tw from 'twin.macro';
import FlashMessageRender from '@/components/FlashMessageRender';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

const features = [
    { title: 'Instant setup', text: 'Pick a game and your server is ready in seconds.' },
    { title: 'Web console', text: 'Run commands straight from the browser, no SSH needed.' },
    { title: 'Always available', text: 'Your server keeps running while you are away.' },
];

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => {
    // Settings are injected by the blade wrapper, but auth routes are
    // unauthenticated so guard rather than assert.
    const name = useStoreState((state: ApplicationStore) => state.settings.data?.name) || 'Game Servers';

    return (
        <div className="at-auth">
            <div className="at-auth__aside">
                <div className="at-auth__headline">{name}</div>
                <p className="at-auth__sub">
                    Game servers that just work. Create, manage and monitor everything from one dashboard.
                </p>

                {features.map((feature) => (
                    <div className="at-auth__feature" key={feature.title}>
                        <div className="at-auth__feature-icon">
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2.5"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                css={tw`w-4 h-4`}
                            >
                                <path d="M20 6 9 17l-5-5" />
                            </svg>
                        </div>
                        <div>
                            <div className="at-auth__feature-title">{feature.title}</div>
                            <div className="at-auth__feature-text">{feature.text}</div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="at-auth__form">
                <div className="at-auth__inner">
                    {title && (
                        <h2 css={tw`text-2xl font-bold mb-6 text-center text-neutral-100`}>{title}</h2>
                    )}
                    <FlashMessageRender css={tw`mb-2 px-1`} />
                    <Form {...props} ref={ref}>
                        {/* `at-auth-card` is styled for both themes by aternos.css; a Tailwind
                            `bg-white` here would stay white in dark mode. */}
                        <div css={tw`w-full border rounded-lg shadow p-6`} className="at-auth-card">
                            {props.children}
                        </div>
                    </Form>
                    <p css={tw`text-center text-neutral-500 text-xs mt-5`}>
                        {(() => {
                            const footerText = (window as any).SiteConfiguration?.colors?.footerText;

                            // A custom footer line replaces the default copyright
                            // and the Pterodactyl link -- same replacement point
                            // as PageContentBlock, so the two cannot drift.
                            if (footerText) {
                                return <>{footerText}</>;
                            }

                            return (
                                <>
                                    &copy; 2015 - {new Date().getFullYear()}&nbsp;
                                    <a
                                        rel={'noopener noreferrer'}
                                        href={'https://pterodactyl.io'}
                                        target={'_blank'}
                                        css={tw`no-underline text-neutral-500 hover:text-neutral-300`}
                                    >
                                        Pterodactyl Software
                                    </a>
                                </>
                            );
                        })()}
                    </p>
                </div>
            </div>
        </div>
    );
});
