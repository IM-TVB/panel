/**
 * The stock content box, with a class on it.
 *
 * Nothing about the box changes: same element, same padding, same title, same
 * flash slot, same spinner overlay. What is added is `at-card` on the surface
 * and `at-card__title` on the heading, and those two class names are the whole
 * reason this file is in the package.
 *
 * The reason is the one that runs through the whole theme. The box paints
 * itself through twin's `css` prop, which compiles to a style object and puts
 * no class name in the DOM -- so the light palette's remap for
 * `bg-neutral-700` has nothing to match, and the box stayed the stock dark
 * slab on a light page. The stylesheet already had a rule for exactly this
 * (`.aternos-blue .rounded.bg-neutral-700`, in section 6) and it was dead for
 * this component, because the class names it selects are not in the DOM.
 *
 * A literal className is the one thing that does reach the DOM, so it is what
 * the palette gets to hang on. Keep it.
 */
import React from 'react';
import FlashMessageRender from '@/components/FlashMessageRender';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import tw from 'twin.macro';

/**
 * The props, spelled the way React spells them.
 *
 * Upstream writes `DetailedHTMLProps<HTMLDivElement, HTMLDivElement>`, which
 * puts the *DOM* interface in the slot where React wants the props type. It
 * happens to compile, but it drags the DOM's own `children: HTMLCollection`
 * into the component's props -- so every caller that passes JSX children is
 * type-checked against an HTMLCollection, and `contentEditable: string` fights
 * React's `Booleanish | 'inherit'`. This spells it the way React does.
 */
type Props = Readonly<
    React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement> & {
        title?: string;
        borderColor?: string;
        showFlashes?: string | boolean;
        showLoadingOverlay?: boolean;
    }
>;

const ContentBox = ({ title, borderColor, showFlashes, showLoadingOverlay, children, ...props }: Props) => (
    <div {...props}>
        {title && (
            <h2 className={'at-card__title'} css={tw`text-neutral-300 mb-4 px-4 text-2xl`}>
                {title}
            </h2>
        )}
        {showFlashes && (
            <FlashMessageRender byKey={typeof showFlashes === 'string' ? showFlashes : undefined} css={tw`mb-4`} />
        )}
        <div
            className={'at-card'}
            css={[tw`bg-neutral-700 p-4 rounded shadow-lg relative`, !!borderColor && tw`border-t-4`]}
        >
            <SpinnerOverlay visible={showLoadingOverlay || false} />
            {children}
        </div>
    </div>
);

export default ContentBox;
