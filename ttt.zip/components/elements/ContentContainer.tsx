/**
 * The column the page content sits in.
 *
 * Unchanged apart from one number: the cap. It was 1200px, which on a wide
 * screen left a lot of the page empty and made the content column narrower
 * than the panels inside it. 1440px gives a desktop a proper column without
 * stretching a line of text past the point where it is comfortable to read.
 *
 * The margin and the centring are upstream's, and the same in both themes.
 */
import styled from 'styled-components/macro';
import { breakpoint } from '@/theme';
import tw from 'twin.macro';

const ContentContainer = styled.div`
    max-width: 1440px;
    ${tw`mx-4`};

    ${breakpoint('xl')`
        ${tw`mx-auto`};
    `};
`;
ContentContainer.displayName = 'ContentContainer';

export default ContentContainer;
