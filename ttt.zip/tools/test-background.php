<?php

/**
 * Asserts config/theme.php agrees with the real stylesheet.
 *
 * The page colour is stated twice: as rgb components in config/theme.php (used
 * by wrapper.blade.php to compose the background-image scrim as a literal
 * rgba(), before first paint) and as --at-page in assets/aternos.css. A
 * custom property cannot be read server-side, so the two are copied by hand and
 * can drift. The failure is subtle -- a scrim that does not quite match the
 * page it covers -- and the kind of thing that survives for months.
 *
 * This reads both and compares them, parsing #hex, rgb() and hsl() so the
 * stylesheet's two spellings (blue uses #78b1f2, dark uses hsl(209, 20%, 25%))
 * are both understood.
 *
 * Usage:
 *   php tools/test-background.php              # compare against ./assets/aternos.css
 *   php tools/test-background.php <panel-dir>  # compare against a deployed panel
 *
 * Exit 0 when they agree, 1 when they do not or either file cannot be read.
 */

$root = dirname(__DIR__);

$panel = $argv[1] ?? null;
$cssPath = $panel
    ? rtrim($panel, '/') . '/resources/scripts/assets/aternos.css'
    : $root . '/assets/aternos.css';
$configPath = $root . '/config/theme.php';

$fail = 0;

function fail(string $message): void
{
    global $fail;
    echo "  [FAIL] $message\n";
    $fail++;
}

function pass(string $message): void
{
    echo "  [PASS] $message\n";
}

// --- colour parsing ---------------------------------------------------------

function hexToRgb(string $hex): ?array
{
    $hex = ltrim(trim($hex), '#');

    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }

    if (!preg_match('/^[0-9a-fA-F]{6}$/', $hex)) {
        return null;
    }

    return [
        (int) hexdec(substr($hex, 0, 2)),
        (int) hexdec(substr($hex, 2, 2)),
        (int) hexdec(substr($hex, 4, 2)),
    ];
}

function hslToRgb(float $h, float $s, float $l): array
{
    $s /= 100;
    $l /= 100;
    $c = (1 - abs(2 * $l - 1)) * $s;
    $x = $c * (1 - abs(fmod($h / 60, 2) - 1));
    $m = $l - $c / 2;

    [$r1, $g1, $b1] = match (true) {
        $h < 60 => [$c, $x, 0.0],
        $h < 120 => [$x, $c, 0.0],
        $h < 180 => [0.0, $c, $x],
        $h < 240 => [0.0, $x, $c],
        $h < 300 => [$x, 0.0, $c],
        default => [$c, 0.0, $x],
    };

    return [
        (int) round(($r1 + $m) * 255),
        (int) round(($g1 + $m) * 255),
        (int) round(($b1 + $m) * 255),
    ];
}

/**
 * Pull the --at-page value out of a given theme block (.aternos-blue /
 * .aternos-dark) and turn it into rgb components.
 *
 * Every block whose selector matches is tried, not just the first: the
 * stylesheet has an earlier `.aternos-dark {` that carries the stock palette
 * and no --at-page at all, so taking the first match found nothing.
 */
function pageColour(string $css, string $selector): ?array
{
    if (!preg_match_all('/' . preg_quote($selector, '/') . '\s*\{(.*?)\}/s', $css, $blocks)) {
        return null;
    }

    foreach ($blocks[1] as $block) {
        if (preg_match('/--at-page\s*:\s*([^;]+);/', $block, $value)) {
            return colourToRgb(trim($value[1]));
        }
    }

    return null;
}

function colourToRgb(string $raw): ?array
{
    if (str_starts_with($raw, '#')) {
        return hexToRgb($raw);
    }

    if (preg_match('/^hsl\(\s*([\d.]+)\s*,\s*([\d.]+)%\s*,\s*([\d.]+)%\s*\)$/i', $raw, $m)) {
        return hslToRgb((float) $m[1], (float) $m[2], (float) $m[3]);
    }

    if (preg_match('/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i', $raw, $m)) {
        return [(int) $m[1], (int) $m[2], (int) $m[3]];
    }

    return null;
}

function normaliseRgbString(string $raw): ?array
{
    if (!preg_match('/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*$/', $raw, $m)) {
        return null;
    }

    return [(int) $m[1], (int) $m[2], (int) $m[3]];
}

// --- run --------------------------------------------------------------------

echo "Page colour: config/theme.php vs $cssPath\n\n";

if (!is_readable($cssPath)) {
    fail("stylesheet not found at $cssPath");
    exit(1);
}

if (!is_readable($configPath)) {
    fail("config not found at $configPath");
    exit(1);
}

$css = (string) file_get_contents($cssPath);
$config = require $configPath;
$expected = $config['background_page'] ?? null;

if (!is_array($expected)) {
    fail('config/theme.php has no background_page key');
    exit(1);
}

foreach (['blue' => '.aternos-blue', 'dark' => '.aternos-dark'] as $key => $selector) {
    $fromCss = pageColour($css, $selector);
    $fromConfig = isset($expected[$key]) ? normaliseRgbString((string) $expected[$key]) : null;

    if ($fromCss === null) {
        fail("could not read --at-page from $selector in the stylesheet");
        continue;
    }

    if ($fromConfig === null) {
        fail("config background_page.$key is not an 'r, g, b' string");
        continue;
    }

    // Tolerance of 2 per channel, deliberately. The dark theme states its page
    // colour as hsl(209, 20%, 25%), and converting that to rgb lands on a
    // tie -- blue = 76.5 -- that rounds to 77 here and 76 in the config. That
    // is a half-unit tie-break difference between two correct conversions, not
    // drift, and a browser may paint either. Failing on it would make this
    // test cry wolf out of the box, which is how a check stops being read.
    //
    // 2 units is still far tighter than any real mistake: a wrong hue, a
    // swapped channel or a hex-vs-hsl edit moves the value by tens.
    $delta = max(
        abs($fromCss[0] - $fromConfig[0]),
        abs($fromCss[1] - $fromConfig[1]),
        abs($fromCss[2] - $fromConfig[2]),
    );

    if ($delta <= 2) {
        pass(sprintf(
            '%s: %s = rgb(%s) agree (config rgb(%s), within rounding)',
            $selector,
            $key,
            implode(', ', $fromCss),
            implode(', ', $fromConfig)
        ));
    } else {
        fail(sprintf(
            '%s: stylesheet says rgb(%s) but config says rgb(%s)',
            $selector,
            implode(', ', $fromCss),
            implode(', ', $fromConfig)
        ));
    }
}

echo "\n";

if ($fail === 0) {
    echo "  ALL PASSED\n";
} else {
    echo "  $fail CHECK(S) FAILED\n";
}

exit($fail === 0 ? 0 : 1);
