#!/usr/bin/env bash
#
# Regression check: the /auth/* screens must not gain a pointless scrollbar.
#
# The Aternos split screen is `min-height: 100vh`, so ANY extra vertical space
# on an ancestor (upstream's `pt-8 xl:pt-32` wrapper, a stray margin, a fixed
# height) pushes the page past the viewport and forces scrolling to see the
# whole form.
#
# Layout cannot be measured without a browser, so this asserts the structural
# invariants that caused the bug in the first place.

set -uo pipefail
PANEL="${1:-/var/www/pterodactyl}"
CSS="$PANEL/resources/scripts/assets/aternos.css"
ROUTER="$PANEL/resources/scripts/routers/AuthenticationRouter.tsx"
fail=0

check() {
    if [ "$2" = "0" ]; then
        printf '  [PASS] %s\n' "$1"
    else
        printf '  [FAIL] %s\n' "$1"
        fail=$((fail + 1))
    fi
}

echo "Auth screen overflow check ($PANEL)"
echo

# 1. No top-padding wrapper in the auth router. Comments are stripped first,
#    because the file explains in a comment why that wrapper was removed — a
#    naive grep for `pt-8` would match its own documentation.
CLEAN=$(mktemp)
perl -0pe 's{/\*.*?\*/}{}gs' "$ROUTER" > "$CLEAN" 2>/dev/null || cp "$ROUTER" "$CLEAN"
grep -qE '\b(pt-8|xl:pt-32)\b' "$CLEAN"
[ $? -ne 0 ]; check "AuthenticationRouter has no pt-8 / xl:pt-32 wrapper" $?
rm -f "$CLEAN"

# 2. The split screen uses min-height, never a fixed height (a fixed height
#    would clip long forms instead of letting them scroll).
# The CSS writes the .at-auth rule across two lines
#     .aternos-blue .at-auth,
#     .aternos-dark .at-auth {
# so the newlines are flattened to spaces before matching: line-by-line grep
# never saw a selector and a brace on the same line, so this negative check
# passed vacuously and would have missed the regression it exists to catch.
#
# The height check neutralises `min-height` before looking for a bare height:
# `height:` is a substring of `min-height:`, so a plain match flagged the
# CORRECT min-height declaration and failed good CSS. sed rather than a grep
# lookbehind, because -P is not guaranteed to be available.
FLAT=$(tr '\n' ' ' < "$CSS" 2>/dev/null)
# The base selector only, NOT the .at-auth__sub / .at-auth__feature children:
# those legitimately carry their own spacing, and matching them (as the first
# `[a-z_]*` form did) reported a failure on correct CSS.
RULES=$(echo "$FLAT" | grep -oE '\.at-auth[[:space:]]*\{[^}]*\}')
FIXED=$(echo "$RULES" | sed 's/min-height/MINHEIGHT/g' | grep -c 'height:[[:space:]]*100vh')
[ "$FIXED" -eq 0 ]; check ".at-auth uses min-height, not a fixed height" $?

grep -q 'min-height:[[:space:]]*100vh' "$CSS"
check ".at-auth declares min-height: 100vh" $?

# 3. Nothing on the auth chain adds vertical space of its own. Same flattening
#    as above, for the same reason.
echo "$RULES" | grep -qE '(padding|margin)-(top|bottom)'
[ $? -ne 0 ]; check ".at-auth adds no padding/margin of its own" $?

# 4. The built bundle must not carry the old wrapper either.
BUNDLE=$(ls -t "$PANEL"/public/assets/bundle.*.js 2>/dev/null | head -1)
if [ -n "$BUNDLE" ]; then
    AUTH=$(grep -l 'at-auth__aside' "$PANEL"/public/assets/*.js 2>/dev/null | head -1)
    if [ -n "$AUTH" ]; then
        grep -q 'pt-8\|xl:pt-32' "$AUTH"
        [ $? -ne 0 ]; check "built auth chunk has no pt-8 / xl:pt-32" $?
    else
        echo "  [SKIP] could not locate the built auth chunk"
    fi
fi

# 5. All auth routes still respond. BASE_URL overridable, because assuming
#    https://127.0.0.1 made every check here fail on an HTTP-only install.
BASE_URL="${BASE_URL:-https://127.0.0.1}"
for p in /auth/login /auth/password /auth/login/checkpoint; do
    code=$(curl -sk -o /dev/null -w '%{http_code}' "$BASE_URL$p" --max-time 15)
    [ "$code" = "200" ]
    check "$p returns 200 (got $code)" $?
done

echo
if [ "$fail" -eq 0 ]; then
    echo "  ALL PASSED"
else
    echo "  $fail CHECK(S) FAILED"
fi
exit "$fail"
