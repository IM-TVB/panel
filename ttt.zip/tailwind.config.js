/**
 * Pterodactyl Panel — Aternos theme extension.
 *
 * This is a MERGE of the stock tailwind.config.js with Aternos additions, not a
 * replacement of the palette. The `gray` / `neutral` / `primary` scales are kept
 * exactly as upstream defines them; the dark→light flip happens in
 * resources/scripts/assets/aternos.css, which can remap `color` and
 * `background-color` independently. Overriding the scale here could not do that,
 * because `bg-neutral-700` and `text-neutral-700` share one token.
 *
 * What is added here: the `at-*` colour scale, Aternos shadows, and an
 * `Inter` font stack. Inter is only loaded if you add the @fontsource import
 * (see README); otherwise the stack falls back to the bundled IBM Plex Sans.
 */
const colors = require('tailwindcss/colors');

const gray = {
    50: 'hsl(216, 33%, 97%)',
    100: 'hsl(214, 15%, 91%)',
    200: 'hsl(210, 16%, 82%)',
    300: 'hsl(211, 13%, 65%)',
    400: 'hsl(211, 10%, 53%)',
    500: 'hsl(211, 12%, 43%)',
    600: 'hsl(209, 14%, 37%)',
    700: 'hsl(209, 18%, 30%)',
    800: 'hsl(209, 20%, 25%)',
    900: 'hsl(210, 24%, 16%)',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Inter"', 'system-ui', 'sans-serif'],
                aternos: ['"Inter"', '"IBM Plex Sans"', 'system-ui', '-apple-system', 'sans-serif'],
            },
            colors: {
                black: '#131a20',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: colors.blue,
                gray: gray,
                neutral: gray,
                cyan: colors.cyan,

                // ---- Aternos additions -------------------------------------
                // Every shade reads a CSS variable, falling back to the built-in
                // palette. assets/aternos.css and the inline <style> in
                // templates/wrapper.blade.php (fed by ThemeColorService) can
                // therefore recolour the whole panel at runtime -- no rebuild.
                at: {
                    primary: {
                        DEFAULT: 'var(--at-primary-500, #007bff)',
                        50: 'var(--at-primary-50, #e7f1ff)',
                        100: 'var(--at-primary-100, #cce3ff)',
                        200: 'var(--at-primary-200, #99c7ff)',
                        300: 'var(--at-primary-300, #66aaff)',
                        400: 'var(--at-primary-400, #338eff)',
                        500: 'var(--at-primary-500, #007bff)',
                        600: 'var(--at-primary-600, #0062cc)',
                        700: 'var(--at-primary-700, #004d99)',
                        800: 'var(--at-primary-800, #003866)',
                        900: 'var(--at-primary-900, #002233)',
                    },
                    success: { DEFAULT: '#28a745', light: '#dcf5e3', dark: '#146c2e' },
                    warning: { DEFAULT: '#ffc107', light: '#fff3d1', dark: '#8a6100' },
                    danger: { DEFAULT: '#dc3545', light: '#fbdcdf', dark: '#a01b28' },
                },
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
            boxShadow: {
                'at-sm': '0 1px 2px rgba(16, 24, 40, 0.06)',
                at: '0 2px 8px rgba(16, 24, 40, 0.07)',
                'at-lg': '0 12px 28px rgba(16, 24, 40, 0.12)',
            },
            borderRadius: {
                at: '10px',
                'at-lg': '16px',
            },
        },
    },
    /*
       @tailwindcss/line-clamp is deliberately absent. It was listed here, which
       was right for Tailwind 3.2 and is redundant from 3.3 on, where line-clamp
       is built in -- so every build printed

           warn - As of Tailwind CSS v3.3, the `@tailwindcss/line-clamp` plugin is
                  now included by default. Remove it from the `plugins` array in
                  your configuration to eliminate this warning.

       Harmless, but a warning on every build trains people to skim build output,
       which is the only thing build output is for. @tailwindcss/forms stays: it is
       not built in.
    */
    plugins: [
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ],
};
