# Aternos theme for Pterodactyl

A theme that makes a Pterodactyl panel look like Aternos: the left sidebar, the
blue and dark palettes, the login split screen, the plugin browser, the server
card banners, profile pictures, a configurable page background, and a configurable
sign-in background. It also carries the things Aternos actually does that a stock
panel does not: server power controls in the sidebar, and a page for changing the
server's software and version.

It is a **file overlay**, not a fork. It replaces 164 files inside a normal
Pterodactyl checkout and touches nothing else, so the panel stays a panel: same
database, same API, same `artisan`, same Wings.

---

## What 1.6.0 adds

A feature release. No configuration was renamed and nothing in it is required to
run the theme.

- **The sidebar is a floating glass panel.** Inset from the edge of the page,
  rounded, translucent and frosted, with the current page as a pill. The 248 px
  layout, the collapse behaviour and the drawer on small screens are unchanged --
  only the surface is different. It stays dark in both palettes on purpose: a
  light sidebar in the blue theme read as a panel of links rather than as the
  thing you are navigating inside.
- **Start / Restart / Stop moved into the sidebar**, as icon-only buttons with
  their names on hover. They act on the whole server, and the sidebar is on every
  server page, so the second copy on the Console page is gone. Console now opens
  straight into the console.
- **"Software & Version" is a page of its own**, with its own sidebar entry at
  the bottom, beside Plugins & Mods. Changing the egg used to be a step inside
  the plugin list, which meant a reinstall was always one click away from
  browsing plugins. The "Reinstalling …" message it shows clears itself after
  three seconds, the way the plugin page's does — it was staying up for the rest
  of the session, which made it look like the reinstall were still running.
- **The desktop hamburger collapses the sidebar to an icon rail.** It used to
  remove it entirely, which left no control of its own and needed a button
  floating over the page to bring it back. Now the sidebar narrows to 72px, keeps
  every icon, and each one says what it is on hover while the content takes the
  width it gives up. Mobile is untouched — below 1024px the sidebar is still a
  full-width drawer opened from the top bar.
- **The phone layout of the Console page is its own card.** Below 1024px the
  sidebar is a drawer, so the server's name, its address and its Start / Restart
  / Stop were unreachable from it. A phone now gets them on the page instead: the
  name with a live Online/Offline pill, a collapsible **Server stats** block with
  Address, CPU, Memory and Disk as `used / limit`, the power buttons, and a
  Console heading above the terminal. Desktop is unchanged — the sidebar carries
  the same three things there.
- **The server's address is in the sidebar**, directly above the server's name,
  on every page of that server. It used to be the first tile of the Console
  page's stats grid, which meant the one string a player needs to join was only
  visible on one of a dozen routes. It keeps its click-to-copy there.
- **Flash messages load and unload.** Every banner in the panel — login errors,
  settings, backups, subuser modals, plugin installs — now fades and slides in
  and out instead of popping into place and vanishing. On Plugins & Mods the
  green "Installed" banner clears itself after three seconds and a failure after
  five.
- **Subusers can be given Plugins & Mods and Software & Version.** Two new
  permission groups, `plugin` and `software`, appear on the Users page next to
  the existing ones, each with **read** and **update**.

  | permission | what it opens |
  |---|---|
  | `plugin.read` | the add-on browser (or the `file.*` it already required) |
  | `plugin.update` | the Install button and the version picker's download |
  | `software.read` | the Software & Version page |
  | `software.update` | actually changing the software |

  - **Blue and dark are a per-account choice.** The palette used to live in one
  localStorage entry, so everyone sharing a machine shared a palette and the last
  person to press the toggle won. It is keyed by account now, so a subuser picks
  their own. An existing choice is adopted rather than reset on the upgrade.
  It does not follow you between devices — that would need a column on the
  account and a migration, and this package deliberately ships none.
- **Checkboxes are themed with it:** the tick on a ticked box was a white glyph on
  Tailwind's default blue, which measured 2.54:1 — ticked and half-ticked were
  nearly the same picture. It now uses the theme's own primary and reads 5.80:1.
- **Dialogs are part of the light theme again.** The subuser modal kept the stock
  dark panel in blue mode, and took the light theme's ink with it: the title
  measured 1.53:1 and the "User Email" label 1.17:1 against it. The cause is
  worth knowing about, because it is not a one-off. The light palette is applied
  by rewriting the stock neutral scale *by class name*, and Pterodactyl styles
  components through twin's `css` prop, which compiles to a style object and
  leaves no class name in the DOM at all — `className={tw...}` is used nowhere in
  the panel. So those remap rules cannot reach a stock component, and every
  dialog and modal had the same problem. The elements that needed it now carry
  a literal class of their own, and the palette is applied to that. Dark mode
  is untouched: it is the stock palette already.
- **Your picture shows up in the activity log.** A user who had uploaded a
  profile picture saw the identicon in every activity entry — the picture was in
  the sidebar and nowhere else. Each entry now draws the picture belonging to
  the person that entry is about, and falls back to the identicon for anyone
  who has not set one. The server's own activity log is fixed by the same
  change.
- **A server's address is short.** Opening a server used to put
  `/server/serv_oza3h4rr2jak7lthp2fdsngsnq` in the bar — the server's realtime
  identifier, which is derived from its uuid and is 32 characters long. It is
  now `/server/7641b3f2`, the short uuid, which is the one the panel's own
  search already used. Every form still works; this is only about which one you
  see, read out loud, and paste into a chat.
- **The main area is wider and its type is bigger.** The page content column
  was capped at 1200px, which left a lot of a wide screen empty; it is 1440px
  now. The type in the main area — but not in the sidebar — is a size and a
  weight up: 17px at weight 500 instead of 16px at 400, with the letter
  spacing tightened rather than loosened, because type that is larger needs
  less of it.
- **The account page is modernised too**, in the same style as the subuser
  surfaces: the four boxes are cards — a light surface, a hairline and a soft
  shadow — with a 15px heading instead of a 24px one, the labels and the help
  text under each field legible against them, and the four boxes in a balanced
  two-by-two instead of three columns with one stranded on a row of its own.
  The API credentials and SSH key pages, which use the same boxes, come with
  it.
- **The subuser surfaces are modernised.** The permissions dialog and the list
  of subusers were restyled — same information, same controls, nothing added:
  the dialog is a rounded panel with a pinned action bar, each permission group
  is a card with its name as a pill and a count of how many of its keys are
  granted, the permissions are clean list items, and the list on the Users tab
  is a column of cards rather than a stack of rows. The shape applies in both
  themes; the colours follow the palette, so dark mode is unchanged.

  Installing an add-on needs `plugin.update` **and** a file write permission —
  the first says "may install", the second says "may write", and the install does
  both. Changing the software is enforced on the server, and stays closed to a
  server's own owner unless someone grants it deliberately: an egg swap
  reinstalls and deletes the server's files.
- **Install and search messages now appear at all.** The plugin page renders only
  flashes carrying its own key, and the install and search failures were being
  raised without one -- so they were shown nowhere. They are keyed now.

---

## Install — one command

```sh
tar -xzf pterodactyl-aternos-theme-*.tar.gz
cd pterodactyl-aternos-theme-*/
./setup.sh
```

That is the whole thing. `setup.sh` finds the panel itself (`/var/www/pterodactyl`
and the other usual places; pass a path if it is somewhere else), installs the
theme, clears the caches, builds the client, fixes `storage/` ownership, and then
verifies all 164 files against this package. It takes about 30 seconds and is safe
to re-run — a second run writes nothing and still verifies.

The panel directory is found rather than asked for, because making you type it is
how a copy-paste ends up writing a theme into your home directory.

If you would rather do it by hand, or you are installing into a panel this script
does not recognise:

```sh
./install.sh /var/www/pterodactyl            # copies the files, nothing else
cd /var/www/pterodactyl
yarn build:production && php artisan view:clear
```

The build is not optional. The theme's CSS and JS are bundled into
`public/assets`, not live-linked, so a panel with every file correctly placed and
no build is a panel that looks completely stock.


> **Do not extract the tarball straight over your panel.** Run `install.sh`.
>
> The package is not a drop-in overlay. 21 of its 164 files use shorter internal
> paths so the tree stays readable — `assets/aternos.css` here is the theme
> stylesheet, and it belongs at `resources/scripts/assets/aternos.css`. Extracting
> puts those 18 files in `assets/`, `components/`, `plugins/`, `routers/` and
> `views/` at the panel root, where a stock panel has no such directories.
>
> 143 of 164 files still land correctly, so **nothing errors**. The panel boots
> and serves an unthemed page, and the stylesheet is sitting in `./assets/`.
>
> If you have already done it, `./install.sh <panel> --check` says so and names
> the directories; `--clean-stray` removes them and `--force` applies the theme.

`install.sh` skips any file that already matches, so it is safe to re-run. Nothing
is overwritten unless you pass `--force`, and anything `--force` replaces is backed
up first.

| command | what it does |
|---|---|
| `./setup.sh [panel]` | the whole thing: install, build, verify |
| `./install.sh <panel>` | install, skipping files that already match |
| `./install.sh <panel> --force` | install, overwriting, backing up what it replaces |
| `./install.sh <panel> --check` | verify the panel against this package; changes nothing |
| `./install.sh <panel> --clean-stray` | remove package-only directories left by a hand-extract |
| `./install.sh <panel> --revert` | restore the panel from the backup tree |
| `./install.sh <panel> --seal` | regenerate this package's checksums |
| `./install.sh --version` | print the package version |

Backups go to `/var/www/pterodactyl-aternos-backup` (override with `BACKUP_ROOT`),
deliberately outside the panel so a reinstall cannot clobber them.

The panel runs as root-owned in most setups, so the installer escalates with `sudo`
when it needs to and tells you if passwordless sudo is unavailable.

---

## Updating the panel without losing the theme or your data

**This is the part to read.** A Pterodactyl update replaces every stock file the
panel ships, and most of what this theme *is* is modifications to stock files —
`AssetComposer`, the client settings interface, the dashboard container, the admin
routes. So a plain update reverts them while leaving the theme's own new files in
place. The result is not a broken panel: it boots, and it looks half-themed. No log
fills with errors, and the theme's own test suites mostly still pass, because most
of them assert on the theme's files — which survived.

So use the wrapper. It runs the official procedure and then puts the theme back
before the client is built, and proves it afterwards:

```sh
./panel-update.sh /var/www/pterodactyl update --latest
```

Stages, in this order, each one fatal:

1. **Back up** the database, uploads and (if the daemon is on this host) the game
   files. First, not "probably fine" — a backup taken after the update is a backup
   of the wrong thing.
2. Download the release and lay it over the panel root, preserving `.env` and
   `config/`.
3. `composer install`, then `migrations`. **On stock code, deliberately before the
   theme goes back on** — a migration must not have to boot a theme written against
   the previous release.
4. Re-apply the theme, **before the client is built**. `yarn build:production`
   compiles whatever is in `resources/scripts`, so a build run before this point
   produces an unthemed bundle with no error anywhere.
5. `yarn install` and `yarn build:production`.
6. Clear caches, fix ownership on `storage/` and `bootstrap/cache`.
7. **Verify**: every theme file compared byte for byte, and the row counts of
   `users`, `servers`, `settings`, `eggs` and `subusers` compared against the
   pre-update snapshot.
8. Bring the panel back up.

| command | what it does |
|---|---|
| `./panel-update.sh <panel> backup [dest]` | back up only; prints the directory |
| `./panel-update.sh <panel> verify [backupdir]` | check the theme and the data; changes nothing |
| `./panel-update.sh <panel> update <tag>` | the above, with `<tag>` a release tag or `--latest` |
| `./build-client.sh <panel>` | just the client build, with the heap limit set for the box |

If a stage fails, the script stops and names it, and the backup path is printed
before anything is touched.

### Why the database settings are read from the panel

Not by parsing `.env`. The password on the install this was built against is 64
characters and contains `"`, `#`, `&` and `%`; a shell parse of `.env` truncated it
and `mysqldump` refused with "access denied", leaving an empty directory that
looked like a backup. `.env` values can also be overridden in
`config/database.php`, which the panel's bootstrap resolves and a text parse does
not. So `db-config.php` asks the panel, and the password goes into a temporary
`0600` defaults-file rather than onto a command line where `ps` shows it.

---

## What is in a backup

```
database.sql              every user, server, egg, nest and setting
row-counts.txt            the counts the verify step compares against
SHA256SUMS                so a restore can prove the archive is whole
theme-state.txt           whether the theme was intact when the backup was taken
public_backgrounds.tar.gz your panel and sign-in background images
public_branding.tar.gz    your logo
public_avatars.tar.gz     user profile pictures
storage_app_public.tar.gz plugin assets
storage_logs.tar.gz       logs
etc_pterodactyl.tar.gz    daemon config, if the daemon is here
var_lib_pterodactyl.tar.gz  the game server files, if the daemon is here
```

The theme itself is **not** in the backup. It is this file list, sealed with
checksums, and it is re-applied rather than restored — a restored copy could be a
stale one, and a re-applied one cannot.

To restore:

```sh
mysql -u pterodactyl -p panel < database.sql
tar -C /var/www/pterodactyl -xzf public_backgrounds.tar.gz
tar -C /            -xzf var_lib_pterodactyl.tar.gz
```

---

## Small boxes: the client build and memory

The one step that is not portable is `yarn build:production`. V8 chooses its own
heap limit from total system memory, and on a 1 GB VPS that comes out at about
**486 MB** — which is roughly where this build's peak sits. So on a small box it
dies with:

```
<--- Last few GCs --->
FATAL ERROR: Ineffective mark-compacts near heap limit
             Allocation failed - JavaScript heap out of memory
```

Nothing is wrong with the panel or the theme. The build needs about 400 MB of heap
and the limit was never stated.

`setup.sh` and `panel-update.sh` both go through `build-client.sh`, which sets
`--max-old-space-size` from **MemAvailable** (not MemFree — page cache counts),
leaves a 200 MB allowance for MySQL, PHP-FPM and Wings, and tells the two possible
failures apart, because they need opposite responses:

- **out of memory** — a machine problem. Stop Wings for the build, add swap, or
  build the assets on a bigger machine and `rsync` `public/assets/` across. That
  directory is self-contained: hashed chunk names and a manifest, nothing outside
  it needed at runtime.
- **a compile error** — a code problem in this package, and the message names the
  file and line.

Check what your box will use:

```sh
./build-client.sh /var/www/pterodactyl
```

**If your box really is 1 GB, move the panel.** A 956 MB VPS is under what a
Pterodactyl panel wants to run, with or without this theme — Wings, MySQL and
PHP-FPM are the panel's floor, and the build needs headroom on top.

## Integrity

`CHECKSUMS` covers all 163 files this package ships. `--check` verifies the
**package** before it compares anything, and refuses to continue if the package
has drifted — comparing the panel against a tampered package would report a tampered
panel as healthy. It is the check to run after any update, by hand or in CI:

```sh
./install.sh /var/www/pterodactyl --check && echo intact
```

Exit 0 means intact, 1 means drift, 2 means the package itself is not trustworthy.

---

## Requirements

- Pterodactyl Panel 1.11 or newer, installed as a release tarball
- Node and Yarn for the client build
- `mysql-client` on `PATH` (for the backup and update actions)
- PHP CLI, and passwordless `sudo` if the panel is not writable by you

The installer checks that the files it depends on still look the way it targeted,
and warns rather than half-applying when upstream has moved.

## Licence and support

This is a theme overlay, not a fork, so it inherits the panel's licence for the
files it replaces. The theme's own additions are yours to use and modify.

If an update breaks it, `--check` will tell you which file, and the failure will
almost always be one of two things: a stock file the theme edited was restructured
upstream, or a client component it replaced was rewritten. Both are fixed in this
package, not in the panel.
