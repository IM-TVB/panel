import { useCallback, useEffect, useState } from 'react';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';

/**
 * The panel's two themes.
 *
 * `blue` is the light one. It was called `light` until its palette went blue,
 * and the name was changed at the same time so the identifier and the colour
 * could not drift apart again. The CSS class went with it: `.aternos-theme` no
 * longer exists, so a page still carrying it gets no theme styling at all.
 */
export type Theme = 'blue' | 'dark';

const STORAGE_KEY = 'pterodactyl:theme';
const BLUE = 'aternos-blue';
const DARK = 'aternos-dark';

/**
 * The key one person's choice is stored under.
 *
 * Scoped by account, because one unscoped value in localStorage means everyone
 * who uses the same machine shares a palette: a subuser pressing the toggle
 * switched the owner over too, and whichever of them loaded the panel last won.
 *
 * The account's uuid, not its numeric id, on both sides of this: the id is an
 * internal autoincrement and the uuid is what the client already holds, so the
 * hook and the pre-paint script can derive the same string without one of them
 * having to ask the database for something it does not have.
 *
 * The unscoped key is still read as a fallback, and is what an unauthenticated
 * request uses. The pre-paint script in wrapper.blade.php resolves the same key
 * from the session and has to agree with this one exactly, since that is the
 * side that runs first and sets the class before React exists. A user arriving
 * with no value of their own adopts the shared one rather than being reset to
 * blue, so nobody loses a choice they made before accounts were distinguished.
 *
 * Exported so the test can pin the two derivations together rather than each
 * being asserted against a copy of the other.
 */
export const storageKey = (userUuid?: string | null): string =>
    userUuid ? `${STORAGE_KEY}:${userUuid}` : STORAGE_KEY;

/**
 * The pre-rename class and stored value.
 *
 * Anyone who visited before the rename has `light` in localStorage and possibly
 * `aternos-theme` on <html>. The inline script in wrapper.blade.php clears both
 * before first paint, so by the time this module runs the DOM is already clean.
 * It is still removed in applyTheme() below, because a page restored from the
 * back/forward cache can be handed to React with the old class still on it.
 */
const LEGACY_CLASS = 'aternos-theme';
const LEGACY_VALUE = 'light';

/**
 * Reads the theme from the class the inline script already applied to <html>.
 * Reading the DOM rather than localStorage keeps the two in sync even if
 * something else changed the class.
 */
const readTheme = (): Theme => (document.documentElement.classList.contains(DARK) ? 'dark' : 'blue');

const applyTheme = (theme: Theme, key: string) => {
    const root = document.documentElement;

    root.classList.remove(BLUE, DARK, LEGACY_CLASS);
    root.classList.add(theme === 'dark' ? DARK : BLUE);

    try {
        window.localStorage.setItem(key, theme);
    } catch (e) {
        /* storage disabled — the toggle still works for this page view */
    }
};

/**
 * Normalises a stored value from any era of this panel to the current one.
 *
 * Exported for the migration test, which drives it against every value the
 * panel has ever written rather than against the happy path only.
 */
export const normalise = (stored: string | null): Theme => {
    if (stored === 'dark') return 'dark';
    if (stored === LEGACY_VALUE || stored === 'blue' || stored === null) return 'blue';

    /* An unrecognised value falls back to the default rather than throwing:
       localStorage is user-writable, so this is reachable. */
    return 'blue';
};

/**
 * Blue/dark theme toggle. The class lives on <html> so it can be applied before
 * first paint; localStorage persists the choice across reloads, per account.
 */
export default () => {
    // Only used to build the storage key, so the toggle writes the same place it
    // reads. Before the user has loaded there is no uuid, which lands on the
    // unscoped key -- the same one the pre-paint script uses without a session.
    const userUuid = useStoreState((state: ApplicationStore) => state.user.data?.uuid);
    const key = storageKey(userUuid);

    const [theme, setTheme] = useState<Theme>(readTheme);

    // Keep multiple components in sync if the theme changes elsewhere.
    useEffect(() => {
        const observer = new MutationObserver(() => setTheme(readTheme()));
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

        return () => observer.disconnect();
    }, []);

    const toggle = useCallback(() => {
        setTheme((current) => {
            const next: Theme = current === 'dark' ? 'blue' : 'dark';
            applyTheme(next, key);

            return next;
        });
    }, [key]);

    return { theme, toggle };
};
